import bpy
import bmesh
import fnmatch
from functools import partial
from mathutils import Vector, Matrix
from math import pi, tan, atan, ceil, floor, radians, degrees, modf
from bpy.types import Panel, Operator, PropertyGroup 
from bpy.props import *



# ======================================== Global List =======================================================
con_array = [] # global array of connection point objects


# ======================================== Custom Functions =======================================================


 # This is a message display routine 
def ShowMessageBox(message = "", title = "Message Box", icon = 'INFO'):

    def draw(self, context):
        self.layout.label(text=message)

    bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)

        

def IsConnectionPoint(obj):
# Returns True if object passed is a connection point
    if obj:
        if (obj.type == 'CURVE' and 
                (fnmatch.fnmatchcase(obj.name, "*_START*") or 
                fnmatch.fnmatchcase(obj.name, "*_END*") or 
                fnmatch.fnmatchcase(obj.name, "ARBITRARY_POINT*"))):
            return True
    return False
    
def IsLineObj(obj):
# Returns True if object passed is a line object
    if obj:
        if (obj.type != 'CURVE' and 
                (fnmatch.fnmatchcase(obj.name, "U_POWERLINE*") or
                fnmatch.fnmatchcase(obj.name, "U_PIPELINE*") or
                fnmatch.fnmatchcase(obj.name, "U_PORTALLINE*") or
                fnmatch.fnmatchcase(obj.name, "U_BYTEBEATLINE*"))):
            return True
    return False


def ConnectorType(con):
# Returns a string of type ("U_POWERLINE", "U_PIPELINE","U_PORTALLINE", "U_BYTEBEATLINE")
# based on the name of the object

    # update scene objects
    searchscope = bpy.context.scene.objects
    
    # get the power line object name associated with the connection point
    linename = con.get("power_line")
    
    # if the custom property exists
    if linename:
        # get the referenced line object from the scene 
        lineobj = searchscope.get(linename)
        # if the line object exists
        if lineobj:
            # handy way to see if any number of strings exist in another string
            if "U_POWERLINE" in linename:
                return "U_POWERLINE"
            if "U_PIPELINE" in linename:
                return "U_PIPELINE"
            if "U_PORTALLINE" in linename:
                return "U_PORTALLINE"
            if "U_BYTEBEATLINE" in linename:
                return "U_BYTEBEATLINE"
    return "NONE"



def HasNoConnection(con):
# routine to return True = if passed connection object has no line associated with it, that exists in the scene    

    # update scene objects
    searchscope = bpy.context.scene.objects
    
    # get the power line object name associated with the connection point
    linename = con.get("power_line")
    
    # if the custom property exists
    if linename:
        # get the referenced line object from the scene 
        lineobj = searchscope.get(linename)
        # if the line object exists
        if lineobj:
            # check start & end control objects in custom properties of the line object
            # against the current connection
            foundstartname = lineobj.get("start_control")
            foundendname = lineobj.get("end_control")

            # check if our connection point is referenced in the line object custom properties
            if foundstartname:
                if foundstartname == con.name:
                    # we found a valid connection
                    return False
            # check if our connection point is referenced in the line object custom properties
            if foundendname:
                if foundendname == con.name:
                    # we found a valid connection
                    return False

    return True
        




def GetLineType():
# routine to return line type connection string required, based on global mytool settings
# and user selection
    
    scene = bpy.context.scene
    mytool = scene.my_tool

    # initialize default
    linetype = "U_POWERLINE"
    
    # determine connection types
    if mytool.my_wire_type == 'ALL':
        linetype = "ALL"

    if mytool.my_wire_type == 'WIRES':
        linetype = "U_POWERLINE"

    if mytool.my_wire_type == 'PIPES':
        linetype = "U_PIPELINE"

    if mytool.my_wire_type == 'TELEPORT':
        linetype = "U_PORTALLINE"

    if mytool.my_wire_type == 'BYTE':
        linetype = "U_BYTEBEATLINE"
    
    return linetype

def UpdateScope():
# routine to update the search scope

    scene = bpy.context.scene
    mytool = scene.my_tool
    
    # take care of search scope
    if mytool.my_search_type == 'INSELECTION':
        # search in selection only
        searchscope = bpy.context.selected_objects 
    else:   # search all scene objects
        searchscope = bpy.context.scene.objects 

    return searchscope    



def DeleteConnections(deletescope):
# routine to delete connections & wires in the scene
# based on user choices
# deletescope can be: 'ALL' or 'LINES'
# where 'ALL' = All lines + connections will be deleted
#       'LINES' = Only lines will be deleted
#       'POINTS' - Only points with no connections
    
    scene = bpy.context.scene
    mytool = scene.my_tool

    # cleanup orphans first
    CleanupOrphans()

    # determine line types needed
    linetype = GetLineType()
    
    # take care of search scope
    searchscope = UpdateScope()

    # if deletescope is 'All', or 'LINES' we delete the lines in the scope
    if deletescope == 'ALL' or deletescope == 'LINES':
        # determine connection types first
        if linetype == 'ALL':
            # select all line objects
            line_objs = [o for o in searchscope if IsLineObj(o)]
        else:
            # match a particular line type
            line_objs = [o for o in searchscope if o.type != 'CURVE' and fnmatch.fnmatchcase(o.name, linetype + "*")]

        # cycle through all line objects
        for obj in line_objs:
            # delete the object
            bpy.data.objects.remove(obj, do_unlink=True)

        # take care of search scope
        searchscope = UpdateScope()
       
    # if deletescope is All, we delete connections as well
    if deletescope == 'ALL':
        # determine connection types first
        if linetype == 'ALL':
            # select all connection objects
            connection_objs = [o for o in searchscope if IsConnectionPoint(o)]
        else:
            connection_objs = [o for o in searchscope if IsConnectionPoint(o) and fnmatch.fnmatchcase(o.name, linetype + "*")]

        # cycle through all connection point objects
        for con in connection_objs:
            # delete the object
            bpy.data.objects.remove(con, do_unlink=True)
            #print(con, " = ", ConnectorType(con))
            
        # take care of search scope
        searchscope = UpdateScope()
            
    # if deletescope is POINTS, we delete all points that have no connections
    if deletescope == 'POINTS':
        # determine connection types first
        if linetype == 'ALL':
            # select all connection objects
            connection_objs = [o for o in searchscope if IsConnectionPoint(o)]
        else:
            connection_objs = [o for o in searchscope if IsConnectionPoint(o) and fnmatch.fnmatchcase(o.name, linetype + "*")]

        # cycle through all connection point objects
        for con in connection_objs:
            # determine of connection point has a line connected to it
            if HasNoConnection(con):
                # delete the object
                bpy.data.objects.remove(con, do_unlink=True)
                #print(con, " = ", ConnectorType(con))    
    
    # cleanup orphans
    CleanupOrphans()







def CleanupOrphans():
# routine to scan all the leftover power lines and delete them
# if they are not connected to any objects in the scene
# will also scan all connection points and if they are not connected to the powerline indicated,
# it will delete the powerline property

    mytool = bpy.context.scene.my_tool

    # this routine applies to all objects in the scene
    searchscope = bpy.context.scene.objects

    # cycle through all line objects first....
    line_objs = [o for o in searchscope if IsLineObj(o)]
    
    # delete the following conditions for line objects:
    # - When the start & end control connection objects are the same
    # - when the start or end control connection objects are line objects
    # - when the start or end points are not real connection points in the scene
    # cycle through all line objects
    for lineobj in line_objs:

        # init var
        lineobjdel = False

        # get start & end connection point object names in the custom properties
        startobjname = lineobj.get("start_control")
        endobjname = lineobj.get("end_control")

       # delete the line object if the start or end connection points are the same 
        if startobjname and endobjname:
            if startobjname == endobjname :
                # set the flag for deletion
                lineobjdel = True                        
                reason = "start = end"
                #print(startobjname, endobjname)
            
        # delete the line object if the start or end connection points are line objects
        # not sure if we need to check this....

        
        # check if start & endpoints actually exist in the scene
        if startobjname:
            foundstartobj = searchscope.get(startobjname)
            if not foundstartobj:
                # set the flag for deletion
                lineobjdel = True                        
            
        if endobjname:
            foundendobj = searchscope.get(endobjname)
            if not foundendobj:
                # set the flag for deletion
                lineobjdel = True                        


        # Delete the line object
        if lineobjdel:
            # delete the object
            bpy.data.objects.remove(lineobj, do_unlink=True)
     
    # update scene objects
    searchscope = bpy.context.scene.objects

    # get all line objects....
    line_objs = [o for o in searchscope if IsLineObj(o)]

    
    # --- This next section scans all lines and will ensure the associated connection point objects are 
    # --- pointing to the line object 
   
    # cycle through all line objects
    for lineobj in line_objs:

        
        # get start & end connection point objects in the searchscope
        startconobj = searchscope.get(lineobj.get("start_control"))
        endconobj = searchscope.get(lineobj.get("end_control"))

       # Update the connection point custom property "power_line" to the associated line object name in the scene 
        if startconobj:
            startconobj["power_line"] = lineobj.name   

        if endconobj:
            endconobj["power_line"] = lineobj.name   


 
            

def SelectLineAndConnections(lineobj):
# routine will select the passed line, as well as the associated endpoints
# in the scene.  This routine is primarily used by the addition of a different
# line type so the NMS plugin will switch in the next call to "connect"  

    # this routine applies to all objects
    searchscope = bpy.context.scene.objects

    # first check the line exists in the scene
    foundlineobj = searchscope.get(lineobj.name)
    if not foundlineobj:
        return

    # select it, if it isn't already
    # add the object to the current selection
    foundlineobj.select_set(True)


    # get start & end connection point object names in the custom properties
    startobjname = lineobj.get("start_control")
    endobjname = lineobj.get("end_control")

    # if start object name found
    if startobjname:
        # look for it in the scene
        foundstartobj = searchscope.get(startobjname)
        if foundstartobj:
            # select it
            # add the object to the current selection
            foundstartobj.select_set(True)
                
    # if end object found
    if endobjname:
        # look for it in the scene
        foundendobj = searchscope.get(endobjname)
        if foundendobj:
            # select it
            # add the object to the current selection
            foundendobj.select_set(True)


def GetLineStartPoint(lineobj):
# routine will return the start_point connection objectof the passed line
# in the scene.  This routine is primarily used by the addition of a different
# line type so the NMS plugin will switch in the next call to "connect"  

    # this routine applies to all objects
    searchscope = bpy.context.scene.objects

    # first check the line exists in the scene
    foundlineobj = searchscope.get(lineobj.name)
    if not foundlineobj:
        return

    # get start connection point object names in the custom properties
    startobjname = lineobj.get("start_control")

    # if start object name found
    if startobjname:
        # look for it in the scene
        foundstartobj = searchscope.get(startobjname)
        if foundstartobj:
            # return it
            return foundstartobj
   
   
def RemoveLinesFromScope(searchscope):
# routine will examine current scope objects and remove any lines selected
# will return a new searchscope
    
    # get all objects in the searchscope
    objs = searchscope
    
    # Deselect all objects in the scene
    bpy.ops.object.select_all(action='DESELECT')

    # cycle through all current objects in the search scope
    for obj in objs:
        #determine if it's a line
        if not IsLineObj(obj):
            # Select the object
            obj.select_set(True)
        


def RemoveConnectorsFromScope(searchscope):
# routine will examine current scope objects and remove any connnectors
    
    # get all currently selected objects
    objs = seachscope

    # cycle through all current objects in the selection
    for obj in objs:
        #determine if it's a line
        if IsLineObj(obj):
            # unselect the onject
            obj.select_set(False)


def SnapToNext():
# routine to snap a connector to another snap point of an object    
# checks for at least 2 objects selected, and that one of them is a connector and the other is not
# a connector or line
# the object must be the active object    
    scene = bpy.context.scene
    mytool = scene.my_tool

    # remove connectors
    RemoveLinesFromScope(bpy.context.selected_objects)

    # get all objects selected
    objs = bpy.context.selected_objects

    # save active object
    savedactive = bpy.context.view_layer.objects.active

    # check only 2 objects selected in scope
    if len(objs) != 2:
        ShowMessageBox("Select 1 connector and 1 object!", "NMS Util Error", 'ERROR')
        return {'FINISHED'}

    # init connection count var
    concount = 0
    
    # cycle through the 2 selected objects
    for obj in objs:
        # exit if object is a line
        if IsLineObj(obj):
            ShowMessageBox("Line selected!", "NMS Util Error", 'ERROR')
            return {'FINISHED'}
        # check if it's a connection
        if IsConnectionPoint(obj):
            # increment connection count
            concount += 1
            # init connection object
            conobj = obj
            # exit if connection count other than 1 
            if concount >= 2:
                ShowMessageBox("Select 1 connector and 1 object!", "NMS Util Error", 'ERROR')
                return {'FINISHED'}
        else:   # found our object
            activeobj = obj          
   
    # exit if we do not have at least 1 connection and 1 object
    if concount != 1 and (not activeobj and not conobj):
        ShowMessageBox("Select 1 connector and 1 object!", "NMS Util Error", 'ERROR')
        return {'FINISHED'}

    
    # assign the active object
    bpy.context.view_layer.objects.active = activeobj
       
    # snap to next - will snap the selected object (connection) to the active object (current object)
    bpy.ops.object.nms_snap(next_source=False, prev_source=False, next_target=True, prev_target=False)

    # cycle through the 2 selected objects
    for obj in objs:
        #select the all objects
        obj.select_set(True)

    # re-assign the active object
    bpy.context.view_layer.objects.active = savedactive
      





def AddConnectPoint():
# routine to add a connection point to the selected objects

    scene = bpy.context.scene
    mytool = scene.my_tool

    # define search scope, based on user selection
    searchscope = UpdateScope()

    # determine line types selected
    linetype = GetLineType()

    # get all objects in the search scope
    objs = searchscope

    # get the active object - this is the object that will be the master for wiring
    activeobj = bpy.context.object                       

    # connection request disabled for "ALL" line types
    if linetype == 'ALL':
        ShowMessageBox("Can't add connector for ALL wire types!", "NMS Util Error", 'ERROR')
        return {'FINISHED'}
    
         
    # empty the arrays
    del con_array[:]            


    # ========== Set the Connection Type ======================================

    # Deselect all objects in the scene
    bpy.ops.object.select_all(action='DESELECT')

    # build a sample section of user selected line type - this sets the type of connection 
    # it also selects the line object only   
    bpy.ops.object.list_build_operator(part_id=linetype)

    #store the sample line
    samplelineobj = bpy.context.selected_objects[0]

    # get the start connection for the line
    startcon = GetLineStartPoint(samplelineobj)

    # Deselect all objects in the scene
    bpy.ops.object.select_all(action='DESELECT')
    
    #select the starting connection only
    startcon.select_set(True)
    
    #Duplicate the starting line connection,  making the duplicate selected
    bpy.ops.object.duplicate_move()
    
    # assign the single connection point of linetype to a var
    templatecon = bpy.context.selected_objects[0]

    # Deselect all objects in the scene
    bpy.ops.object.select_all(action='DESELECT')
    
    # select the line and the end connections
    SelectLineAndConnections(samplelineobj)

    # delete the sample line objects
    for obj in bpy.context.selected_objects:
        # delete the connection objects just added
        bpy.data.objects.remove(obj, do_unlink=True)

    
    # at this point nothing is selected and there is no active object!
    # we also have a template connection object (templatecon) which defines what type of line will be built
    # all objects in our group of objs will only be connectors or objects (no lines)
    
    
    # ============== Connection Points to Each Object ========================


    # First we need to setup the template connector onto the stored active object(if it's a true object)


    # if at least 1 or more objects
    if len(objs) >= 1: 
        # cycle through all selected objects
        # and add connection points to them, if needed
        for obj in objs:
            
            # Deselect all objects in the scene
            bpy.ops.object.select_all(action='DESELECT')

            # if the object is not a connection point, or line object carry on
            if not IsConnectionPoint(obj) and not IsLineObj(obj):

                # Select the template point
                templatecon.select_set(True)
                
                #Duplicate the template connection,  making the duplicate selected
                bpy.ops.object.duplicate_move()
                
                # assign a var to the selected object (new connection point)
                connew = bpy.context.selected_objects[0]
                
                # add the currently selected connection point object to the array
                # along with the object pairing
                con_array.append([obj, connew]) 

                # add the object to the current selection
                obj.select_set(True)
                
                #make the object the active object 
                bpy.context.view_layer.objects.active = obj          
               
                # snap to next - will snap the selected object (connection) to the active object (current object)
                bpy.ops.object.nms_snap(next_source=False, prev_source=False, next_target=True, prev_target=False)
        
        # delete the template connection point
        bpy.data.objects.remove(templatecon, do_unlink=True)
    
        
    else:
        # Select the template point
        templatecon.select_set(True)


    # Deselect all objects in the scene
    bpy.ops.object.select_all(action='DESELECT')

    # cycle through all items in the object array list 
    for obj, con in con_array:
        # select the active connector
        obj.select_set(True)
        # select the connection
        con.select_set(True)

    # select all connectors
    SelectPoints()



def SelectLines():
# routine to isolate and select only lines in the current searchscope
    scene = bpy.context.scene
    mytool = scene.my_tool

    # define search scope, based on user selection
    searchscope = UpdateScope()

    # get all line objects....
    line_objs = [o for o in searchscope if IsLineObj(o)]

    # Deselect all objects in the scene
    bpy.ops.object.select_all(action='DESELECT')

    # cycle through all line objects
    for lineobj in line_objs:
        #select the all objects
        lineobj.select_set(True)



def SelectPoints():
# routine to isolate and select only lines in the current searchscope
    scene = bpy.context.scene
    mytool = scene.my_tool

    # define search scope, based on user selection
    searchscope = UpdateScope()

    # Deselect all objects in the scene
    bpy.ops.object.select_all(action='DESELECT')

    # select all curve connection objects
    connection_objs = [obj for obj in searchscope if IsConnectionPoint(obj)]
    
    # cycle through all connection point objects in the search scope
    for conobj in connection_objs:
        #select the all objects
        conobj.select_set(True)




# ********************************************************************************************************************    
# ==================================  Simple Connection Routine ============================
def SimpleConnectObjects():
# routine to connect all selected objects
# this simple version of the routine will work like the "connect" button in the NMS Base Builder Plugin
# except: it will connect cleanly without multiple connectors being created

    scene = bpy.context.scene
    mytool = scene.my_tool

    # define search scope, based on user selection
    searchscope = UpdateScope()

    # remove all lines from searchscope
    RemoveLinesFromScope(searchscope)

    # determine line types selected
    linetype = GetLineType()

    # get all currently selected objects
    objs = bpy.context.selected_objects


    # check at least 2 objects selected in scope
    if len(objs) <= 1:
        return

    # get the active object - this is the object that will be the master for wiring
    activeobj = bpy.context.object                       
    
    # check active object available
    if activeobj:
        if activeobj in objs:
            activeobjname = activeobj.name
        else:
            activeobj = objs[0]
            activeobjname = objs[0].name
    else:
        activeobj = objs[0]
        activeobjname = objs[0].name
        


    # connection request disabled for "ALL" line types
    if linetype == 'ALL':
        ShowMessageBox("Can't connect ALL wire types!", "NMS Util Error", 'ERROR')
        return {'FINISHED'}
    
         
    # empty the arrays
    del con_array[:]            


    # ========== Set the Connection Type ======================================

    # Deselect all objects in the scene
    bpy.ops.object.select_all(action='DESELECT')

    # build a sample section of user selected line type - this sets the type of connection 
    # it also selects the line object only   
    bpy.ops.object.list_build_operator(part_id=linetype)

    #store the sample line
    samplelineobj = bpy.context.selected_objects[0]

    # get the start connection for the line
    startcon = GetLineStartPoint(samplelineobj)

    # Deselect all objects in the scene
    bpy.ops.object.select_all(action='DESELECT')
    
    #select the starting connection only
    startcon.select_set(True)
    
    #Duplicate the starting line connection,  making the duplicate selected
    bpy.ops.object.duplicate_move()
    
    # assign the single connection point of linetype to a var
    templatecon = bpy.context.selected_objects[0]

    # Deselect all objects in the scene
    bpy.ops.object.select_all(action='DESELECT')
    
    # select the line and the end connections
    SelectLineAndConnections(samplelineobj)

    # delete the sample line objects
    for obj in bpy.context.selected_objects:
        # delete the connection objects just added
        bpy.data.objects.remove(obj, do_unlink=True)

    
    # at this point nothing is selected and there is no active object!
    # we also have a template connection object (templatecon) which defines what type of line will be built
    # all objects in our group of objs will only be connectors or objects (no lines)
    
    
    # ============== Connection Points to Each Object ========================


    # First we need to setup the template connector onto the stored active object(if it's a true object)
    # or if it's a connector, deal with it differently



    # cycle through all selected objects
    # and add connection points to them, if needed
    for obj in objs:
        
        # Deselect all objects in the scene
        bpy.ops.object.select_all(action='DESELECT')

        # only operate on non line objects
        if not IsLineObj(obj):

            # if the object is not a connection point, carry on
            if not IsConnectionPoint(obj):
 
                # Select the template point
                templatecon.select_set(True)
                
                #Duplicate the template connection,  making the duplicate selected
                bpy.ops.object.duplicate_move()
                
                # assign a var to the selected object (new connection point)
                connew = bpy.context.selected_objects[0]
                
                # add the currently selected connection point object to the array
                # along with the object pairing
                con_array.append([obj, connew]) 

                # if the current object is the active object,
                # flag mew connection point at the active connection object for later
                if obj.name == activeobj.name: 
                    conactive = connew
                
                # add the object to the current selection
                obj.select_set(True)
                
                #make the object the active object 
                bpy.context.view_layer.objects.active = obj          
               
                # snap to next - will snap the selected object (connection) to the active object (current object)
                bpy.ops.object.nms_snap(next_source=False, prev_source=False, next_target=True, prev_target=False)
        
        
        
            else:  # what to do with a connection object?
                
                # add the currently selected connection point object to the array
                # along with the object pairing
                con_array.append([obj, obj]) 

                # if the current connection object is the active object,
                # flag mew connection point at the active connection object for later
                if obj.name == activeobj.name: 
                    conactive = obj
        
    
        
    # delete the template connection point
    bpy.data.objects.remove(templatecon, do_unlink=True)

    
    # =========== Start of inter-connections generation =======================

    
    # cycle through all items in the object array list 
    for obj, con in con_array:

        # assign the active object to the active connection object 
        bpy.context.view_layer.objects.active = con          
            
        # Deselect all objects in the scene
        bpy.ops.object.select_all(action='DESELECT')
        
        # select the active connector
        conactive.select_set(True)
        # select the connection
        con.select_set(True)
        #return       
        # make sure the active connecting doesn't get connected to itself
        if conactive.name != con:        
            # need to have 2 x points selected for this command
            # make electrical connection between points
            bpy.ops.object.nms_connect()
            #newlineobj = bpy.context.selected_objects[0]

            # ensure the active connection has same power line property as the object
            if not con["power_line"]:
                #create it
                con["power_line"] = ""
            # ensure the active connection has same power line property as the object
            if not conactive["power_line"]:
                #create it
                conactive["power_line"] = ""
            # now assign
            con["power_line"] = conactive["power_line"]

    # cleanup first
    CleanupOrphans()




