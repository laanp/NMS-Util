import bpy
from mathutils import Vector, Matrix
from math import pi, tan, atan, ceil, floor, radians, degrees, modf


# Global CONSTANTS
# define standard floor width (in case it changes)
std_floor_width = 5.33
std_floor_height = 3.33

# the following list defines the number of sides needed for a round floor 
# based on the number of diameter floorplates, starting with [1,2,3,4....20] 
# this list is used in the "OP_CreateOptoRound" routine 
round_sides = [8,10,12,16,18,22,24,28,32,34,38,40,44,48,52,54,56,60,64]
 
# GLOBAL string arrays
coa_list = []              # list of the current circle of anything items names




 # This is a message display routine 
def ShowMessageBox(message = "", title = "Message Box", icon = 'INFO'):

    def draw(self, context):
        self.layout.label(text=message)

    bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)

 

# routine to return the rotation axis of the rotated reference object
def GetNormalRotationAxis(obj):
    rotationMAT = obj.rotation_euler.to_matrix()
    rotationMAT.invert()
    if abs(rotationMAT[0][2]) == 1:
        return "X"
    if abs(rotationMAT[1][2]) == 1:
        return "Y"
    if abs(rotationMAT[2][2]) == 1:
        return "Z"
    # return default
    return "Y"

# routine to return the translate to centre axis of the circle objects (for circle adjust)
def GetNormalTranslateAxis(obj):
    rotationMAT = obj.rotation_euler.to_matrix()
    rotationMAT.invert()
    if abs(rotationMAT[0][1]) == 1:
        return "X"
    if abs(rotationMAT[1][1]) == 1:
        return "Y"
    if abs(rotationMAT[2][1]) == 1:
        return "Z"
    # return default
    return "Z"


# routine to calculate the rotation width of an object based on it's orientation
# pass the object and routine will return the rotation width to use
def GetRotationWidth(obj):
    # get rotation orientation for ref object
    rot_ref = GetNormalRotationAxis(obj)
    # get translation info for ref object
    tran_ref = GetNormalTranslateAxis(obj)

    if tran_ref == 'X':
        if rot_ref == 'Y':
            return obj.dimensions.z
        else:
            return obj.dimensions.y
    
    if tran_ref == 'Y':
        if rot_ref == 'X':
            return obj.dimensions.z
        else:
            return obj.dimensions.x
    
    if tran_ref == 'Z':
        if rot_ref == 'X':
            return obj.dimensions.y
        else:
            return obj.dimensions.x
    # default
    return obj.dimensions.x


# This operator is the main code that runs when a user clicks on the "Setup/Reset" button in the 
# "Object Circle Creator" Panel" menu, under the "Object Circle" section, to complete the
# setup arrangement for building the circle.  
# It will dispay a circle mesh item, and a reference object, to show the intial diameter
# and arrangement of the circle build.  
def SetupCircle():

    scene = bpy.context.scene
    mytool = scene.my_tool

    # get the currently active object 
    orig_obj = bpy.context.object
    # get the currently selected object
    if orig_obj is None : 
        ShowMessageBox("Please select an object first!", "Circle of Anything Error", 'ERROR')
        return {'FINISHED'}

    # Set flag that centre offset has not been done yet
    mytool.my_bool_centre_adjust_done = False

    # check for the setup circle, if it exists
    found = mytool.my_str_circle_name in bpy.data.objects
    if found:
        # assign a variable to the circle object
        c_obj = bpy.data.objects[mytool.my_str_circle_name]
        # delete the circle object
        bpy.data.objects.remove(c_obj, do_unlink=True)
        
        # check for the reference object, if it exists
        found = mytool.my_str_ref_obj_name in bpy.data.objects
        if found:
            # assign a variable to the reference object
            r_obj = bpy.data.objects[mytool.my_str_ref_obj_name]
            # delete the circle object
            bpy.data.objects.remove(r_obj, do_unlink=True)
            
        # select original object, if it exists
        found = mytool.my_str_obj_name in bpy.data.objects
        if found:
            #assign the original object variable
            orig_obj = bpy.data.objects[mytool.my_str_obj_name]   

            # Set the active object to a specific object in the scene
            bpy.context.view_layer.objects.active = orig_obj       
            

    # check for the existence of the circle object list - indicates not happy with circle, want reset
    found = len(coa_list) > 1 and len(bpy.context.selected_objects) > 1
    if found:
        # assign the original object variable to the orginial object name
        orig_obj = bpy.data.objects[mytool.my_str_obj_name]   
    
        # Set the active object to the original object
        bpy.context.view_layer.objects.active = orig_obj
        
        # unselect original object
        orig_obj.select_set(False)  

        # deletes all reamining selected objects
        bpy.ops.object.delete(use_global=False, confirm=False)
 
        # reselect original object
        orig_obj.select_set(True)  

    # clear the circle objects names list
    del coa_list[:]

    # reselect original object
    orig_obj.select_set(True)  

    # set the global variable to the original centre object name
    mytool.my_str_obj_name = orig_obj.name 
    
    # place the 3D cursor to the centre of the original object
    bpy.ops.view3d.snap_cursor_to_selected()


    # copy the original object in place
    bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'},
    TRANSFORM_OT_translate={"value":(0,0,0), "orient_type":'NORMAL'})

    # cycle through currently selected object (should be the newly added reference object)
    for obj in bpy.context.selected_objects:
        # store the reference object names
        ref_obj = obj
        mytool.my_str_ref_obj_name  = obj.name
    
    # --------------------------  Section that calculates rotation width based on objects orientation -------------------    
    # get the rotation width
    mytool.my_float_obj_width = GetRotationWidth(ref_obj)
    
    # get the width of the object, based on it's orientation
    width = mytool.my_float_obj_width
    
    # check if it's a floorplate (change width if so)
    if "FLOOR" in orig_obj.name:
        width = std_floor_width


    # =============   Start of Object Count Method   ====================
    
    # Calculate the rotation needed, based on # of sides
    deg_rot = 360 / mytool.my_int_obj_count
    
    # calculate the move of the object from current location (centre and 3D location)
    move_dist = (width / 2) / (tan((deg_rot / 2) * pi / 180))
    
    # assign global variable the circle radius
    mytool.my_float_circle_radius = move_dist
    
    # move the newly copied reference object
    bpy.ops.transform.translate(value=(0, -move_dist, 0), orient_type='GLOBAL')

    # store the radius rotation location vector
    mytool.my_floatvect_rad = ref_obj.location  

    # Add a mesh to show circle path
    bpy.ops.mesh.primitive_circle_add(radius=move_dist)
    # cycle through currently selected object (should be the circle)
    for obj in bpy.context.selected_objects:
        circle_obj = obj     # store the circle object
        mytool.my_str_circle_name = circle_obj.name
        
    #make the reference object the currently selected item
    bpy.context.scene.objects[mytool.my_str_ref_obj_name].select_set(True)  
    
    #make the new ref object the active object
    bpy.context.view_layer.objects.active = ref_obj

    # save the reference object rotation
    #r_mat_ref = ref_obj.rotation_euler.to_matrix()

    # Unselect the circle object
    circle_obj.select_set(False)  

    # add to my list of circle object names 
    coa_list.append(ref_obj.name)

    # adjust distance to centre based on object count
    mytool.my_float_dist_to_centre = 0.03 * mytool.my_int_obj_count
    

    # Set the flag that setup done
    mytool.my_bool_setup_done = True




# This operator is code that runs when a user clicks on the "<<" button in the 
# "Object Circle Creator" Panel" menu, under the "Object Rotation Offset" menu item, to adjust circle object(s) 
# rotation by incremental amounts.
# It is primarily used to rotate the reference object before completing the "Create Circle" routine,
# but also will rotate the entire selected object circle items if done after building the circle
def RotationINAdjustOperator():

    scene = bpy.context.scene
    mytool = scene.my_tool

    # get reference object, & store in variable obj
    found = mytool.my_str_ref_obj_name in bpy.data.objects
    if found:
        obj = bpy.data.objects[mytool.my_str_ref_obj_name]
    else:   # just exit
        return {'FINISHED'}
    
    #make the new ref object the active object
    bpy.context.view_layer.objects.active = obj

    # set the pivot point around the individual origins
    bpy.context.scene.tool_settings.transform_pivot_point = 'INDIVIDUAL_ORIGINS'

    # rotate the object(s) in step
    bpy.ops.transform.rotate(value=radians(mytool.my_float_rot_offset), orient_axis=GetNormalRotationAxis(obj), orient_type='LOCAL')



# This operator is code that runs when a user clicks on the ">>" button in the 
# "Object Circle Creator" Panel" menu, under the "Object Rotation Offset" menu item, to adjust circle object(s) 
# rotation by incremental amounts.
# It is primarily used to rotate the reference object before completing the "Create Circle" routine,
# but also will rotate the entire selected object circle items if done after building the circle
def RotationOUTAdjustOperator():

    scene = bpy.context.scene
    mytool = scene.my_tool

    # get reference object, & store in variable obj
    found = mytool.my_str_ref_obj_name in bpy.data.objects
    if found:
        obj = bpy.data.objects[mytool.my_str_ref_obj_name]
    else:   # just exit
        return {'FINISHED'}
    
    #make the new ref object the active object
    bpy.context.view_layer.objects.active = obj

    # set the pivot point around the individual origins
    bpy.context.scene.tool_settings.transform_pivot_point = 'INDIVIDUAL_ORIGINS'

    # rotate the object in step
    bpy.ops.transform.rotate(value=-radians(mytool.my_float_rot_offset), orient_axis=GetNormalRotationAxis(obj), orient_type='LOCAL')

   


# This operator is code that runs when a user clicks on the "<<" button in the 
# "Object Circle Creator" Panel" menu, under the "Distance to Centre" menu item, to adjust circle object(s) 
# towards/away from the circle centre by incremental amounts.
def AdjustINOperator():

    scene = bpy.context.scene
    mytool = scene.my_tool


    # get reference object, & store in variable obj
    found = mytool.my_str_ref_obj_name in bpy.data.objects
    if found:
        obj = bpy.data.objects[mytool.my_str_ref_obj_name]
    else:   # just exit
        return {'FINISHED'}

    # Set the pivot point around the 3D cursor
    bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'

    # based on translate position of reference object, move selected objects to centre of circle
    if GetNormalTranslateAxis(obj) == "X":
        bpy.ops.transform.translate(value=(mytool.my_float_dist_to_centre, 0, 0), orient_type='LOCAL')
    if GetNormalTranslateAxis(obj) == "Y":
        bpy.ops.transform.translate(value=(0, mytool.my_float_dist_to_centre, 0), orient_type='LOCAL')
    if GetNormalTranslateAxis(obj) == "Z":
        bpy.ops.transform.translate(value=(0, 0, mytool.my_float_dist_to_centre), orient_type='LOCAL') 



# This operator is code that runs when a user clicks on the ">>" button in the 
# "Object Circle Creator" Panel" menu, under the "Distance to Centre" menu item, to adjust circle object(s) 
# towards/away from the circle centre by incremental amounts.
def AdjustOUTOperator():

    scene = bpy.context.scene
    mytool = scene.my_tool

    # get reference object, & store in variable obj
    found = mytool.my_str_ref_obj_name in bpy.data.objects
    if found:
        obj = bpy.data.objects[mytool.my_str_ref_obj_name]
    else:   # just exit
        return {'FINISHED'}

    # Set the pivot point around the 3D cursor
    bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'

    # based on translate position of reference object, move selected objects to centre of circle
    if GetNormalTranslateAxis(obj) == "X":
        bpy.ops.transform.translate(value=(-mytool.my_float_dist_to_centre, 0, 0), orient_type='LOCAL')
    if GetNormalTranslateAxis(obj) == "Y":
        bpy.ops.transform.translate(value=(0, -mytool.my_float_dist_to_centre, 0), orient_type='LOCAL')
    if GetNormalTranslateAxis(obj) == "Z":
        bpy.ops.transform.translate(value=(0, 0, -mytool.my_float_dist_to_centre), orient_type='LOCAL') 




# This operator is the main code that runs when a user clicks on the "Create" button in the 
# "Object Circle Creator" Panel" menu, under the "Build Circle" section, to create the object circle.
def CreateCircle():

    scene = bpy.context.scene
    mytool = scene.my_tool

    # check for the reference object, if it exists
    found = mytool.my_str_ref_obj_name in bpy.data.objects
    if found:
        # assign a variable to the reference object
        ref_obj = bpy.data.objects[mytool.my_str_ref_obj_name]
    else:
        bpy.ops.addonname.setup_operator('INVOKE_DEFAULT')
    
    # Check if setup has been done - if not, run setup
    if not mytool.my_bool_setup_done :
        bpy.ops.addonname.setup_operator('INVOKE_DEFAULT')

    # get the currently active object (should be the reference object)
    ref_obj = bpy.context.object

    # get the currently selected object
    if ref_obj is None : 
        ShowMessageBox("Please select reference object!", "Circle of Anything Error", 'ERROR')
        return {'FINISHED'}

    # Calculate the rotation needed, based on # of sides
    deg_rot = 360 / mytool.my_int_obj_count

    # get the original object
    orig_obj = bpy.context.scene.objects.get(mytool.my_str_obj_name)
    if orig_obj is None : 
        ShowMessageBox("Please redo setup!", "Circle of Anything Error", 'ERROR')
        return {'FINISHED'}
    
    # place the 3D cursor to the centre of the original centre object
    bpy.context.scene.cursor.location = orig_obj.location     

    # --------------------------  Section that calculates rotation width based on objects orientation -------------------    
    # get the rotation width
    mytool.my_float_obj_width = GetRotationWidth(ref_obj)
    
    rotationMAT = ref_obj.rotation_euler.to_matrix()
    rotationMAT.invert()
    rot_axis = GetNormalRotationAxis(ref_obj)
    
    # get the width of the object, based on it's orientation
    width = mytool.my_float_obj_width
    
    # check if it's a floorplate (change width if so)
    if "FLOOR" in ref_obj.name:
        width = std_floor_width
    # check if object needs adjustment to find centre
    if rot_axis == "X" or rot_axis == "Z":
        if abs(rotationMAT[1][0]) == 1:
            # adjust the location of the ref object along the Y axis (LOCAL) to account for centre change 
            bpy.ops.transform.translate(value=(0, -(mytool.my_float_obj_width / 2), 0), orient_type='LOCAL')
            
            # calculate the new move distance of the object from current location (centre and 3D location)
            new_move_dist = (width / 2) / (tan((deg_rot / 2) * pi / 180))
            
            # move the ref object by difference between new calculated move and original
            bpy.ops.transform.translate(value=(0, (mytool.my_float_circle_radius-new_move_dist), 0), orient_type='GLOBAL')


    # add to my list of object names of the circle objects
    coa_list.append(ref_obj.name)

          
    # cyle through each number of sides
    for i in range(mytool.my_int_obj_count - 1) :
    
        # Set the pivot point around the 3D cursor
        bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'

        # Rotate selected objects around the 3D cursor and duplicate
        # copies of original selected items are created, with the newly created objects now being
        # the newly selected objects 
        bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'},
        TRANSFORM_OT_translate={"value":(0,0,0), "orient_type":'NORMAL'})

        # get the object
        new_ref_obj = bpy.context.object
        
        # rotate the object
        bpy.ops.transform.rotate(value=radians(deg_rot), orient_axis='Z', orient_type='GLOBAL')
            
        # add to my list of objects in the circle
        coa_list.append(new_ref_obj.name)
    
    
    # delete the reference circle if it exists
    circle_obj = bpy.context.scene.objects.get(mytool.my_str_circle_name)
    # if the circle object exists from setup...
    if circle_obj:
        object_to_delete = bpy.data.objects[mytool.my_str_circle_name]
        bpy.data.objects.remove(object_to_delete, do_unlink=True)            

    #add all objects to selection
    for index, obj_name in enumerate(coa_list):
        obj = bpy.context.scene.objects.get(obj_name)
        if obj:
            obj.select_set(True)    
    
    # Setup is reset
    mytool.my_bool_setup_done = False
  