import bpy


# ======================================== Global Variable & Constants Definitions =======================================================

# GLOBAL string arrays
vertex_list = []              # list of the vertex names



def BuildText():

    scene = bpy.context.scene
    mytool = scene.my_tool
    
    # initialize a vertex location list
    vert_locs = []
    del vert_locs[:]
    
    # initialize a character start vertex index list
    char_vert_counts = []
    del char_vert_counts[:]

    # initialize a character  name list
    char_objs = []
    del char_objs[:]
    
    # at this point he text object should be selected
    
    # convert the text object to a mesh
    bpy.ops.object.convert(target='MESH')

    # go into edit mode
    bpy.ops.object.editmode_toggle()

    # select all
    bpy.ops.mesh.select_all(action='SELECT')

    # separate the letters into different parts
    bpy.ops.mesh.separate(type='LOOSE')

    # go back into object mode
    bpy.ops.object.editmode_toggle()

    # Cycle through All selected objects and store vector locations
    for obj in bpy.context.selected_objects :     
        # get the mesh data for the object
        mesh = obj.data
        # store the vertex counts for this object in a list
        char_vert_counts.append(len(mesh.vertices))
        
        # store the character object name in a list
        char_objs.append(obj.name)

        # cycle through each vertex in vertices of the object
        for vert in mesh.vertices:
            # store the vertex location
            vert_locs.append(obj.matrix_world @ vert.co)
                    

    #initialize total vertex index
    total_verts = 0
   
    # cycle through all text character objects 
    for index, obj_name in enumerate(char_objs):
        # get the text caharacter object
        obj = bpy.data.objects[obj_name]

        # Deselect all objects in the scene
        bpy.ops.object.select_all(action='DESELECT')
        
        # cycle through all vertices for the current text character
        for i in range(total_verts, char_vert_counts[index] + total_verts):       
         
            # create a new NMS electrical point
            bpy.ops.object.nms_point()
            
            # Assign a variable to the Active object 
            obj = bpy.context.object                       

            # set the location of the newly added electrical point
            obj.location = vert_locs[i]
      
        #increment total vertex index
        total_verts += char_vert_counts[index]
                                

    return {'FINISHED'}



def AdjustText():

    scene = bpy.context.scene
    mytool = scene.my_tool
    
    t = mytool.my_str_text
    c = mytool.my_bool_center
    i = mytool.my_bool_italic
    
    # check if at least 1 object selected
    found = len(bpy.context.selected_objects)

    # check if an object selected and it's a font.
    if found:
        obj = bpy.context.selected_objects[0]
        
        if obj.type == "FONT":
            # work with existing text selected        
            bpy.ops.object.editmode_toggle()
            bpy.ops.font.select_all()
            bpy.ops.font.delete(type='PREVIOUS_WORD')
            bpy.ops.font.text_insert(text= t)        
        else:
            # create the text object
            bpy.ops.object.text_add(enter_editmode=True)
            bpy.ops.font.delete(type='PREVIOUS_WORD')
            bpy.ops.font.text_insert(text= t)        
    else:
        # create the text object
        bpy.ops.object.text_add(enter_editmode=True)
        bpy.ops.font.delete(type='PREVIOUS_WORD')
        bpy.ops.font.text_insert(text= t)        

    bpy.context.object.data.fill_mode = 'NONE'

    # adjust other text settings
    bpy.context.object.data.resolution_u = 2
    bpy.context.object.data.bevel_resolution = 0
    bpy.context.object.data.bevel_depth = 0
    bpy.context.object.data.small_caps_scale = 0
    bpy.context.object.data.extrude = 0


    # toggle edit mode
    bpy.ops.object.editmode_toggle()
    bpy.context.object.data.size = 3
    if c == True:
        bpy.context.object.data.align_x = 'CENTER'
        bpy.context.object.data.align_y = 'CENTER'
    else:
        bpy.context.object.data.align_x = 'LEFT'
        bpy.context.object.data.align_y = 'CENTER'

    if i == True:
        bpy.context.object.data.shear = 0.38
    else:
        bpy.context.object.data.shear = 0
        
    if len(t) != 0:
        bpy.context.object.name = t
    else:
        bpy.context.object.name = t + " : Text"
                
 
    return {'FINISHED'}


