import bpy
from mathutils import Vector, Matrix
from math import pi, tan, atan, ceil, floor, radians, degrees, modf


# Global CONSTANTS
# define standard floor width (in case it changes)
std_floor_width = 5.33
std_floor_height = 3.33

# the following list defines the number of sides needed for a round floor 
# based on the number of diameter floorplates, starting with [1,2,3,4....20] 
# this list is used in the "OP_CreateOptoRound" routine 
round_sides = [8,10,12,16,18,22,24,28,32,34,38,40,44,48,52,54,56,60,64]


# to initialize lists 
obj_listy = []             # List of the first single row of square or round floorplates, along Y axis
obj_list_floor = []        # total list of floorplate object names for first single floor


# GLOBAL Variables
total_floorplates = int(0)


 # This is a message display routine 
def ShowMessageBox(message = "", title = "Message Box", icon = 'INFO'):

    def draw(self, context):
        self.layout.label(text=message)

    bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)




# Routine to set a passed object's location in real world
# based on a NORMAL vector move_distances 
def SetWorldLocation(obj, move_x, move_y, move_z):

    # adjustment values of new direction distance (based on NORMAL orientation)
    dist = Vector((move_x, move_y, move_z))

    # Move the selected object
    # Following lines will convert a vector move (move_dist) to a new location vector
    # it's needed if objects x,y,z translation is needed for NORMAL transform movement in Blender 2.8 and above
    rotationMAT = obj.rotation_euler.to_matrix()
    rotationMAT.invert()
    # project the vector to the world using the rotation matrix
    zVector = dist @ rotationMAT
    # adjust currently selected objects location
    obj.location = obj.location + zVector





# Routine to remove floor centres on round floors,for symmetrical option
# This should be called before duplicating floors
# called from the OP_CreateRound operator when creating optimized round floors
# works with the global floor list that gets set when building floors
# it also works with the custom property variable: my_int_centres_to_remove
def RemoveSymCentres():

    scene = bpy.context.scene
    mytool = scene.my_tool
    
    # Check if object diameter count is even
    even_diam = ((mytool.my_int_diam % 2) == 0)

    # skip if no centres being removed
    if mytool.my_int_centres_to_remove <= 0:
        return
    
    # if even diameter
    if even_diam:
        
        # check for max centres to delete
        if mytool.my_int_centres_to_remove >= mytool.my_int_diam / 2:
            mytool.my_int_centres_to_remove = mytool.my_int_diam / 2 - 1   
        
        
        loop_idx = int(0)
        #print ("Loop ", round_sides[mytool.my_int_diam - 2], loop_idx)
        #print (round_sides[loop_idx])
        for i in range(round_sides[mytool.my_int_diam - 2]):
            for c in range(mytool.my_int_centres_to_remove):
                # here is where we delete the floors
                found = obj_list_floor[loop_idx + c] in bpy.data.objects
                if found:
                    obj = bpy.data.objects[obj_list_floor[loop_idx + c]]
                    bpy.data.objects.remove(obj, do_unlink=True)
                #print(loop_idx + c)
            loop_idx += int(mytool.my_int_diam / 2)
   
    # Odd diameter
    else:
        # check for max centres to delete
        if mytool.my_int_centres_to_remove >= (mytool.my_int_diam + 1) / 2:
            mytool.my_int_centres_to_remove = (mytool.my_int_diam - 1) / 2   
        
        loop_idx = int(0)
        #print ("Loop ", round_sides[mytool.my_int_diam - 2], loop_idx)
        #print (round_sides[loop_idx])
        for i in range(round_sides[mytool.my_int_diam - 2]):
            for c in range(mytool.my_int_centres_to_remove):
                # here is where we delete the floors
                found = obj_list_floor[loop_idx + c] in bpy.data.objects
                if found:
                    obj = bpy.data.objects[obj_list_floor[loop_idx + c]]
                    bpy.data.objects.remove(obj, do_unlink=True)
                #print(loop_idx + c)
            
            loop_idx += int((mytool.my_int_diam + 1) / 2)
  
 
# Routine to remove floor centres on round floors for non-symmetrical option
# This should be called before duplicating floors
# called from the OP_CreateOptoRound operator when creating optimized round floors
# works with the global floor list that gets set when building floors
# it also works with the custom property variable: my_int_centres_to_remove
def RemoveNonSymCentres():

    scene = bpy.context.scene
    mytool = scene.my_tool
    
    # Check if object diameter count is even
    even_diam = ((mytool.my_int_diam % 2) == 0)

    # skip if no centres being removed
    if mytool.my_int_centres_to_remove <= 0:
        return
    
    # if even diameter
    if even_diam:
        
        # check for max centres to delete
        if mytool.my_int_centres_to_remove >= mytool.my_int_diam / 2:
            mytool.my_int_centres_to_remove = mytool.my_int_diam / 2 - 1   
        
        # first, set the starting index
        # for even number of diameter floorplates, starts at 1, for every 2nd index
        idx_count = 0
        
        # repeat this for the number of centres that need removing
        for ctrs in range(1, mytool.my_int_centres_to_remove + 1):
            # calculate the current loop index we need to pull from our list
            # for even number of diameter floorplates, starts at 1, for every 2nd index
            loop_idx = (ctrs * 2) - 2 
            #print ("Loop ", ctrs, loop_idx)
            #print (round_sides[loop_idx])
            for i in range(round_sides[loop_idx]):
                # here is where we delete the floors
                found = obj_list_floor[idx_count] in bpy.data.objects
                if found:
                    obj = bpy.data.objects[obj_list_floor[idx_count]]
                    bpy.data.objects.remove(obj, do_unlink=True)
                idx_count += 1
       
    # Odd diameter
    else:
        # check for max centres to delete
        if mytool.my_int_centres_to_remove >= (mytool.my_int_diam + 1) / 2:
            mytool.my_int_centres_to_remove = (mytool.my_int_diam - 1) / 2   
        
        # first, set the starting index
        # for even number of diameter floorplates, starts at 1, for every 2nd index
        idx_count = 1
        
        # repeat this for the number of centres that need removing
        for ctrs in range(2, mytool.my_int_centres_to_remove + 1):
            # calculate the current loop index we need to pull from our list
            # for even number of diameter floorplates, starts at 1, for every 2nd index
            loop_idx = (ctrs * 2) - 3
            #print ("Loop ", ctrs, loop_idx)
            #print (round_sides[loop_idx])
            for i in range(round_sides[loop_idx]):
                # here is where we delete the floors
                found = obj_list_floor[idx_count] in bpy.data.objects
                if found:
                    obj = bpy.data.objects[obj_list_floor[idx_count]]
                    bpy.data.objects.remove(obj, do_unlink=True)
                idx_count += 1
 
         # delete the 0 index here & exit if mytool.my_int_centres_to_remove = 1
        if mytool.my_int_centres_to_remove >= 1:
            found = obj_list_floor[0] in bpy.data.objects
            if found:
                obj = bpy.data.objects[obj_list_floor[0]]
                bpy.data.objects.remove(obj, do_unlink=True)


# This routine is code that runs when a user clicks on the "Build" button in the 
# "Floor Creator" menu to add floor tiles
def AddFloorTile():

    scene = bpy.context.scene
    mytool = scene.my_tool

    # If Wood floor tile selected
    if mytool.my_enum_material == 'OP1' :
        if mytool.my_bool_with_glass:
            bpy.ops.object.list_build_operator(part_id="W_GFLOOR")
        else:
            bpy.ops.object.list_build_operator(part_id="W_FLOOR")

    # If Metal floor tile selected
    if mytool.my_enum_material == 'OP2' :
        if mytool.my_bool_with_glass:
            bpy.ops.object.list_build_operator(part_id="M_GFLOOR")
        else:
            bpy.ops.object.list_build_operator(part_id="M_FLOOR")
    
    # If Metal floor tile selected
    if mytool.my_enum_material == 'OP3' :
        if mytool.my_bool_with_glass:
            bpy.ops.object.list_build_operator(part_id="C_GFLOOR")
        else:
            bpy.ops.object.list_build_operator(part_id="C_FLOOR")
    

 
# This routine is code that runs when a user clicks on the "<<" button in the 
# "Floor Creator" menu, under the "Distance to Centre" menu item, to adjust round floor tiles 
# towards/away from the round floor centre by incremental amounts.
def AdjustRoundINOperator():

    scene = bpy.context.scene
    mytool = scene.my_tool

    # check if at least 1 object selected
    if len(bpy.context.selected_objects) == 0:
        return {'FINISHED'}

    if mytool.my_floatvect_rad:
        # Set the 3D cursor to a position saved in a custom property variable
        bpy.context.scene.cursor.location = mytool.my_floatvect_rad     

    # Set the pivot point around the 3D cursor
    bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'


    # translate selected objects to centre of circle
    bpy.ops.transform.translate(value=(0, 0, mytool.my_float_round_adjust), orient_type='LOCAL') 



 
 
# This operator is code that runs when a user clicks on the ">>" button in the 
# "Floor Creator" menu, under the "Distance to Centre" menu item, to adjust round floor tiles 
# towards/away from the round floor centre by incremental amounts.
def AdjustRoundOUTOperator():
 
    scene = bpy.context.scene
    mytool = scene.my_tool

    # check if at least 1 object selected
    if len(bpy.context.selected_objects) == 0:
        return {'FINISHED'}

    if mytool.my_floatvect_rad:
        # Set the 3D cursor to a position saved in a custom property variable
        bpy.context.scene.cursor.location = mytool.my_floatvect_rad     

    # Set the pivot point around the 3D cursor
    bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'


    # translate selected objects to centre of circle
    bpy.ops.transform.translate(value=(0, 0, -mytool.my_float_round_adjust), orient_type='LOCAL') 



# Optimized round floors creation routine for NON-symmetrical layout
# This operator is code that runs when a user clicks on the "Create" button in the 
# "Floor Creator" menu, under the "Build Round Floors" menu item, to build round floor arrangements
def CreateOptoRound():

    scene = bpy.context.scene
    mytool = scene.my_tool

    del obj_list_floor[:]

    # get the currently active object (should also be the selected)
    obj = bpy.context.object

    # get the currently selected object
    if obj : 
        # add the current object name to the total floor object count object names & list
        obj_list_floor.append(obj.name)
        
    else :
        ShowMessageBox("Please choose a floor object!", "Floor Creator Error", 'ERROR')
        return {'FINISHED'}
    
    # select object, it if it isn't already
    obj.select_set(True) 

    # place the 3D cursor to the centre of our currently selected object(s)
    bpy.ops.view3d.snap_cursor_to_selected()        
    
    # save the location vector of the 3D cursor centre of rotation
    mytool.my_floatvect_rad = obj.location  

    # make sure diameter is min=2
    if mytool.my_int_diam < 2:
       mytool.my_int_diam = 2


    # ====================  Copy Along Z-Axis (NORMAL orientation =============================

    # Check if object diameter count is even
    even_diam = ((mytool.my_int_diam % 2) == 0)

    # initialize movement along z axis
    z_move = 0
    
    # to ready for duplication & rotation...
    # check if even or odd
    if even_diam:
        
        # initially move by 1/2 width of floor tile
        z_move = std_floor_width * obj.scale[2] * 0.5
    else:
            
        # copy centre 
        bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'},
        TRANSFORM_OT_translate={"value":(0,0,0), "orient_type":'NORMAL'})
    
        # cycle through all selected objects (should be newly selected one) and add to complete floor objects list
        for obj in bpy.context.selected_objects:
            # add the current object name to the total floor object count object names & list
            obj_list_floor.append(obj.name)

        # initially move by 1 width of floor tile
        z_move = std_floor_width * obj.scale[2] 
    
   
   
    # set the actual object to world coordinates
    SetWorldLocation(obj, 0, 0, -z_move)
    
    # assign the reference object
    ref_obj = obj
        

    #return {'FINISHED'}
   
    
    # ====================  Build out rings of Round Floors  =============================

    for d in range(int(mytool.my_int_diam / 2)):    
        
        if even_diam:
            # get the required sides for the diameter specified
            sides = round_sides[d * 2]
        else:
            # get the required sides for the diameter specified
            sides = round_sides[(d * 2) + 1]
            
        # calcualte the rotation angle
        rot_angle = 360 / sides    
        
        # Loop for length
        # cycle through a single row of -axis (NORMAL orientation) objects 
        for i in range(sides - 1) :


            # copy the currently selected objects, (not the active object, unless it also is selected) with no translation
            # copies of original selected items are created, with the newly created objects now being
            # the newly selected objects 
            bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'},
            TRANSFORM_OT_translate={"value":(0,0,0), "orient_type":'NORMAL'})

            # set pivot point around 3D cursor
            bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'

            # rotate the currently selected items - the group of diameter floorplates
            bpy.ops.transform.rotate(value=radians(rot_angle), orient_axis='Y', orient_type='NORMAL')

            #return {'FINISHED'}


            # cycle through all currently selected objects (should be newly created object)
            for obj in bpy.context.selected_objects:
                # add the current object name to the total floor object count object names & list
                obj_list_floor.append(obj.name)

             # Deselect all objects in the scene
        bpy.ops.object.select_all(action='DESELECT')
        
        
        #return {'FINISHED'}
   
        
            
        # prepare for next ring of rotation if required
        if d < (int(mytool.my_int_diam / 2) - 1):
            # select the ref object
            ref_obj.select_set(True)       
            #return {'FINISHED'}

            # copy it
            bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'},
            TRANSFORM_OT_translate={"value":(0,0,0), "orient_type":'NORMAL'})

            # cycle through all currently selected objects (should be newly created object)
            for obj in bpy.context.selected_objects:
                # add the current object name to the total floor object count object names & list
                obj_list_floor.append(obj.name)
            
            # move it full plate width over
            z_move = std_floor_width * obj.scale[2] * (d + 1)

            # set the actual object to world coordinates
            SetWorldLocation(obj, 0, 0, -z_move)
   
            

    # cycle through all floor objects and select them
    # and select the objects 
    for i, obj_name in enumerate(obj_list_floor):
        obj = bpy.data.objects[obj_name]
        obj.select_set(True)       
    
    # Save the total floor plates used before we cut out the centres
    total_floorplates = len(obj_list_floor)
    
    # call the remove centres routine
    RemoveNonSymCentres()            
            

    #return {'FINISHED'}
   

    # ====================  Copy Along Y-Axis for floors (NORMAL orintation =============================
    # cycle through the Y list objects
    
    if mytool.my_int_floors > 1 :
        for floors in range(mytool.my_int_floors - 1) :

            # adjustment values of new direction distance (based on NORMAL orientation)
            y_move = std_floor_height * obj.scale[1] * mytool.my_int_wall_height

            # copy the currently selected objects, (not the active object, unless it also is selected) with no translation
            # copies of original selected items are created, with the newly created objects now being
            # the newly selected objects 
            bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'},
            TRANSFORM_OT_translate={"value":(0,0,0), "orient_type":'NORMAL'})


            # cycle through all selected objects and apply translation
            for obj in bpy.context.selected_objects:
                # set the actual object to world coordinates
                SetWorldLocation(obj, 0, y_move, 0)
                # add the current object name to the total floor object count object names & list
                obj_list_floor.append(obj.name)


    # calculate the centre piece offset from floor to floor
    centre_offset = total_floorplates
    
    # increment the floor piece count
    total_floorplates *= mytool.my_int_floors
   
    # cycle through all floor objects and select them
    for i, obj_name in enumerate(obj_list_floor):
        # do boolean check to see if object exists
        found = obj_list_floor[i] in bpy.data.objects
        if found:
            obj = bpy.data.objects[obj_list_floor[i]]
            obj.select_set(True)
   
    # if odd number of diameter floorplates & no centres are being removed
    # deselect the centre pieces, to facilitate diameter adjustment
    if not even_diam and mytool.my_int_centres_to_remove == 0:
        for i in range(0, total_floorplates, centre_offset):
            # do boolean check to see if object exists
            found = obj_list_floor[i] in bpy.data.objects
            if found:
                obj = bpy.data.objects[obj_list_floor[i]]
                obj.select_set(False)
                            
    
    # adjust default size adjust based on size of circle
    if mytool.my_int_diam > 10:
        mytool.my_float_round_adjust = 0.25
    else:
        mytool.my_float_round_adjust = 0.10






# Optimized round floors creation routine for Symmetrical layout
# This operator is code that runs when a user clicks on the "Create" button in the 
# "Floor Creator" menu, under the "Build Round Floors" menu item, to build round floor arrangements
def CreateSymOptoRound():

    scene = bpy.context.scene
    mytool = scene.my_tool

    # to initialize lists 
    del obj_listy[:] 
    del obj_list_floor[:]


    # get the currently active object (should also be the selected)
    obj = bpy.context.object

    # get the currently selected object
    if obj : 
        # add the currently selected object to the list
        obj_listy.append(obj.name)
        # add the current object name to the total floor object count object names & list
        obj_list_floor.append(obj.name)
        
    else :
        ShowMessageBox("Please choose a floor object!", "Floor Creator Error", 'ERROR')
        return {'FINISHED'}


    #record the scale
    y_scale = obj.scale[1]
    
    # select object, it if it isn't already
    obj.select_set(True) 

    # place the 3D cursor to the centre of our currently selected object(s)
    bpy.ops.view3d.snap_cursor_to_selected()        
    
    # save the location vector of the 3D cursor centre of rotation
    mytool.my_floatvect_rad = obj.location  


    # make sure diameter is min=2
    if mytool.my_int_diam < 2:
       mytool.my_int_diam = 2
    

    #return {'FINISHED'}    

    # ====================  Copy Along Z-Axis (NORMAL orientation =============================

        
    # Check if object diameter count is even
    even_diam = ((mytool.my_int_diam % 2) == 0)

    # calculate the z move
    z_move = 0
    if even_diam:
        z_move = -std_floor_width * obj.scale[2] * 0.5
        
        
    # set the actual object to world coordinates
    SetWorldLocation(obj, 0, 0, z_move)

    #return {'FINISHED'}    
    

    # adjustment values of new direction distance (based on NORMAL orientation)
    z_move = -std_floor_width * obj.scale[2]

    # determine number of loops to execute for radius build
    if even_diam:
        
        no_loops = int(mytool.my_int_diam / 2) - 1
    else:
        no_loops = int(mytool.my_int_diam / 2)
   
        
    # Loop for length
    # cycle through a single row of Z-axis (NORMAL orientation) objects (max 10 diameter)
    for i in range(no_loops) :
        # copy the currently selected item in place
        bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'},
        TRANSFORM_OT_translate={"value":(0,0,0), "orient_type":'NORMAL'})
        
        # get the current object
        obj = bpy.context.object                       

        # set the actual object to world coordinates
        SetWorldLocation(obj, 0, 0, z_move)

        # add the currently selected object to the list
        obj_listy.append(obj.name)
        # add the current object name to the total floor object count object names & list
        obj_list_floor.append(obj.name)
        

    # cycle through a single row of Z-axis (NORMAL orientation) objects
    # and select the objects 
    for i, obj_name in enumerate(obj_listy):
        obj = bpy.data.objects[obj_name]
        obj.select_set(True)       
    

    
    # ====================  Duplicate & Rotate around the Y-Axis (NORMAL orientation =============================

    # set pivot point around 3D cursor
    bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'

    # get the final number of sides that are needed
    final_sides = round_sides[mytool.my_int_diam - 2]
    
    # calculate the real angle needed for a reasonable smooth curve, based on number of sides
    acurate_angle = 360 / round_sides[mytool.my_int_diam - 2]
    
    # for each diameter section...
    for x in range((int(final_sides) - 1)) :
 
        # copy the currently selected objects, (not the active object, unless it also is selected) with no translation
        # copies of original selected items are created, with the newly created objects now being
        # the newly selected objects 
        bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'},
        TRANSFORM_OT_translate={"value":(0,0,0), "orient_type":'NORMAL'})


        # rotate the currently selected items - the group of diameter floorplates
        bpy.ops.transform.rotate(value=radians(acurate_angle), orient_axis='Y', orient_type='NORMAL')

        # cycle through all selected objects and add to complete floor objects list
        for obj in bpy.context.selected_objects:
            # add the current object name to the total floor object count object names & list
            obj_list_floor.append(obj.name)

    # cycle through all current floor objects
    # and select the objects 
    for i in range(len(obj_list_floor)) :
        # check for existence of list item in objects
        found = obj_list_floor[i] in bpy.data.objects
        if found:
            obj = bpy.context.scene.objects[obj_list_floor[i]]
            # select the object
            obj.select_set(True)       


    # call the routine to manage centres to remove
    RemoveSymCentres()

    # ====================  Start of Optimization before floor copying  =============================

    # no opto for 2 diameter
    if mytool.my_int_diam == 2:
        return {'FINISHED'}
        
    
    # ---------------- First centre section optimization for all diameters
    # reduces centre to 1 flooplate for odd numbers, and optimize for even
    if even_diam:
        start_idx = int(mytool.my_int_diam / 2)
        for i in range(start_idx, len(obj_list_floor) - 1, mytool.my_int_diam):
            # here is where we delete the floors
            found = obj_list_floor[i] in bpy.data.objects
            if found:
                obj = bpy.data.objects[obj_list_floor[i]]
                bpy.data.objects.remove(obj, do_unlink=True)
    
    # Odd diameter
    else:
        start_idx = int(mytool.my_int_diam / 2) + 1
        for i in range(start_idx, len(obj_list_floor) - 1, int((mytool.my_int_diam + 1) / 2)):
            # here is where we delete the floors
            found = obj_list_floor[i] in bpy.data.objects
            if found:
                obj = bpy.data.objects[obj_list_floor[i]]
                bpy.data.objects.remove(obj, do_unlink=True)

    # ---------------- First centre section optimization for diameters over 7, for even diameters only
    # only for diameters over 6
    if mytool.my_int_diam > 7:
        if even_diam:
            start_idx = mytool.my_int_diam
            for i in range(start_idx, len(obj_list_floor) - 1, mytool.my_int_diam * 2):
                # here is where we delete the floors
                found = obj_list_floor[i] in bpy.data.objects
                if found:
                    obj = bpy.data.objects[obj_list_floor[i]]
                    bpy.data.objects.remove(obj, do_unlink=True)


    if mytool.my_int_diam >= 16:
        if even_diam:
            start_idx = int(mytool.my_int_diam * 2)
            for i in range(start_idx, len(obj_list_floor) - 1, mytool.my_int_diam * 4):
                # here is where we delete the floors
                found = obj_list_floor[i] in bpy.data.objects
                if found:
                    obj = bpy.data.objects[obj_list_floor[i]]
                    bpy.data.objects.remove(obj, do_unlink=True)
    
    
    # ---------------- First Phase of 2nd centre section optimization
    # only for diameters over 6
    if mytool.my_int_diam > 6:
        if even_diam:
            start_idx = int(mytool.my_int_diam / 2) + 1
            for i in range(start_idx, len(obj_list_floor) - 1, mytool.my_int_diam):
                # here is where we delete the floors
                found = obj_list_floor[i] in bpy.data.objects
                if found:
                    obj = bpy.data.objects[obj_list_floor[i]]
                    bpy.data.objects.remove(obj, do_unlink=True)
        # Odd diameter
        else:
            start_idx = int(mytool.my_int_diam / 2) + 2
            for i in range(start_idx, len(obj_list_floor) - 1, mytool.my_int_diam + 1):
                # here is where we delete the floors
                found = obj_list_floor[i] in bpy.data.objects
                if found:
                    obj = bpy.data.objects[obj_list_floor[i]]
                    bpy.data.objects.remove(obj, do_unlink=True)

    
    # ---------------- 2nd Phase of 2nd centre section optimization
    if mytool.my_int_diam > 11:
        if even_diam:
            if mytool.my_int_diam > 15:
                start_idx = mytool.my_int_diam + 1
                for i in range(start_idx, len(obj_list_floor) - 1, mytool.my_int_diam * 2):
                    # here is where we delete the floors
                    found = obj_list_floor[i] in bpy.data.objects
                    if found:
                        obj = bpy.data.objects[obj_list_floor[i]]
                        bpy.data.objects.remove(obj, do_unlink=True)
            # Odd diameter
        else:
            start_idx = mytool.my_int_diam + 2
            for i in range(start_idx, len(obj_list_floor) - 1, (mytool.my_int_diam * 2) + 2):
                # here is where we delete the floors
                found = obj_list_floor[i] in bpy.data.objects
                if found:
                    obj = bpy.data.objects[obj_list_floor[i]]
                    bpy.data.objects.remove(obj, do_unlink=True)

            if mytool.my_int_diam == 17:
                # special circumstance
                found = obj_list_floor[469] in bpy.data.objects
                if found:
                    obj = bpy.data.objects[obj_list_floor[469]]
                    bpy.data.objects.remove(obj, do_unlink=True)


    # ---------------- 1st Phase of 3rd centre section optimization
    # only for diameters 11, 13 and beyond?
    if mytool.my_int_diam > 10:
        if even_diam:
            # works for 12 & 14
            start_idx = int(mytool.my_int_diam / 2)  + 2
            for i in range(start_idx, len(obj_list_floor) - 1, mytool.my_int_diam):
                # here is where we delete the floors
                found = obj_list_floor[i] in bpy.data.objects
                if found:
                    obj = bpy.data.objects[obj_list_floor[i]]
                    bpy.data.objects.remove(obj, do_unlink=True)
        else:
            # works for 11, 13
            start_idx = int(mytool.my_int_diam / 2) + 3
            for i in range(start_idx, len(obj_list_floor) - 1, mytool.my_int_diam + 1):
                # here is where we delete the floors
                found = obj_list_floor[i] in bpy.data.objects
                if found:
                    obj = bpy.data.objects[obj_list_floor[i]]
                    bpy.data.objects.remove(obj, do_unlink=True)


    # ----------------   Start of 1st phase of 4th row section optimization
    if mytool.my_int_diam > 14:
        if even_diam:
            start_idx = int(mytool.my_int_diam / 2) + 3
            for i in range(start_idx, len(obj_list_floor) - 1, mytool.my_int_diam):
                # here is where we delete the floors
                found = obj_list_floor[i] in bpy.data.objects
                if found:
                    obj = bpy.data.objects[obj_list_floor[i]]
                    bpy.data.objects.remove(obj, do_unlink=True)
        # Odd diameter
        else:
            start_idx = int(mytool.my_int_diam / 2) + 4
            for i in range(start_idx, len(obj_list_floor) - 1, mytool.my_int_diam + 1):
                # here is where we delete the floors
                found = obj_list_floor[i] in bpy.data.objects
                if found:
                    obj = bpy.data.objects[obj_list_floor[i]]
                    bpy.data.objects.remove(obj, do_unlink=True)


    # ----------------   Start of 1st phase of 5th row section optimization
    if mytool.my_int_diam == 20:
        if even_diam:
            start_idx = int(mytool.my_int_diam / 2) + 4
            for i in range(start_idx, len(obj_list_floor) - 1, mytool.my_int_diam):
                # here is where we delete the floors
                found = obj_list_floor[i] in bpy.data.objects
                if found:
                    obj = bpy.data.objects[obj_list_floor[i]]
                    bpy.data.objects.remove(obj, do_unlink=True)



    #return {'FINISHED'}

    # get the currently active object (should also be the selected)
    obj = bpy.context.object


   
    # ====================  Copy Along Y-Axis for floors (NORMAL orientation =============================
    # cycle through the Y list objects
    
    if mytool.my_int_floors > 1 :
        for floors in range(mytool.my_int_floors - 1) :

            # adjustment values of new direction distance (based on NORMAL orientation)
            y_move = std_floor_height * y_scale * mytool.my_int_wall_height

            # copy the currently selected objects, (not the active object, unless it also is selected) with no translation
            # copies of original selected items are created, with the newly created objects now being
            # the newly selected objects 
            bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'},
            TRANSFORM_OT_translate={"value":(0,0,0), "orient_type":'NORMAL'})


            # cycle through all selected objects and apply translation
            for obj in bpy.context.selected_objects:
                # set the actual object to world coordinates
                SetWorldLocation(obj, 0, y_move, 0)
                # add the current object name to the total floor object count object names & list
                obj_list_floor.append(obj.name)

    # cycle through all current floor objects
    # and select the objects 
    for i in range(len(obj_list_floor)) :
        # check for existence of list item in objects
        found = obj_list_floor[i] in bpy.data.objects
        if found:
            obj = bpy.context.scene.objects[obj_list_floor[i]]
            # select the object
            obj.select_set(True)       

    if mytool.my_int_diam > 10:
        mytool.my_float_round_adjust = 0.25
    else:
        mytool.my_float_round_adjust = 0.10
        



# Round floors creation routine for Symmetrical layout - no optimization (very wasteful on resources,
# but looks cool.
# This operator is code that runs when a user clicks on the "Create" button in the 
# "Floor Creator" menu, under the "Build Round Floors" menu item, to build round floor arrangements
def CreateRound():

    scene = bpy.context.scene
    mytool = scene.my_tool

    # to initialize lists 
    del obj_listy[:] 
    del obj_list_floor[:]


    # get the currently active object (should also be the selected)
    obj = bpy.context.object


    # get the currently selected object
    if obj : 
        # add the currently selected object to the list
        obj_listy.append(obj.name)
        # add the current object name to the total floor object count object names & list
        obj_list_floor.append(obj.name)
        
    else :
        ShowMessageBox("Please choose a floor object!", "Floor Creator Error", 'ERROR')
        return {'FINISHED'}
    
    # select object, it if it isn't already
    obj.select_set(True) 

    # place the 3D cursor to the centre of our currently selected object(s)
    bpy.ops.view3d.snap_cursor_to_selected()        
    
    # save the location vector of the 3D cursor centre of rotation
    mytool.my_floatvect_rad = obj.location  


    # make sure diameter is min=2
    if mytool.my_int_diam < 2:
       mytool.my_int_diam = 2
    

    #return {'FINISHED'}    

    # ====================  Copy Along Z-Axis (NORMAL orientation =============================

        
    # Check if object diameter count is even
    even_diam = ((mytool.my_int_diam % 2) == 0)

    # calculate the z move
    z_move = 0
    if even_diam:
        z_move = -std_floor_width * obj.scale[2] * 0.5
        
        
    # set the actual object to world coordinates
    SetWorldLocation(obj, 0, 0, z_move)

    #return {'FINISHED'}    
    

    # adjustment values of new direction distance (based on NORMAL orientation)
    z_move = -std_floor_width * obj.scale[2]

    # determine number of loops to execute for radius build
    if even_diam:
        no_loops = int(mytool.my_int_diam / 2) - 1
    else:
        no_loops = int(mytool.my_int_diam / 2)
   
        
    # Loop for length
    # cycle through a single row of Z-axis (NORMAL orientation) objects (max 10 diameter)
    for i in range(no_loops) :
        # copy the currently selected item in place
        bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'},
        TRANSFORM_OT_translate={"value":(0,0,0), "orient_type":'NORMAL'})
        
        # get the current object
        obj = bpy.context.object                       

        # set the actual object to world coordinates
        SetWorldLocation(obj, 0, 0, z_move)

        # add the currently selected object to the list
        obj_listy.append(obj.name)
        # add the current object name to the total floor object count object names & list
        obj_list_floor.append(obj.name)
        
            

    # cycle through a single row of Z-axis (NORMAL orientation) objects
    # and select the objects 
    for i, obj_name in enumerate(obj_listy):
        obj = bpy.data.objects[obj_name]
        obj.select_set(True)       
    

    
    # ====================  Duplicate & Rotate around the Y-Axis (NORMAL orientation =============================

    # set pivot point around 3D cursor
    bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'

    # get the final number of sides that are needed
    final_sides = round_sides[mytool.my_int_diam - 2]
    
    # calculate the real angle needed for a reasonable smooth curve, based on number of sides
    acurate_angle = 360 / round_sides[mytool.my_int_diam - 2]
    
    # for each diameter section...
    for x in range((int(final_sides) - 1)) :
 
        # copy the currently selected objects, (not the active object, unless it also is selected) with no translation
        # copies of original selected items are created, with the newly created objects now being
        # the newly selected objects 
        bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'},
        TRANSFORM_OT_translate={"value":(0,0,0), "orient_type":'NORMAL'})


        # rotate the currently selected items - the group of diameter floorplates
        bpy.ops.transform.rotate(value=radians(acurate_angle), orient_axis='Y', orient_type='NORMAL')

        # cycle through all selected objects and add to complete floor objects list
        for obj in bpy.context.selected_objects:
            # add the current object name to the total floor object count object names & list
            obj_list_floor.append(obj.name)

    # cycle through all current floor objects
    # and select the objects 
    for i in range(len(obj_list_floor)) :
        # check for existence of list item in objects
        found = obj_list_floor[i] in bpy.data.objects
        if found:
            obj = bpy.context.scene.objects[obj_list_floor[i]]
            # select the object
            obj.select_set(True)       


    # call the routine to manage centres to remove
    RemoveSymCentres()



   
    # ====================  Copy Along Y-Axis for floors (NORMAL orientation =============================
    # cycle through the Y list objects
    
    if mytool.my_int_floors > 1 :
        for floors in range(mytool.my_int_floors - 1) :

            # adjustment values of new direction distance (based on NORMAL orientation)
            y_move = std_floor_height * obj.scale[1] * mytool.my_int_wall_height

            # copy the currently selected objects, (not the active object, unless it also is selected) with no translation
            # copies of original selected items are created, with the newly created objects now being
            # the newly selected objects 
            bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'},
            TRANSFORM_OT_translate={"value":(0,0,0), "orient_type":'NORMAL'})


            # cycle through all selected objects and apply translation
            for obj in bpy.context.selected_objects:
                # set the actual object to world coordinates
                SetWorldLocation(obj, 0, y_move, 0)
                # add the current object name to the total floor object count object names & list
                obj_list_floor.append(obj.name)


    # cycle through all current floor objects
    # and select the objects 
    for i in range(len(obj_list_floor)) :
        # check for existence of list item in objects
        found = obj_list_floor[i] in bpy.data.objects
        if found:
            obj = bpy.context.scene.objects[obj_list_floor[i]]
            # select the object
            obj.select_set(True)       

    if mytool.my_int_diam > 10:
        mytool.my_float_round_adjust = 0.25
    else:
        mytool.my_float_round_adjust = 0.10
        
       
 

# Square floors creation routine 
# This operator is code that runs when a user clicks on the "Create" button in the 
# "Floor Creator" menu, under the "Build Square Floors" menu item, to build square floor arrangements
def CreateSquare():

    scene = bpy.context.scene
    mytool = scene.my_tool

    # to initialize empty lists 
    del obj_listy[:]
    del obj_list_floor[:]

    # get the currently active object (should also be the selected)
    obj = bpy.context.object

    # get the currently selected object
    if obj : 
        # add the currently selected object to the list
        obj_listy.append(obj.name)
        # add the current object name to the total floor object count object names & list
        obj_list_floor.append(obj.name)
        
    else :
        ShowMessageBox("Please choose a floor object!", "Floor Creator Error", 'ERROR')
        return {'FINISHED'}
    
    #return {'FINISHED'}    

    # move original object to bottom left of square floor size so
    # entire structure is centred at 0,0
    x_move = -(mytool.my_int_width - 1) * std_floor_width * obj.scale[2] * 0.5
    y_move = 0
    z_move = (mytool.my_int_length - 1) * std_floor_width * obj.scale[2] * 0.5
    
    # set the actual object to world coordinates
    SetWorldLocation(obj, x_move, y_move, z_move)
    
    #return {'FINISHED'}
    

    # ====================  Copy Along Z-Axis (NORMAL orientation =============================

    # adjustment values of new direction distance (based on NORMAL orientation)
    z_move = -std_floor_width * obj.scale[2]

    # Loop for length
    # cycle through a single row of Z-axis (NORMAL orientation) objects 
    for i in range(mytool.my_int_length - 1) :
        # copy the currently selected object with no translation
        # copies of original selected items are created, with the newly created objects now being
        # the newly selected objects 
        bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'},
        TRANSFORM_OT_translate={"value":(0,0,0), "orient_type":'NORMAL'})


        # cycle through all selected objects and apply translation
        for obj in bpy.context.selected_objects:
            # set the actual object to world coordinates
            SetWorldLocation(obj, 0, 0, z_move)
        
            # add the currently selected object to the list
            obj_listy.append(obj.name)
            # add the current object name to the total floor object count object names & list
            obj_list_floor.append(obj.name)

    
    # cycle through a single row of Z-axis (NORMAL orientation) objects
    # and select the objects 
    for i in range(mytool.my_int_length - 1) :
        # get the object
        obj = bpy.context.scene.objects[obj_listy[i]]
        # select the object
        obj.select_set(True)       

    #return {'FINISHED'}
     
    
    # ====================  Copy Along X-Axis (NORMAL orientation =============================
    
    # now we need to copy the length of floors to width 
    # for each width value...
    for x in range(mytool.my_int_width - 1) :
 
        # adjustment values of new direction distance (based on NORMAL orientation)
        x_move = std_floor_width * obj.scale[0]
 
        # copy the currently selected object with no translation
        # copies of original selected items are created, with the newly created objects now being
        # the newly selected objects 
        bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'},
        TRANSFORM_OT_translate={"value":(0,0,0), "orient_type":'NORMAL'})


        # cycle through all selected objects and apply translation
        for obj in bpy.context.selected_objects:
            # set the actual object to world coordinates
            SetWorldLocation(obj, x_move, 0, 0)
        
            # add the current object name to the total floor object count object names & list
            obj_list_floor.append(obj.name)
 
    # cycle through all current floor objects
    # and select the objects 
    for i in range((mytool.my_int_length * mytool.my_int_width) - 1) :
        # get the object
        obj = bpy.context.scene.objects[obj_list_floor[i]]
        # select the object
        obj.select_set(True)       

    #return {'FINISHED'}
    
    # ====================  Copy Along Y-Axis for floors (NORMAL orientation =============================
    # cycle through the Y list objects
    
    if mytool.my_int_floors > 1 :
        for floors in range(mytool.my_int_floors - 1) :
            # adjustment values of new direction distance (based on NORMAL orientation)
            y_move = std_floor_height * obj.scale[1] * mytool.my_int_wall_height

            # copy the currently selected object with no translation
            # copies of original selected items are created, with the newly created objects now being
            # the newly selected objects 
            bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'},
            TRANSFORM_OT_translate={"value":(0,0,0), "orient_type":'NORMAL'})


            # cycle through all selected objects and apply translation
            for obj in bpy.context.selected_objects:
                # set the actual object to world coordinates
                SetWorldLocation(obj, 0, y_move, 0)


    # Deselect all objects in the scene
    bpy.ops.object.select_all(action='DESELECT')
       
   

