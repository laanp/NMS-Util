import bpy
from mathutils import Vector, Matrix



# ======================================== Custom Class PropertyGroup Definitions =======================================================

def CopyObj(obj):
    # copy the active object - same as SHIFT+D
    newobj = obj.copy()
    newobj.data = obj.data.copy() # Omit if you want a linked object.
    # add to collection
    bpy.context.collection.objects.link(newobj)
    # new object will get all same info as active object, including if it's selected
    # unselect the new object
    newobj.select_set(False)      
    return newobj



def ObjReplacement():
# routine to mass replace active object with selected objects, including scale, rotation & location to all selected objects    

    scene = bpy.context.scene
    mytool = scene.my_tool
    first_move_done = False

    # get active object    
    obj = bpy.context.object                       

    # apply active object rotation matrix to selected objects
    # Cycle through All selected objects 
    for sel in bpy.context.selected_objects :     
        # as long as selected isn't the active
        if sel.name != obj.name :
            # copy the active object
            newobj = CopyObj(obj)            
            
            # apply rotation to new object, of the current selected object
            newobj.rotation_euler = sel.rotation_euler

            # apply scale if applicable
            if mytool.my_bool_attr_sca :
                newobj.scale = sel.scale                           

            # move the new object to the currently selected object location
            newobj.location = sel.location
    
    # unselect the active object
    obj.select_set(False)      
    
    # delete all selected objects
    bpy.ops.object.delete(use_global=False, confirm=False)

    # return after looping    
    return {'FINISHED'}

