import bpy
import bmesh
from mathutils import Vector, Matrix
from math import pi, tan, atan, ceil, floor, radians, degrees, modf


# Global Arrays
align_objs = []     # List of currently selected items
align_locs = []     # List of currently selected item location vectors


 # This is a message display routine 
def ShowMessageBox(message = "", title = "Message Box", icon = 'INFO'):

    def draw(self, context):
        self.layout.label(text=message)

    bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)


def CopyObj(obj):
    # copy the active object - same as SHIFT+D
    newobj = obj.copy()
    newobj.data = obj.data.copy() # Omit if you want a linked object.
    # add to collection
    bpy.context.collection.objects.link(newobj)
    # new object will get all same info as active object, including if it's selected
    # unselect the new object
    newobj.select_set(False)      
    return newobj


def ObjMan():
# routine to copy active objects scale, rotation & location to all selected objects    

    scene = bpy.context.scene
    mytool = scene.my_tool
    first_move_done = False

    # lit of selected object names
    sel_objs = []
    del sel_objs[:]
    
    # get active object    
    obj = bpy.context.object                       

    # get the currently selected object
    if not obj : 
        ShowMessageBox("Please choose a an active object!", "Object Manipulation Error", 'ERROR')
        return {'FINISHED'}

    # check if at least 2 objects selected (at least the active and 1 more selected
    if len(bpy.context.selected_objects) <= 1:
        ShowMessageBox("Please choose at least 2 objects!", "Object Manipulation Error", 'ERROR')
        return {'FINISHED'}

    
    # apply active object rotation matrix to selected objects
    # Cycle through All selected objects 
    for sel in bpy.context.selected_objects :     
        # as long as selected isn't the active
        if sel.name != obj.name :
            # add the selected object to our list
            #sel_objs.append(sel.name)    

                    
            #check if move/copy from selected to Active required 
            if mytool.my_bool_attr_loc:
                # check if it's a move
                if mytool.my_enum_action == 'OP2' :
                    if mytool.my_bool_loc:
                        # Active ----> Selected
                        if not first_move_done:
                            obj.location = sel.location
                            first_move_done = True
                    else:                            
                        # Selected ----> Active
                        sel.location = obj.location
                else:  # it's a copy
                    if mytool.my_bool_loc:
                        # Active ----> Selected
                        # copy the Active object and assign to newobj
                        newobj = CopyObj(obj)
                        # move the new object to the current selection
                        newobj.location = sel.location
                    else:                            
                        # Selected ----> Active
                        # copy the Active object and assign to newobj
                        newobj = CopyObj(sel)
                        # move the new object to the Active object location
                        newobj.location = obj.location
                    # rotation and scale dealt with differently if copying or moving
                     # check if rotation needed
                    if mytool.my_bool_attr_rot:
                        # perform rotation, based on direction
                        if mytool.my_bool_rot:
                            # Active ----> Selected
                            newobj.rotation_euler = obj.rotation_euler
                        else:                            
                            # Selected ----> Active
                            newobj.rotation_euler = sel.rotation_euler
                    if mytool.my_bool_attr_sca:
                        # perform scale, based on direction
                        if mytool.my_bool_sca:
                            # Active ----> Selected
                            newobj.scale = obj.scale
                        else:                            
                            # Selected ----> Active
                            newobj.scale = sel.scale

            else:
                # rotation and scale dealt with differently if copying or moving
                 # check if rotation needed
                if mytool.my_bool_attr_rot:
                    # perform rotation, based on direction
                    if mytool.my_bool_rot:
                        # Active ----> Selected
                        sel.rotation_euler = obj.rotation_euler
                    else:                            
                        # Selected ----> Active
                        obj.rotation_euler = sel.rotation_euler
                if mytool.my_bool_attr_sca:
                    # perform scale, based on direction
                    if mytool.my_bool_sca:
                        # Active ----> Selected
                        sel.scale = obj.scale
                    else:                            
                        # Selected ----> Active
                        obj.scale = sel.scale



    # return after looping    
    return {'FINISHED'}


# routine to clear selected rotation or scale attributes from objects
# routine runs when user clicks on "Clear" button on the panel
def ClearAttr():

    scene = bpy.context.scene
    mytool = scene.my_tool

    # get active object    
    obj = bpy.context.object                       

    # get the currently selected object
    if not obj : 
        ShowMessageBox("Please choose a an active object!", "Object Manipulation Error", 'ERROR')
        return {'FINISHED'}

    # check if at least 1 objects selected (at least the active selected
    if len(bpy.context.selected_objects) == 0:
        ShowMessageBox("Please choose at least 1 object!", "Object Manipulation Error", 'ERROR')
        return {'FINISHED'}


    # Cycle through All selected objects 
    for sel in bpy.context.selected_objects :     

        if mytool.my_bool_clrattr_rot:
            # clear rotation of selected object 
            sel.rotation_euler = [radians(90),0,0]

        if mytool.my_bool_clrattr_sca:
            # clear scale of selected object 
            sel.scale = [1,1,1]





def AlignObjects():
    
    scene = bpy.context.scene
    mytool = scene.my_tool

    # get active object    
    obj = bpy.context.object                       

    # get the currently selected object
    if not obj : 
        ShowMessageBox("Please choose a an active object!", "Object Manipulation Error", 'ERROR')
        return {'FINISHED'}

    # check if at least 1 objects selected (at least the active selected
    if len(bpy.context.selected_objects) == 0:
        ShowMessageBox("Please choose at least 1 object!", "Object Manipulation Error", 'ERROR')
        return {'FINISHED'}

    # check if align mode = Active selected, and the active object is not in the current selection 
    if mytool.my_enum_alignto == 'OPT_4':
        if obj not in bpy.context.selected_objects:
            # active object not selected, select it...
            obj.select_set(True)

    # save the selected items position if the selection has changed
    if SelectionChanged():
        SaveAlignObjectPositions()    
        
    if not mytool.my_bool_xalign and not mytool.my_bool_yalign and not mytool.my_bool_zalign:
        RecallAlignObjectPositions()    
        return {'FINISHED'}

    # initially recall the saved positions
    RecallAlignObjectPositions()    

    # perform alignments based on which checkboxes selected
    if mytool.my_bool_xalign and not mytool.my_bool_yalign and not mytool.my_bool_zalign:
        bpy.ops.object.align(align_mode=mytool.my_enum_alignmode, relative_to=mytool.my_enum_alignto, align_axis={'X'})
        return {'FINISHED'}
    
    if not mytool.my_bool_xalign and mytool.my_bool_yalign and not mytool.my_bool_zalign:
        bpy.ops.object.align(align_mode=mytool.my_enum_alignmode, relative_to=mytool.my_enum_alignto, align_axis={'Y'})
        return {'FINISHED'}
    
    
    if not mytool.my_bool_xalign and not mytool.my_bool_yalign and mytool.my_bool_zalign:
        bpy.ops.object.align(align_mode=mytool.my_enum_alignmode, relative_to=mytool.my_enum_alignto, align_axis={'Z'})
        return {'FINISHED'}
    
    if mytool.my_bool_xalign and mytool.my_bool_yalign and not mytool.my_bool_zalign:
        bpy.ops.object.align(align_mode=mytool.my_enum_alignmode, relative_to=mytool.my_enum_alignto, align_axis={'X', 'Y'})
        return {'FINISHED'}
    
    if mytool.my_bool_xalign and not mytool.my_bool_yalign and mytool.my_bool_zalign:
        bpy.ops.object.align(align_mode=mytool.my_enum_alignmode, relative_to=mytool.my_enum_alignto, align_axis={'X', 'Z'})
        return {'FINISHED'}

    if mytool.my_bool_xalign and mytool.my_bool_yalign and mytool.my_bool_zalign:
        bpy.ops.object.align(align_mode=mytool.my_enum_alignmode, relative_to=mytool.my_enum_alignto, align_axis={'X', 'Y', 'Z'})
        return {'FINISHED'}
    
    if not mytool.my_bool_xalign and mytool.my_bool_yalign and mytool.my_bool_zalign:
        bpy.ops.object.align(align_mode=mytool.my_enum_alignmode, relative_to=mytool.my_enum_alignto, align_axis={'Y', 'Z'})
        return {'FINISHED'}
    


# routine to save original objects selected locations
def SaveAlignObjectPositions():

    scene = bpy.context.scene
    mytool = scene.my_tool

    # clear lidt of selected object names
    del align_objs[:]
    # clear list of selected object vector locations
    del align_locs[:]

    # Cycle through All selected objects 
    for sel in bpy.context.selected_objects :     
        align_objs.append(sel.name)
        align_locs.append(sel.location.copy())    




# routine to recall original objects selected locations
def RecallAlignObjectPositions():

    scene = bpy.context.scene
    mytool = scene.my_tool

    # loop through all object names in a list
    for i, obj_name in enumerate(align_objs):
        
        # check if object exists in all the objects 
        found = obj_name in bpy.data.objects
        if found:
            obj = bpy.data.objects[obj_name]
            # recall it's position.append
            obj.location = align_locs[i]
 


def SelectionChanged():
    
    scene = bpy.context.scene
    mytool = scene.my_tool

    # check if array has not been initialized 
    if len(align_objs) == 0:
        return True

    # check if number of selected objects is different than array length
    if len(align_objs) != len(bpy.context.selected_objects):
        return True

    # reset selected items index
    sel_index = 0
        
    # Cycle through All selected objects 
    for sel in bpy.context.selected_objects :     
        # check if selection object name is different from the stored selection at the index
        if sel.name != align_objs[sel_index]:
            return True
        # increment the selection index 
        sel_index += 1
        
    return False





def AttachFaces():
# routine to move an object to another object via selected faces
# routine works by selected 2 objects, then going into edit mode and selecting the source face first,
# followed by the destination face, and then running this routine

# Error checking prior to running this routine should look for only 2 selected objects

    scene = bpy.context.scene
    mytool = scene.my_tool

    # save transform & pivot point settings
    transformtype = bpy.context.scene.transform_orientation_slots[0].type
    pivotpoint = bpy.context.scene.tool_settings.transform_pivot_point

    # get active object, (the destination object)    
    A = bpy.context.object                       

    # get the currently selected object
    if not A : 
        ShowMessageBox("Please choose at least 2 objects!", "Object Manipulation Error", 'ERROR')
        return {'FINISHED'}

    # check if at least 2 objects selected (at least the active selected)
    if len(bpy.context.selected_objects) <= 1:
        ShowMessageBox("Please choose at least 2 objects!", "Object Manipulation Error", 'ERROR')
        return {'FINISHED'}

    # check if at least 2 objects selected (at least the active selected)
    if len(bpy.context.selected_objects) > 2:
        ShowMessageBox("Please choose only 2 objects!", "Object Manipulation Error", 'ERROR')
        return {'FINISHED'}

    # assign B = the object moving, make sure it's the other selected object
    if bpy.context.selected_objects[0].name == A.name:
        B = bpy.context.selected_objects[1]  
    else:
        B = bpy.context.selected_objects[0]  

    # get the scale of the moving object
    s = B.scale.copy()

    # get data from destination object
    src_mw = A.matrix_world.copy()
    src_bm = bmesh.from_edit_mesh(A.data)
    #src_face = src_bm.select_history.active   # last selected
    src_face = src_bm.faces.active
    
    
    # check if face selected in destination object
    if not src_face:
        ShowMessageBox("Please choose face on object to move!", "Object Manipulation Error", 'ERROR')
        return {'FINISHED'}
    
    src_o = src_face.calc_center_median()
    src_normal = src_face.normal
    src_tan = src_face.calc_tangent_edge()

    # calculation of where we want the 3D cursor & set it
    bpy.context.scene.cursor.location = src_mw @ src_o

    # This is the moving object, incorporate scale when copying matrix
    dst_mwu = B.matrix_world.copy()
    dst_scale = dst_mwu.Scale(s[0],4)
    dst_mw = dst_mwu @ dst_scale
    dst_bm = bmesh.from_edit_mesh(B.data)
    dst_face = dst_bm.select_history.active
    dst_o = dst_face.calc_center_median()
    # change the sign of normal to stick face to face
    dst_normal = -(dst_face.normal)
    dst_tan = (dst_face.calc_tangent_edge())

    vec2 = src_normal @ src_mw.inverted()
    matrix_rotate = dst_normal.rotation_difference(vec2).to_matrix().to_4x4()

    vec1 = src_tan @ src_mw.inverted()
    dst_tan = dst_tan @ matrix_rotate.inverted()
    mat_tmp = dst_tan.rotation_difference(vec1).to_matrix().to_4x4()
    matrix_rotate = mat_tmp @ matrix_rotate
    matrix_translation = Matrix.Translation(src_mw @ src_o)
    
    # This line applied the matrix_translation and matrix_rotate
    B.matrix_world = matrix_translation @ matrix_rotate.to_4x4()

    # We need to recalculate these value since we change the matrix_world
    dst_mwu = B.matrix_world.copy()
    dst_scale = dst_mwu.Scale(s[0],4)
    dst_mw = dst_mwu @ dst_scale

    dst_bm = bmesh.from_edit_mesh(B.data)
    dst_face = dst_bm.select_history.active
    dst_o = dst_face.calc_center_median()


    # The following is telling blender to find a translation from face center to origin,
    # And than apply it on world matrix 
    # Be Careful, the order of the matrix multiplication change the result,
    # We always put the transform matrix on "Left Hand Side" to perform the task
    dif_mat = Matrix.Translation(B.location - dst_mw @ dst_o)
    B.matrix_world = dif_mat @ B.matrix_world
    
    # deselect the destination object   
    A.select_set(state=False)

    # make the moving object , the active object
    bpy.context.view_layer.objects.active = B    
    
    # set pivot point to 3D cursor
    bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'
    
    # place 3D window in object mode
    bpy.ops.object.mode_set(mode='OBJECT')
    
    # resize the moving object (which is the default selected object in the scene at the moment)
    bpy.ops.transform.resize(value=s)

    # switch back to original transform
    bpy.context.scene.transform_orientation_slots[0].type = transformtype
    #switch back to original pivot
    bpy.context.scene.tool_settings.transform_pivot_point = pivotpoint



def AttachAllFaces():
# routine to move an object to another object via selected faces
# routine works by selected 2 objects, then going into edit mode and selecting the source face first,
# followed by the destination face, and then running this routine

# Error checking prior to running this routine should look for only 2 selected objects

    scene = bpy.context.scene
    mytool = scene.my_tool

    # a list of moved objects
    movedobjs = []


    # get active object, (the destination object)    
    A = bpy.context.object                       

    # get the currently selected object
    if not A : 
        ShowMessageBox("Please choose at least 2 objects!", "Object Manipulation Error", 'ERROR')
        return {'FINISHED'}

    # check if at least 2 objects selected (at least the active selected)
    if len(bpy.context.selected_objects) <= 1:
        ShowMessageBox("Please choose at least 2 objects!", "Object Manipulation Error", 'ERROR')
        return {'FINISHED'}

    # check if at least 2 objects selected (at least the active selected)
    if len(bpy.context.selected_objects) > 2:
        ShowMessageBox("Please choose only 2 objects!", "Object Manipulation Error", 'ERROR')
        return {'FINISHED'}

    
    # assign B = the object moving, make sure it's the other selected object
    if bpy.context.selected_objects[0].name == A.name:
        B = bpy.context.selected_objects[1]  
    else:
        B = bpy.context.selected_objects[0]  
        
    # check which mode we are in
    if bpy.context.object.mode == "EDIT":
        # place 3D window in object mode
        bpy.ops.object.mode_set(mode='OBJECT')

    # get the mesh objects from the destination object
    bm = bmesh.new()
    bm.from_mesh(A.data)
    
    
    
    #select all faces if All = True
    if mytool.my_bool_allfaces == True:
        for face in bm.faces:
            face.select = True
        
    #cycle through all faces and check if selected face
    for i,f in enumerate(bm.faces):
        if f.select:
            
            # change the active face
            A.data.polygons.active = i
            
            # place 3D window in object mode
            #bpy.ops.object.mode_set(mode='OBJECT')
            # deselect the original move object
            B.select_set(state=False)
                 
            # copy the object we are moving, this will be the new moving object
            newobj = B.copy()
            newobj.data = B.data.copy()
            # add to current collection
            bpy.context.collection.objects.link(newobj)
            # add the new obj to our list, to select all of them later
            movedobjs.append(newobj)
            
            # select the copy, which will move to destination
            newobj.select_set(state=True)

            # place 3D window back in edit mode
            bpy.ops.object.mode_set(mode='EDIT')
            
            # attach the faces of the selected objects
            AttachFaces()
            
            # reselect the active object, the destination object 
            A.select_set(state=True)
            bpy.context.view_layer.objects.active = A
            # deselect the recently moved
            newobj.select_set(state=False)
            # reselect the original 
            B.select_set(state=True)

    bm.free()
    del bm

    # remove original moving object
    # delete the object
    bpy.data.objects.remove(B, do_unlink=True)
    
    #Select the moved objects
    for obj in movedobjs:
        # select the object
        obj.select_set(state=True)
    # unselect the destination
    A.select_set(state=False)
    
    # switch to LOCAL transform
    bpy.context.scene.transform_orientation_slots[0].type = 'LOCAL'
    #switch to individual Origins pivot
    bpy.context.scene.tool_settings.transform_pivot_point = 'INDIVIDUAL_ORIGINS' 






