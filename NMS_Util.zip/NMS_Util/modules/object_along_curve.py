import bpy
from mathutils import Vector, Matrix
from math import pi, tan, atan, ceil, floor, radians, degrees, modf


# ======================================== Global List =======================================================

oac_list = []


# ======================================== Custom Functions =======================================================


 # This is a message display routine 
def ShowMessageBox(message = "", title = "Message Box", icon = 'INFO'):

    def draw(self, context):
        self.layout.label(text=message)

    bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)


def CopyObj(obj):
    # copy the active object - same as SHIFT+D
    newobj = obj.copy()
    newobj.data = obj.data.copy() # Omit if you want a linked object.
    # add to collection
    bpy.context.collection.objects.link(newobj)
    # new object will get all same info as active object, including if it's selected
    # unselect the new object
    newobj.select_set(False)      
    return newobj



# routine to calculate the lenth of a curve
# copies the curve, converts to a mesh and counts edge lengths, deleting the resulting 
# copied mesh
def get_length(curve):

    # check for curve type
    if curve.type != 'CURVE':
        print(curve.type)    
        return 0.0

    # store the original active object
    active_obj = bpy.context.view_layer.objects.active

    # store all selected objects
    objs = bpy.context.selected_objects    
    

    # copy the active object - same as SHIFT+D
    newobj = curve.copy()
    newobj.data = curve.data.copy() # Omit if you want a linked object.
    # add to collection
    bpy.context.collection.objects.link(newobj)

    # Deselect all objects in the scene
    bpy.ops.object.select_all(action='DESELECT')


    # make the new curve active object
    bpy.context.view_layer.objects.active = newobj
    # select it
    newobj.select_set(True)      
    
    # the duplicate is active, apply all transforms to get global coordinates
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
    
    # convert to mesh
    bpy.ops.object.convert(target='MESH', keep_original=False)
    # store all object data
    _data = bpy.context.active_object.data
    

    # traverse the mesh edges
    edge_length = 0
    for edge in _data.edges:
        vert0 = _data.vertices[edge.vertices[0]].co
        vert1 = _data.vertices[edge.vertices[1]].co
        edge_length += (vert0-vert1).length
    
    # deal with trailing float smear
    #edge_length = '{:.6f}'.format(edge_length)
    
    # delete the copied curve turned into mesh object
    bpy.ops.object.delete()
    
    # restore the original active object
    bpy.context.view_layer.objects.active = active_obj

    for obj in objs:
        # select it
        obj.select_set(True)      
            
    return edge_length


def AddFirstConstraint(obj, curve):

    # move a copy of the active object to the curve start        
    # get a copy of the object first
    newobj = CopyObj(obj)
    # clear rotation of new object from curve
    newobj.rotation_euler = [0,0,0]
    # set location of new object at 0
    newobj.location = [0,0,0]
    
    # Create constraint properties.
    constraint = newobj.constraints.new(type='FOLLOW_PATH')
    constraint.target = bpy.data.objects[curve.name]
    constraint.use_fixed_location = True
    constraint.use_curve_follow = True
    constraint.offset_factor = 0

    return newobj


def AddAllConstraints(obj, curve):

    # adjust gap distance based on object width
    gap_distance = 1 / (curve_length / obj.width)    

    # initialize percentage_count (distance along curve 0 - 1)
    percentage_count = 0.0
   
    # adjust gap distance based on object width
    gap_distance = 1 / (curve_length / obj.width)    
    
    while percentage_count <= 1.0:
        percentage_count += gap_distance

        # move a copy of the active object to the curve start        
        # get a copy of the object first
        newobj = CopyObj(obj)
        # clear rotation of new object from curve
        newobj.rotation_euler = [0,0,0]
        # set location of new object at 0
        newobj.location = [0,0,0]
        
        # Create constraint properties.
        constraint = newobj.constraints.new(type='FOLLOW_PATH')
        constraint.target = bpy.data.objects[curve.name]
        constraint.use_fixed_location = True
        constraint.use_curve_follow = True
        constraint.offset_factor = percentage_count

    
# routine to return the location matrix of the start of curve object passed
def GetStartOfCurve(curve):

    # transform the mesh using the matrix world
    curve.data.transform(curve.matrix_world)
    # then reset matrix to identity
    curve.matrix_world = Matrix()        
    
    
    # make the non curve object active object
    # to get the spline data of the object curve
    spline_data = curve.data.splines
    # to access all the bezier points on the first spline
    bp = spline_data[0].bezier_points
    # to access the first control point on the first spline of the bezier curve
    cp = bp[0]
    # return location
    return cp.co




# this routine will delete all the objects along a curve
def DeleteObjectsAlongCurve():
    
    scene = bpy.context.scene
    mytool = scene.my_tool
    
    # get active object    
    obj = bpy.context.object                       

    # check if at least 1 object selected
    if len(bpy.context.selected_objects) == 0:
        return

    # set curve_name
    curve_name = ""

    # check if currently selected object has a constraint associated with it
    # make sure it's currently an object constrained along a curve
    if obj:
        for name, con in obj.constraints.items():
            if con.type == "FOLLOW_PATH":
                # get the name of the curve associated with this constraint
                curve_name = con.target
                #print("Found Constraints with curve")    
            else:
                # exit if constraint is not a curve
                return
            
        # exit if no curve name found
        if curve_name == "":
            return
    
        # if we found an existing list
        if len(oac_list) > 1:
            # found a list of constrained items
            first_object_on_curve =  bpy.data.objects[oac_list[0]]
            for name, con in first_object_on_curve.constraints.items():
                if con.type == "FOLLOW_PATH":
                    # get the name of the curve associated with this constraint
                    if curve_name == con.target:
                        # found the right curve associated with the selected object in our list
                        #delete all objects in the list
                        for i, obj_name in enumerate(oac_list):
                            # skip if first item
                            if i > 0:
                                # check if object name at index i in the list, exists in the current objects 
                                found = oac_list[i] in bpy.data.objects
                                if found:
                                    o = bpy.data.objects[obj_name]
                                    # delete the object
                                    bpy.data.objects.remove(o, do_unlink=True)
                            else:
                                # check if object name at index i in the list, exists in the current objects 
                                found = oac_list[i] in bpy.data.objects
                                if found:
                                    o = bpy.data.objects[obj_name]
                                    # add the object to the current selection
                                    o.select_set(True)
                                    # Set the active object to a specific object in the scene
                                    bpy.context.view_layer.objects.active = o          # Make obj the active object (does not select)
                                                                        

                    else:
                        # no current list, but let's find all the objects associated with this curve and delete them
                        # except the first one
                        # Cycle through All objects (preferred)
                        for o in bpy.data.objects :                  
                            for name, con in o.constraints.items():
                                if con.type == "FOLLOW_PATH":
                                    # get the name of the curve associated with this constraint
                                    if curve_name == con.target:
                                        # delete the object, as long as it's not the first one
                                        if con.offset_factor != 0:
                                            bpy.data.objects.remove(o, do_unlink=True)
                                        else:
                                            # add the object to the current selection
                                            o.select_set(True)
                                            # Set the active object to a specific object in the scene
                                            bpy.context.view_layer.objects.active = o          # Make obj the active object (does not select)

        else:
            # no current list, but let's find all the objects associated with this curve and delete them
            # except the first one
            # Cycle through All objects (preferred)
            for o in bpy.data.objects :                  
                for name, con in o.constraints.items():
                    if con.type == "FOLLOW_PATH":
                        # get the name of the curve associated with this constraint
                        if curve_name == con.target:
                            # delete the object, as long as it's not the first one
                            if con.offset_factor != 0:
                                bpy.data.objects.remove(o, do_unlink=True)
                            else:
                                # add the object to the current selection
                                o.select_set(True)
                                # Set the active object to a specific object in the scene
                                bpy.context.view_layer.objects.active = o          # Make obj the active object (does not select)
        
                

def SetupObjectOnCurve():
# routine to setup the object along curve

    scene = bpy.context.scene
    mytool = scene.my_tool

    # delete any additional objects (reset)            
    DeleteObjectsAlongCurve()

    # clear the oac_list
    del oac_list[:]

    
    # get active object    
    obj = bpy.context.object                       

    # initialize a curve name
    curve_name = ""
    

    # get the currently selected object
    if not obj : 
        ShowMessageBox("Please choose a curve and 1 active object only!", "NMS Util Error", 'ERROR')
        return {'FINISHED'}

    # check if object already has a constraint (setup won't be needed)
    if obj.constraints.items():
        # get the curve name
        for name, con in obj.constraints.items():
            if con.type == "FOLLOW_PATH":
                # get the name of the curve associated with this constraint
                curve_name = con.target.name
                curve = bpy.data.objects[curve_name]
        
                # initialize the offset to the object width initially
                # get length of curve
                mytool.my_float_curve_length = get_length(curve)

                # initialize the offset to the object width initially
                mytool.my_float_oac_offset = 1 / (mytool.my_float_curve_length / obj.dimensions.x)

                # add the first object to the list
                oac_list.append(obj.name)

                return {'FINISHED'}


    # check if at least 2 objects selected (at least the active and 1 more selected
    if len(bpy.context.selected_objects) <= 1:
        ShowMessageBox("Please choose a curve and 1 active object only!", "NMS Util Error", 'ERROR')
        return {'FINISHED'}

    # check if only 2 objects selected
    if len(bpy.context.selected_objects) > 2:
        ShowMessageBox("Please choose a curve and 1 active object only!", "NMS Util Error", 'ERROR')
        return {'FINISHED'}



    # check that at least one object of selected objects is a curve
    for sel in bpy.context.selected_objects :     
        # check for curve type
        if sel.type == 'CURVE':
            # assign to curve
            curve = sel
            curve_name = curve.name
        else:
            obj = sel    


    # check if curve was initialized
    if curve_name == "":
        ShowMessageBox("No curve found with selected objects!", "NMS Util Error", 'ERROR')
        return {'FINISHED'}


    # Set the active object to other object than the curve
    bpy.context.view_layer.objects.active = obj          # Make obj the active object (does not select)

    # when we get to here, obj = active object we want to copy along curve, and curve = the curve object


    # get length of curve
    mytool.my_float_curve_length = get_length(curve)

    # initialize the offset to the object width initially
    mytool.my_float_oac_offset = 1 / (mytool.my_float_curve_length / obj.dimensions.x)
    
    # add constraint to a new first object along curve
    newobj = AddFirstConstraint(obj, curve)

    # add the first object to the list
    oac_list.append(newobj.name)


    # Unselect curve
    curve.select_set(False)      
        
    # Unselect object
    obj.select_set(False)      

    # set the new object as the active
    bpy.context.view_layer.objects.active = newobj          # Make obj the active object (does not select)

    # Select the new object
    newobj.select_set(True)      
    
    

# routine to copy all the obects along the curve
def CreateObjectsOnCurve():

    scene = bpy.context.scene
    mytool = scene.my_tool

    # get active object    
    obj = bpy.context.object                       


    # make sure it's currently an object constrained along a curve
    if obj:
        for name, con in obj.constraints.items():
            if con.type != "FOLLOW_PATH":
                ShowMessageBox("Please choose an active object on a curve!", "NMS Util Error", 'ERROR')
                return {'FINISHED'}
            else:
                # store curve name
                curve_obj = con.target 
                # check if item selected is first object in list, if not exit
                if obj.name != oac_list[0]:
                    # redo setup if different curve than list
                    SetupObjectOnCurve()

                    # get active object    
                    obj = bpy.context.object                       
        
        if not obj.constraints.items():
            return
                
    # clear the oac_list
    del oac_list[:]

    # add the object to the objects list
    oac_list.append(obj.name)

    # applies transform active, apply all transforms to get global coordinates
    #bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    
    # get length of curve
    mytool.my_float_curve_length = get_length(curve_obj)
    
    # adjust gap distance based on object width
    gap_distance = mytool.my_float_oac_offset    


    # calculate next location on curve
    percent_along_curve = 0.0
    percent_along_curve += gap_distance

   
   # loop while we are not completed the curve
    while percent_along_curve <= 1.0:
   
        # get active object    
        obj = bpy.context.object                       

        
        # get a copy of the object first
        newobj = CopyObj(obj)

        # select it
        newobj.select_set(True)      

        # set the new object as the active
        bpy.context.view_layer.objects.active = newobj          # Make obj the active object (does not select)
            
        # unselect original object
        obj.select_set(False)      
        
        
        # set new object 
        newobj.constraints["Follow Path"].offset_factor = obj.constraints["Follow Path"].offset_factor + gap_distance

        # find next spot along curve
        percent_along_curve += gap_distance

        # add the object to the objects list
        oac_list.append(newobj.name)
        


def OAC_INAdjust():

    scene = bpy.context.scene
    mytool = scene.my_tool

    # delete existing objects along curve
    DeleteObjectsAlongCurve()

    # adjust the spacing by increments
    mytool.my_float_oac_offset -= (mytool.my_float_oac_adjoffset / 100) 
    mytool.my_float_oac_offset = max(0.005, mytool.my_float_oac_offset)
    
    # create the objects along the curve
    CreateObjectsOnCurve()
      



def OAC_OUTAdjust():
    scene = bpy.context.scene
    mytool = scene.my_tool

    # delete existing objects along curve
    DeleteObjectsAlongCurve()

    # adjust the spacing by increments (within reason)
    mytool.my_float_oac_offset += (mytool.my_float_oac_adjoffset / 100) 
    mytool.my_float_oac_offset = min(100, mytool.my_float_oac_offset)
    
    
    # create the objects along the curve
    CreateObjectsOnCurve()


def OAC_Adjust():
    scene = bpy.context.scene
    mytool = scene.my_tool

    # delete existing objects along curve
    DeleteObjectsAlongCurve()
    
    # create the objects along the curve
    CreateObjectsOnCurve()
    




