import bpy
from mathutils import Vector, Matrix
from math import pi, tan, atan, ceil, floor, radians, degrees, modf


# ======================================== Global List =======================================================


# ======================================== Custom Functions =======================================================


 # This is a message display routine 
def ShowMessageBox(message = "", title = "Message Box", icon = 'INFO'):

    def draw(self, context):
        self.layout.label(text=message)

    bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)


def CopyObj(obj):
    # copy the active object - same as SHIFT+D
    newobj = obj.copy()
    newobj.data = obj.data.copy() # Omit if you want a linked object.
    # add to collection
    bpy.context.collection.objects.link(newobj)
    # new object will get all same info as active object, including if it's selected
    # unselect the new object
    newobj.select_set(False)      
    return newobj



# routine to calculate the lenth of a curve
# copies the curve, converts to a mesh and counts edge lengths, deleting the resulting 
# copied mesh
def get_length(curve):

    # check for curve type
    if curve.type != 'CURVE':
        print(curve.type)    
        return 0.0

    # store the original active object
    active_obj = bpy.context.view_layer.objects.active

    # store all selected objects
    objs = bpy.context.selected_objects    
    

    # copy the active object - same as SHIFT+D
    newobj = curve.copy()
    newobj.data = curve.data.copy() # Omit if you want a linked object.
    # add to collection
    bpy.context.collection.objects.link(newobj)

    # Deselect all objects in the scene
    bpy.ops.object.select_all(action='DESELECT')


    # make the new curve active object
    bpy.context.view_layer.objects.active = newobj
    # select it
    newobj.select_set(True)      
    
    # the duplicate is active, apply all transforms to get global coordinates
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
    
    # convert to mesh
    bpy.ops.object.convert(target='MESH', keep_original=False)
    # store all object data
    _data = bpy.context.active_object.data
    

    # traverse the mesh edges
    edge_length = 0
    for edge in _data.edges:
        vert0 = _data.vertices[edge.vertices[0]].co
        vert1 = _data.vertices[edge.vertices[1]].co
        edge_length += (vert0-vert1).length
    
    # deal with trailing float smear
    #edge_length = '{:.6f}'.format(edge_length)
    
    # delete the copied curve turned into mesh object
    bpy.ops.object.delete()
    
    # restore the original active object
    bpy.context.view_layer.objects.active = active_obj

    for obj in objs:
        # select it
        obj.select_set(True)      
            
    return edge_length


def AddFirstConstraint(obj, curve):

    # move a copy of the active object to the curve start        
    # get a copy of the object first
    newobj = CopyObj(obj)
    # clear rotation of new object from curve
    newobj.rotation_euler = [0,0,0]
    # set location of new object at 0
    newobj.location = [0,0,0]
    
    # Create constraint properties.
    constraint = newobj.constraints.new(type='FOLLOW_PATH')
    constraint.target = bpy.data.objects[curve.name]
    constraint.use_fixed_location = True
    constraint.use_curve_follow = True
    constraint.offset_factor = 0

    return newobj


def AddAllConstraints(obj, curve):

    # adjust gap distance based on object width
    gap_distance = 1 / (curve_length / obj.width)    

    # initialize percentage_count (distance along curve 0 - 1)
    percentage_count = 0.0
   
    # adjust gap distance based on object width
    gap_distance = 1 / (curve_length / obj.width)    
    
    while percentage_count <= 1.0:
        percentage_count += gap_distance

        # move a copy of the active object to the curve start        
        # get a copy of the object first
        newobj = CopyObj(obj)
        # clear rotation of new object from curve
        newobj.rotation_euler = [0,0,0]
        # set location of new object at 0
        newobj.location = [0,0,0]
        
        # Create constraint properties.
        constraint = newobj.constraints.new(type='FOLLOW_PATH')
        constraint.target = bpy.data.objects[curve.name]
        constraint.use_fixed_location = True
        constraint.use_curve_follow = True
        constraint.offset_factor = percentage_count

    

def SelectAllonCurve():
# this routine will select all objects on a curve (but not the curve itself)
# the currently selected object can be a constrained object along a curve, or the curve itself
# routine will do nothing if no object selected or object is not associated with a curve
    scene = bpy.context.scene
    mytool = scene.my_tool
    
    # get first selected object, exit if none selected    
    if len(bpy.context.selected_objects):
        obj = bpy.context.selected_objects[0]                       
    else:
        ShowMessageBox("No Objects Selected!", "NMS Util Error", 'ERROR')
        return {'FINISHED'}
    
    # init curve_name
    curve_name = ""

    # check if obj is curve type
    if obj.type == 'CURVE':
        # assign to curve
        curve = obj
        curve_name = curve.name
        #unselect the curve
        curve.select_set(False)
        

    else:  # object is not a curve
        # cycle through the object constraints to find the curve associated with it
        for name, con in obj.constraints.items():
            if con.type == "FOLLOW_PATH":
                # get the curve and the name of the curve associated with this constraint
                curve = con.target
                curve_name = con.target.name
    
    # exit if no curve name found
    if curve_name == "":
        ShowMessageBox("No Curve Found!", "NMS Util Error", 'ERROR')
        return {'FINISHED'}

    # Deselect all objects in the scene
    bpy.ops.object.select_all(action='DESELECT')
        
    # Cycle through All objects in the scene,
    for o in bpy.data.objects :                  
        # check for all objects with constraints
        for name, con in o.constraints.items():
            # for those with a constraint, check the name matches our curve
            if con.type == "FOLLOW_PATH":
                # check the name of the curve associated with this constraint, matches our curve
                if curve_name == con.target.name:
                    # add the object to the current selection
                    o.select_set(True)
    return  


def SelectCurve():
# this routine will select a curve object associated with the currently select object.
# the currently selected object must be a constrained object along a curve, or the curve itself.
# routine will do nothing if no object selected or object is not associated with a curve
    scene = bpy.context.scene
    mytool = scene.my_tool
    
    # get first selected object, exit if none selected    
    if len(bpy.context.selected_objects):
        obj = bpy.context.selected_objects[0]                       
    else:
        ShowMessageBox("No Objects Selected!", "NMS Util Error", 'ERROR')
        return {'FINISHED'}
    
    # init curve_name
    curve_name = ""

    # check if obj is curve type
    if obj.type == 'CURVE':
        # assign to curve
        curve = obj
        curve_name = curve.name
    else:  # object is not a curve
        # cycle through the object constraints to find the curve associated with it
        for name, con in obj.constraints.items():
            if con.type == "FOLLOW_PATH":
                # get the curve and the name of the curve associated with this constraint
                curve = con.target
                curve_name = con.target.name
    
    # exit if no curve name found
    if curve_name == "":
        ShowMessageBox("No Curve Found!", "NMS Util Error", 'ERROR')
        return {'FINISHED'}

    # Deselect all objects in the scene
    bpy.ops.object.select_all(action='DESELECT')
    # select only the curve
    curve.select_set(True)
    
    # set the active object in the scene to the object (does not select)
    bpy.context.view_layer.objects.active = curve          

    return      




# this routine will delete all the objects along a curve
# it will operate on the first object of any selected objects, or failing that
# it will use the active object
def DeleteObjectsAlongCurve():
    
    scene = bpy.context.scene
    mytool = scene.my_tool

    # get the first selected object
    if len(bpy.context.selected_objects):
        obj = bpy.context.selected_objects[0]
    else:
        # Assign a variable to the Active object (may be selected or not!)
        obj = bpy.context.object                       

    # initialize variables
    curve_name = ""
    

    # exit if no active object
    if not obj : 
        return
    
    # check for object that does not have a constraint curve - this will be our object!
    for sel in bpy.context.selected_objects :     
        # check if item has constraints
        if sel.constraints.items():
            # cycle through all constraint items
            for name, con in sel.constraints.items():
                # if the constraint item is a curve
                if con.type == "FOLLOW_PATH":
                    # get the name of the curve associated with this constraint
                    curve_name = con.target.name
        else:   # no constraints (could be a plain object or curve) 
            # check for which one is the curve type
            if sel.type == 'CURVE':
                curve = sel
                curve_name = curve.name
            
    # check if curve was found in selected items
    if curve_name == "":
        return

    # Cycle through all scene objects 
    for o in bpy.data.objects :                  
        for name, con in o.constraints.items():
            if con.type == "FOLLOW_PATH":
                # get the name of the curve associated with this constraint
                if curve_name == con.target.name:
                    # delete the object
                    bpy.data.objects.remove(o, do_unlink=True)

  
    

# routine to copy all the obects along the curve
def CreateObjectsOnCurve():

    scene = bpy.context.scene
    mytool = scene.my_tool

    # get the first selected object
    if len(bpy.context.selected_objects):
        obj = bpy.context.selected_objects[0]
    else:
        # Assign a variable to the Active object (may be selected or not!)
        obj = bpy.context.object                       

    
    # initialize variables
    curve_name = ""
    foundobj = False

    # exit if no active object
    if not obj : 
        ShowMessageBox("Please choose a curve and 1 active object only!", "NMS Util Error", 'ERROR')
        return {'FINISHED'}

    # check if at least 2 objects selected (at least the active and 1 more selected
    if len(bpy.context.selected_objects) <= 1:
        ShowMessageBox("Please choose a curve and 1 active object only!", "NMS Util Error", 'ERROR')
        return {'FINISHED'}

    # check if only 2 objects selected
    if len(bpy.context.selected_objects) > 2:
        ShowMessageBox("Please choose a curve and 1 active object only!", "NMS Util Error", 'ERROR')
        return {'FINISHED'}
        
    # check for object that does not have a constraint curve - this will be our object!
    for sel in bpy.context.selected_objects :     
        # check if item has constraints
        if sel.constraints.items():
            # cycle through all constraint items
            for name, con in sel.constraints.items():
                # if the constraint item is a curve
                if con.type == "FOLLOW_PATH":
                    # check if curve_name hasn't already been assigned...
                    if curve_name == "":
                        # get the name of the curve associated with this constraint
                        curve_name = con.target.name
                    else:
                        ShowMessageBox("Both objects have associated curves!", "NMS Util Error", 'ERROR')
                        return {'FINISHED'}
        else:   # no constraints (could be a plain object or curve) 
            # check for which one is the curve type
            if sel.type == 'CURVE':
                # check if curve_name hasn't already been assigned...
                if curve_name == "":
                    curve = sel
                    curve_name = curve.name
                else:
                    ShowMessageBox("Both objects have associated curves!", "NMS Util Error", 'ERROR')
                    return {'FINISHED'}
            else:
                # found object
                obj = sel
                foundobj = True


    if not foundobj:
        ShowMessageBox("Please choose at least one object that does not have a curve associated with it!", "NMS Util Error", 'ERROR')
        return {'FINISHED'}

  
    if obj.name == curve_name:
        ShowMessageBox("Both objects have same curve!", "NMS Util Error", 'ERROR')
        return {'FINISHED'}


    # check if curve was found in selected items
    if curve_name == "":
        ShowMessageBox("Please choose a curve and 1 active object only!", "NMS Util Error", 'ERROR')
        return {'FINISHED'}


    # delete any additional objects (reset)            
    DeleteObjectsAlongCurve()

    # get the name of the curve associated with this constraint
    curve = bpy.data.objects[curve_name]

    # initialize the offset to the object width initially
    # get length of curve
    mytool.my_float_curve_length = get_length(curve)

    # initialize the offset to the object width initially
    mytool.my_float_oac_offset = 1 / (mytool.my_float_curve_length / obj.dimensions.x)

    # add constraint to a new first object along curve
    newobj = AddFirstConstraint(obj, curve)

    # Deselect all objects in the scene
    bpy.ops.object.select_all(action='DESELECT')

    # set the new object as the active
    bpy.context.view_layer.objects.active = curve          # Make obj the active object (does not select)

    #select the curve
    curve.select_set(True)      
    
    #goto Edit mode
    # switch to Edit mode
    bpy.ops.object.mode_set(mode='EDIT')
    # switch to Object mode
    bpy.ops.object.mode_set(mode='OBJECT')
    
    # Deselect all objects in the scene
    bpy.ops.object.select_all(action='DESELECT')

    # set the new object as the active
    bpy.context.view_layer.objects.active = newobj          # Make obj the active object (does not select)

    # Select the new object
    newobj.select_set(True)     


  
    

    # =================  Start of create along curve section ===============================

    
    # adjust gap distance based on object width
    gap_distance = mytool.my_float_oac_offset    


    # calculate next location on curve
    percent_along_curve = 0.0
    percent_along_curve += gap_distance

   
   # loop while we are not completed the curve
    while percent_along_curve <= 1.0:
   
        # get active object    
        obj = bpy.context.object                       

        
        # get a copy of the object first
        newobj = CopyObj(obj)

        # select it
        newobj.select_set(True)      

        # set the new object as the active
        bpy.context.view_layer.objects.active = newobj          # Make obj the active object (does not select)
            
        # unselect original object
        obj.select_set(False)      
        
        # set new object 
        newobj.constraints["Follow Path"].offset_factor = obj.constraints["Follow Path"].offset_factor + gap_distance

        # find next spot along curve
        percent_along_curve += gap_distance

    # select all objects
    SelectAllonCurve()      


def AdjustObjectsAlongCurve():
# routine called when user clicks on << or >> buttons to redistribute distances
# between onjects along the curve
    
    scene = bpy.context.scene
    mytool = scene.my_tool

    # get the first selected object
    if len(bpy.context.selected_objects):
        obj = bpy.context.selected_objects[0]
    else:
        # Assign a variable to the Active object (may be selected or not!)
        obj = bpy.context.object                       

    # initialize variables
    curve_name = ""
    

    # exit if no active object
    if not obj : 
        return
    
    # check for object that does not have a constraint curve - this will be our object!
    for sel in bpy.context.selected_objects :     
        # check if item has constraints
        if sel.constraints.items():
            # cycle through all constraint items
            for name, con in sel.constraints.items():
                # if the constraint item is a curve
                if con.type == "FOLLOW_PATH":
                    # get the name of the curve associated with this constraint
                    curve_name = con.target.name
        else:   # no constraints (could be a plain object or curve) 
            # check for which one is the curve type
            if sel.type == 'CURVE':
                curve = sel
                curve_name = curve.name
            
    # check if curve was found in selected items
    if curve_name == "":
        return

    # Cycle through all scene objects & delete all except first on on the curve
    for o in bpy.data.objects :                  
        for name, con in o.constraints.items():
            if con.type == "FOLLOW_PATH":
                # get the name of the curve associated with this constraint
                if curve_name == con.target.name:
                    # delete the object if offset <> 0 (not the first item)
                    if o.constraints["Follow Path"].offset_factor != 0:
                        bpy.data.objects.remove(o, do_unlink=True)
                    else:
                        # select the first one
                        o.select_set(True) 
                        # set the new object as the active
                        bpy.context.view_layer.objects.active = o         
                        
    
    # adjust gap distance based on object width
    gap_distance = mytool.my_float_oac_offset    

    # calculate next location on curve
    percent_along_curve = 0.0
    percent_along_curve += gap_distance

   
   # loop while we are not completed the curve
    while percent_along_curve <= 1.0:
   
        # get active object    
        obj = bpy.context.object                       

        
        # get a copy of the object first
        newobj = CopyObj(obj)

        # select it
        newobj.select_set(True)      

        # set the new object as the active
        bpy.context.view_layer.objects.active = newobj          # Make obj the active object (does not select)
            
        # unselect original object
        obj.select_set(False)      
        
        
        # set new object 
        newobj.constraints["Follow Path"].offset_factor = obj.constraints["Follow Path"].offset_factor + gap_distance

        # find next spot along curve
        percent_along_curve += gap_distance

    # select all objects
    SelectAllonCurve()      



def OAC_INAdjust():

    scene = bpy.context.scene
    mytool = scene.my_tool

    # adjust the spacing by increments
    mytool.my_float_oac_offset -= (mytool.my_float_oac_adjoffset / 100) 
    mytool.my_float_oac_offset = max(0.005, mytool.my_float_oac_offset)
    
    # adjust the objects along the curve
    AdjustObjectsAlongCurve()  



def OAC_OUTAdjust():
    scene = bpy.context.scene
    mytool = scene.my_tool

    # adjust the spacing by increments (within reason)
    mytool.my_float_oac_offset += (mytool.my_float_oac_adjoffset / 100) 
    mytool.my_float_oac_offset = min(100, mytool.my_float_oac_offset)
    
    # adjust the objects along the curve
    AdjustObjectsAlongCurve()  



def OAC_Adjust():
    scene = bpy.context.scene
    mytool = scene.my_tool

    # adjust the objects along the curve
    AdjustObjectsAlongCurve()  
    

# This operator is the main code that runs when a user clicks on the "X-Axis" button in the 
# various panel menu, under the "Object Orientation in Circle" section, to 
# adjust the X-Axis rotation, of the reference object, in custom or predefined rotation increments.  
def FlipX():

    scene = bpy.context.scene
    mytool = scene.my_tool

    if len(bpy.context.selected_objects) == 0:
        ShowMessageBox("Please choose an object!", "NMS Util Error", 'ERROR')
        return {'FINISHED'}

    # initialize angle of rotation
    rot_angle = 90

    if mytool.my_bool_90_flip and not mytool.my_bool_custom_rot:
        rot_angle = 90
    if not mytool.my_bool_90_flip and not mytool.my_bool_custom_rot:
        rot_angle = 45
    if mytool.my_bool_custom_rot:
        rot_angle = mytool.my_float_cust_rot

    #store all objects currently selected
    objs = bpy.context.selected_objects

    # Deselect all objects in the scene
    bpy.ops.object.select_all(action='DESELECT')

    for obj in objs:
        #select the object
        obj.select_set(True)
        # rotate the active item
        
        # set the object to the active object
        bpy.context.view_layer.objects.active = obj
        bpy.ops.transform.rotate(value=radians(rot_angle), orient_axis='X', orient_type='LOCAL')
        #Unselect the object
        obj.select_set(False)
     
    # Reselect all objects in the scene originally selected
    for obj in objs:
        #select the object
        obj.select_set(True)
        

# This operator is the main code that runs when a user clicks on the "Y-Axis" button in the 
# "Object Circle Creator" Panel" menu, under the "Object Orientation in Circle" section, to 
# adjust the Y-Axis rotation of the reference object, in custom or predefined rotation increments.  
def FlipY():

    scene = bpy.context.scene
    mytool = scene.my_tool

    if len(bpy.context.selected_objects) == 0:
        ShowMessageBox("Please choose an object!", "NMS Util Error", 'ERROR')
        return {'FINISHED'}
    
    # initialize angle of rotation
    rot_angle = 90

    if mytool.my_bool_90_flip and not mytool.my_bool_custom_rot:
        rot_angle = 90
    if not mytool.my_bool_90_flip and not mytool.my_bool_custom_rot:
        rot_angle = 45
    if mytool.my_bool_custom_rot:
        rot_angle = mytool.my_float_cust_rot

    #store all objects currently selected
    objs = bpy.context.selected_objects

    # Deselect all objects in the scene
    bpy.ops.object.select_all(action='DESELECT')

    for obj in objs:
        #select the object
        obj.select_set(True)
        # rotate the active item
        
        # set the object to the active object
        bpy.context.view_layer.objects.active = obj
        bpy.ops.transform.rotate(value=radians(rot_angle), orient_axis='Y', orient_type='LOCAL')
        #Unselect the object
        obj.select_set(False)
     
    # Reselect all objects in the scene originally selected
    for obj in objs:
        #select the object
        obj.select_set(True)



# This operator is the main code that runs when a user clicks on the "Z-Axis" button in the 
# "Object Circle Creator" Panel" menu, under the "Object Orientation in Circle" section, to 
# adjust the Z-Axis rotation of the reference object, in custom or predefined rotation increments.  
def FlipZ():

    scene = bpy.context.scene
    mytool = scene.my_tool

    if len(bpy.context.selected_objects) == 0:
        ShowMessageBox("Please choose an object!", "NMS Util Error", 'ERROR')
        return {'FINISHED'}
    
    # initialize angle of rotation
    rot_angle = 90

    if mytool.my_bool_90_flip and not mytool.my_bool_custom_rot:
        rot_angle = 90
    if not mytool.my_bool_90_flip and not mytool.my_bool_custom_rot:
        rot_angle = 45
    if mytool.my_bool_custom_rot:
        rot_angle = mytool.my_float_cust_rot

    #store all objects currently selected
    objs = bpy.context.selected_objects

    # Deselect all objects in the scene
    bpy.ops.object.select_all(action='DESELECT')

    for obj in objs:
        #select the object
        obj.select_set(True)
        # rotate the active item
        
        # set the object to the active object
        bpy.context.view_layer.objects.active = obj
        bpy.ops.transform.rotate(value=radians(rot_angle), orient_axis='Z', orient_type='LOCAL')
        #Unselect the object
        obj.select_set(False)
     
    # Reselect all objects in the scene originally selected
    for obj in objs:
        #select the object
        obj.select_set(True)



def CreateSpiralVertex():
    # make mesh
    vertices = [(0, 0, 0),]
    edges = []
    faces = []
    new_mesh = bpy.data.meshes.new('new_mesh')
    new_mesh.from_pydata(vertices, edges, faces)
    new_mesh.update()
    # make object from mesh
    new_object = bpy.data.objects.new('SpiralCurve', new_mesh)
    # add object to scene collection
    bpy.data.collections[0].objects.link(new_object)

    # Deselect all objects in the scene
    bpy.ops.object.select_all(action='DESELECT')
    # Set the active object to new vertex object in the scene
    bpy.context.view_layer.objects.active = new_object          
    # select only the new vertex object
    new_object.select_set(True)
    # move a selected object to 3D cursor location, while maintaining offset
    bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
    # move origin of vertex object by 10 units along x axis
    moveorigin(new_object,10,0,0)
    
    # return created vertex object 
    return()


# Routine to move a curve object control point along it's normal path
def Movecp(obj, cp, move_x, move_y, move_z):
    # adjustment values of new direction distance (based on NORMAL orientation)
    dist = Vector((move_x, move_y, move_z))
    # adjust for scale
    scalemult = obj.scale[0]

    cp.co += dist / scalemult
    #Set automatic
    cp.handle_right_type = 'AUTO'
    cp.handle_left_type = 'AUTO'

    #Now set handle type to aligned
    cp.handle_right_type = 'ALIGNED'
    cp.handle_left_type = 'ALIGNED'


def moveorigin(obj, dx, dy, dz):
# moves the origin of an object by a delta value,
# relative to the mesh local orientation
# and leaves the object mesh intact
    mw = obj.matrix_world
    me = obj.data 
    offset = Vector((dx, dy, dz)) 
    me.transform(Matrix.Translation( -offset )) 
    obj.matrix_world.translation = mw @ offset


def HasScrewModifier(obj):
# routine to see if passed object has a "Scew" modifier
    if obj:
        for modifier in obj.modifiers:
            if modifier.type == 'SCREW':
                return True
            else:
                return False
    else:
        return False

def IsCurveObject(obj):
# routine to determine if passed object is a curve object
    if obj:
         # check for curve type
        if obj.type == 'CURVE':
            return True
        else:
            return False
    else:
        return False



    
# this snippet will scan the passed curve object, and 
# select the control point & handles for the passed cpindex
# it will return the vertex of the control point
# if cpindex is larger than the the curve cp index, will select & return the last cp + handles
# Usage:
#    SelectCP(bpy.context.object, 2)    # '0' = first item, will select the 3rd control point and associated handles
def SelectCP(obj, cpindex):
    # check if valid object selected
    if obj:
         # check for curve type
        if obj.type == 'CURVE':
            curvedata = obj.data.splines[0].bezier_points
            for i, point in enumerate(curvedata):
                point.select_left_handle = i == cpindex
                point.select_right_handle = i == cpindex
                point.select_control_point = i == cpindex
                # if index found
                if i == cpindex:
                    cpfound = True
                    cp = point
            if cpfound:    
                return cp
            else:
                # get last control point
                cp = curvedata[len(curvedata)-1]   
                cp.select_left_handle = True
                cp.select_right_handle = True
                cp.select_control_point = True
                return cp                        

# this snippet will scan the passed curve object, and 
# select the right or left handles for the passed cpindex, with handle = "left", "right", "both", "all", "cp"
# it will return the vertex of the control point
# if cpindex is larger than the the curve cp index, will select & return the last cp + handles
# Usage:
#    SelectCP(bpy.context.object, 2, 'left')    # '0' = first item, will select the left handle of the 3rd control point
def SelectCPhandles(obj, cpindex, handle):
    # check if valid object selected
    if obj:
         # check for curve type
        if obj.type == 'CURVE':
            curvedata = obj.data.splines[0].bezier_points
            for i, point in enumerate(curvedata):
                point.select_left_handle = (i == cpindex and (handle == "left" or handle == "both" or handle == "all"))
                point.select_right_handle = (i == cpindex and (handle == "right" or handle == "both" or handle == "all"))
                point.select_control_point = (i == cpindex and (handle == "cp" or handle == "all"))
                # if index found
                if i == cpindex:
                    cpfound = True
                    cp = point
            if cpfound:    
                return cp
            else:
                # get last control point
                cp = curvedata[len(curvedata)-1]   
                cp.select_left_handle = (handle == "left" or handle == "both" or handle == "all")
                cp.select_right_handle = (handle == "right" or handle == "both" or handle == "all")
                cp.select_control_point = (handle == "cp" or handle == "all")
                return cp                        


                

        
def SetupCurve():
# routine to setup the curve selected
    scene = bpy.context.scene
    mytool = scene.my_tool
    
    # ====== Spiral Creator ===============
    if mytool.my_enum_curve_shape == 'OP6' :
        # make a vertex 
        CreateSpiralVertex()
        # create a screw modifier
        bpy.ops.object.modifier_add(type='SCREW')
        # set some default parameters on the selected spiral object
        bpy.context.selected_objects[0].modifiers["Screw"].steps = 512       
        bpy.context.selected_objects[0].modifiers["Screw"].screw_offset = 10       
       
    return()


        
def BuildCurve():
# routine to setup the curve selected
    scene = bpy.context.scene
    mytool = scene.my_tool


    # save transform & pivot point
    transformtype = bpy.context.scene.transform_orientation_slots[0].type
    pivotpoint = bpy.context.scene.tool_settings.transform_pivot_point



    # ====== Straight Curve Build ===============
    if mytool.my_enum_curve_shape == 'OP1' :
        # switch to local orientation
        bpy.context.scene.transform_orientation_slots[0].type = 'LOCAL'
        # switch to median pivot point
        bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'

        # add a beziere curve at 0,0,0 and resize to 10
        bpy.ops.curve.primitive_bezier_curve_add()
        # rename it
        bpy.context.object.name = "StraightCurve"

        bpy.ops.transform.resize(value=(10, 10, 10))
        
        # switch to Edit mode
        bpy.ops.object.mode_set(mode='EDIT')

        # Deselect all control handles in the curve
        bpy.ops.curve.select_all(action='DESELECT')

        # get the spline data of the object curve
        spline_data = bpy.context.object.data.splines
        # get all the bezier points on the first spline
        bp = spline_data[0].bezier_points
        
        # select 1st control point
        cp = SelectCP(bpy.context.object, 0)

        #rotate the first cp by -45 along z
        bpy.ops.transform.rotate(value=-0.785398, orient_axis='Z', orient_type='LOCAL')
        
        # select 2nd control point
        cp = SelectCP(bpy.context.object, 1)
        
        # resize to 70%
        bpy.ops.transform.resize(value=(0.7, 0.7, 0.7))
        
        bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'

        # index count
        i = 2
        # adjust min control points = 2
        if mytool.my_int_curve_cp < 2:
           mytool.my_int_curve_cp = 2 
        
        # loop for # of control points needed
        while i < mytool.my_int_curve_cp:
            # copy it with an extrude 
            bpy.ops.curve.extrude_move(CURVE_OT_extrude={"mode":'TRANSLATION'}, TRANSFORM_OT_translate={"value":(20, 0, 0), "orient_matrix_type":'LOCAL', "constraint_axis":(True, False, False)})
            i += 1

        # select all control points
        bpy.ops.curve.select_all(action='SELECT')
        # switch to Object mode
        bpy.ops.object.mode_set(mode='OBJECT')
        #  centre the origin to geometry
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
        # move a selected object to 3D cursor location
        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
            


    # ====== Circle Curve Build ===============
    if mytool.my_enum_curve_shape == 'OP2' :
        # switch to local orientation
        bpy.context.scene.transform_orientation_slots[0].type = 'LOCAL'
        # switch to median pivot point
        bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'

        # add a beziere circle curve at 0,0,0 and resize to 10
        bpy.ops.curve.primitive_bezier_circle_add(radius=mytool.my_int_curve_diam / 2, enter_editmode=True, align='WORLD')
        # rename it
        bpy.context.object.name = "CircleCurve"
        # select all control points
        bpy.ops.curve.select_all(action='SELECT')
        # switch to Object mode
        bpy.ops.object.mode_set(mode='OBJECT')

    


    # ====== Half-Circle Curve Build ===============
    if mytool.my_enum_curve_shape == 'OP3' :
        # switch to local orientation
        bpy.context.scene.transform_orientation_slots[0].type = 'LOCAL'
        # switch to median pivot point
        bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'

        # add a beziere circle curve at 3D cursor 
        bpy.ops.curve.primitive_bezier_circle_add(radius=mytool.my_int_curve_diam / 2, enter_editmode=True, align='WORLD')
        # rename it
        bpy.context.object.name = "HalfCircCurve"
        # get the object
        obj = bpy.context.selected_objects[0]

        # switch to Edit mode
        bpy.ops.object.mode_set(mode='EDIT')

        # select 1st control point, left handle
        cp = SelectCPhandles(bpy.context.object, 0, 'left')
        
        # set handle to free
        bpy.ops.curve.handle_type_set(type='FREE_ALIGN')
        # rotate left handle
        bpy.ops.transform.rotate(value=radians(90), orient_axis='Z', orient_type='LOCAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)))

        # select right control point, right handle
        cp = SelectCPhandles(bpy.context.object, 2, 'right')
        bpy.ops.curve.handle_type_set(type='FREE_ALIGN')
        # rotate right handle
        bpy.ops.transform.rotate(value=radians(-90), orient_axis='Z', orient_type='LOCAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)))

        # select last control point, cp
        cp = SelectCPhandles(bpy.context.object, 3, 'all')
        bpy.ops.curve.handle_type_set(type='ALIGNED')

        # adjust for scale
        scalemult = obj.scale[0]
    
        # move the control point
        Movecp(obj, cp, 0, mytool.my_int_curve_diam / 2 * scalemult, 0)
            
        # select all control points
        bpy.ops.curve.select_all(action='SELECT')
        # switch to Object mode
        bpy.ops.object.mode_set(mode='OBJECT')
    




    # ====== Wave Curve Build ===============
    if mytool.my_enum_curve_shape == 'OP4' :
        # switch to local orientation
        bpy.context.scene.transform_orientation_slots[0].type = 'LOCAL'
        # switch to median pivot point
        bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'

        # add a beziere curve at 0,0,0 and resize to 10
        bpy.ops.curve.primitive_bezier_curve_add()
        # rename it
        bpy.context.object.name = "WaveCurve"
        bpy.ops.transform.resize(value=(10, 10, 10))
        
        # switch to Edit mode
        bpy.ops.object.mode_set(mode='EDIT')

        # Deselect all control handles in the curve
        bpy.ops.curve.select_all(action='DESELECT')

        # get the spline data of the object curve
        spline_data = bpy.context.object.data.splines
        # get all the bezier points on the first spline
        bp = spline_data[0].bezier_points
        
        # select 1st control point
        cp = SelectCP(bpy.context.object, 0)

        #rotate the first cp by -45 along z
        bpy.ops.transform.rotate(value=-0.785398, orient_axis='Z', orient_type='LOCAL')
        
        # select 2nd control point
        cp = SelectCP(bpy.context.object, 1)
        
        # resize to 70%
        bpy.ops.transform.resize(value=(0.7, 0.7, 0.7))
        # switch pivot to individual origins
        bpy.context.scene.tool_settings.transform_pivot_point = 'INDIVIDUAL_ORIGINS'

        # index count
        i = 1
        cploop = (mytool.my_int_curve_cp * 2)
        
        # loop for # of control points needed
        while i < cploop:
            # copy it with an extrude 
            bpy.ops.curve.extrude_move(CURVE_OT_extrude={"mode":'TRANSLATION'}, TRANSFORM_OT_translate={"value":(20, 0, 0), "orient_matrix_type":'LOCAL', "constraint_axis":(True, False, False)})
            i += 1

        # adjust every 2nd cp up by 20
        # index count
        i = 1
        cploop = (mytool.my_int_curve_cp * 2)

        # Deselect all control handles in the curve
        bpy.ops.curve.select_all(action='DESELECT')

        # loop for # of control points needed
        while i < cploop:
            # select the control point
            cp = SelectCP(bpy.context.object, i)
            # move it up by 20
            bpy.ops.transform.translate(value=(0, 20, 0), orient_type='LOCAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='LOCAL', constraint_axis=(False, True, False))
            # Deselect all control handles in the curve
            bpy.ops.curve.select_all(action='DESELECT')
            i += 2

        # Select all control handles in the curve
        bpy.ops.curve.select_all(action='SELECT')
        # Size up all cp's from original sizes
        # resize to 1.43%
        bpy.ops.transform.resize(value=(1.43, 1.43, 1.43))
                
        # switch to Object mode
        bpy.ops.object.mode_set(mode='OBJECT')
        #  centre the origin to geometry
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
        # move a selected object to 3D cursor location
        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

 
 
     # ====== Arc Curve Build ===============
    if mytool.my_enum_curve_shape == 'OP5' :
        # switch to local orientation
        bpy.context.scene.transform_orientation_slots[0].type = 'LOCAL'
        # switch to median pivot point
        bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'

        # add a beziere curve at 3D cursor 
        bpy.ops.curve.primitive_bezier_curve_add()
        # rename it
        bpy.context.object.name = "ArcCurve"
        # get object
        obj = bpy.context.object

        # save the current 3D cursor location
        currentcursorloc = bpy.context.scene.cursor.location

        # Bezier curve points come in at distance 2 apart... so....
        # calculate radius size
        radsize = mytool.my_int_curve_diam / 2
        # resize Bezier curve as needed
        bpy.ops.transform.resize(value=(radsize / 2, radsize / 2, radsize / 2))
        
        # Get the obj scale
        scalemult = obj.scale[0]
        
        # switch to Edit mode
        bpy.ops.object.mode_set(mode='EDIT')

        # get the spline data of the object curve
        spline_data = bpy.context.object.data.splines
        # get all the bezier points on the first spline
        bp = spline_data[0].bezier_points
        
        # select 1st control point
        cp = SelectCP(obj, 0)

        # The Bezier curve first control point comes in at 45 deg rotation by default
        #rotate the first cp by -10 along z
        bpy.ops.transform.rotate(value=radians(5), orient_axis='Z', orient_type='LOCAL')
        
        # select 2nd control point
        cp = SelectCP(obj, 1)
        
        # resize to 70%
        bpy.ops.transform.resize(value=(0.7, 0.7, 0.7))
       
        # adjust for 3 control points needed
        # copy it with an extrude 
        bpy.ops.curve.extrude_move(CURVE_OT_extrude={"mode":'TRANSLATION'}, TRANSFORM_OT_translate={"value":(radsize, 0, 0), "orient_matrix_type":'LOCAL', "constraint_axis":(True, False, False)})
       
        # select last control point
        cp = SelectCP(obj, 2)

        #rotate the first cp by -90 along z
        bpy.ops.transform.rotate(value=radians(-50), orient_axis='Z', orient_type='LOCAL')

        # select middle control point, cp
        cp = SelectCP(obj, 1)
        
        # move the control point (by a ratio of it's scale size)
        Movecp(obj, cp, 0, mytool.my_int_curve_diam * 0.218, 0)
            
        # switch to edit mode
        bpy.ops.object.mode_set(mode='EDIT')
        
        # select all control points
        bpy.ops.curve.select_all(action='SELECT')
        
        # switch to Object mode
        bpy.ops.object.mode_set(mode='OBJECT')

        # move object origin to stored shape centre
        moveorigin(obj, radsize / scalemult / 2, 0, 0) 

        # Set the 3D cursor to the earlier saved position
        bpy.context.scene.cursor.location = currentcursorloc     

        # move the selected object to 3D cursor location
        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        
    
    # ====== Spiral Build ===============
    if mytool.my_enum_curve_shape == 'OP6' :
        # convert screw modified vertex into curve from mesh 
        bpy.ops.object.convert(target='CURVE')
        # switch to Edit mode
        bpy.ops.object.mode_set(mode='EDIT')
        # set toggle cyclic (this creates a continuous curve, but more importantly, 
        # levels the curve twist on a horizontal plane
        bpy.ops.curve.cyclic_toggle()
        # switch to Object mode
        bpy.ops.object.mode_set(mode='OBJECT')


    # switch back to original transform
    bpy.context.scene.transform_orientation_slots[0].type = transformtype
    #switch back to original pivot
    bpy.context.scene.tool_settings.transform_pivot_point = pivotpoint
    # move a selected object to 3D cursor location
    #bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
    # switch to Edit mode, so you can see the handles
    #bpy.ops.object.mode_set(mode='EDIT')
                
    return()

def DeleteCurve():
# routine to delete a curve
# the currently selected object can be a constrained object along a curve, or the curve itself
# routine will do nothing if:
#    1. No object selected
#    2. Selected object is not associated with a curve
#    3. Selected bject is not a curve

    scene = bpy.context.scene
    mytool = scene.my_tool
    
    # get first selected object, exit if none selected    
    if len(bpy.context.selected_objects):
        obj = bpy.context.selected_objects[0]                       
    else:
        return
    
    # init curve_name
    curve_name = ""

    # check if obj is curve type
    if obj.type == 'CURVE':
        # assign to curve
        curve = obj
        curve_name = curve.name
        #unselect the curve
        curve.select_set(False)
    else:  # object is not a curve
        # cycle through the object constraints to find the curve associated with it
        for name, con in obj.constraints.items():
            if con.type == "FOLLOW_PATH":
                # get the curve and the name of the curve associated with this constraint
                curve = con.target
                curve_name = con.target.name
                break
    # exit if no curve name found
    if curve_name == "":
        return

    # Deselect all objects in the scene
    bpy.ops.object.select_all(action='DESELECT')
        
    # ====== delete the curve, maintain constraint object positions ===============
    # Cycle through All objects in the scene
    for o in bpy.data.objects :                  
        for name, con in o.constraints.items():
            if con.type == "FOLLOW_PATH":
                # check if the name of the curve associated with this constraint is the same as associated object curve
                if curve_name == con.target.name:
                    # create a temp copy of real world matrix coordinates
                    mw = o.matrix_world.copy()
                    # delete the object constraint
                    o.constraints.clear()
                    # reassign coordinates to object
                    o.matrix_world = mw

    # now delete curve
    bpy.data.objects.remove(curve, do_unlink=True)

    return()


def getcurve(obj):
# routine to get a constraint curve, from the object passed
# the passed object can be a constrained object along a curve, or the curve itself
# routine will return the curve name
# routine will do nothing if:
#    1. No object selected
#    2. Selected object is not associated with a curve
#    3. Selected bject is not a curve

    # init curve_name
    curve_name = ""

    # return if no object passed
    if not obj:
        return (curve_name)

    # check if obj is curve type
    if obj.type == 'CURVE':
        # assign to curve
        curve = obj
        curve_name = curve.name
    else:  # object is not a curve
        # cycle through the object constraints to find the curve associated with it
        for name, con in obj.constraints.items():
            if con.type == "FOLLOW_PATH":
                # get the curve and the name of the curve associated with this constraint
                curve_name = con.target.name

    return (curve_name)
       



def AdjustCurve(dir):
# routine to adjust control points on the curve
# dependent upon curve type, different actions will be taken
    scene = bpy.context.scene
    mytool = scene.my_tool

    # check if at least 1 object selected, and it's a curve
    found = len(bpy.context.selected_objects) and  bpy.context.selected_objects[0].type == 'CURVE'
    if found:
        # get the first object
        obj = bpy.context.selected_objects[0]
        objname = obj.name
    else:
        return

    # save transform & pivot point
    transformtype = bpy.context.scene.transform_orientation_slots[0].type
    pivotpoint = bpy.context.scene.tool_settings.transform_pivot_point
    # Determine which mode the object editing is in, and save it
    currentmode = bpy.context.object.mode

    
    # ====== Straight Curve Adjust ===============
    # check if selected object is a straight curve
    if "StraightCurve" in objname:

        # switch to Object mode
        bpy.ops.object.mode_set(mode='OBJECT')
         
        # select the active object 
        obj = bpy.context.object

        #move the cursor to the origin of the object
        bpy.ops.view3d.snap_cursor_to_selected()

        # switch to Edit mode
        bpy.ops.object.mode_set(mode='EDIT')
        
        # Deselect all control handles in the curve
        bpy.ops.curve.select_all(action='DESELECT')
          
        # to access the last control point on the first spline of the bezier curve
        cp = LastControlPoint(obj)

        if dir == "down":
            if ControlPoints(obj) > 2:
                # delete it
                bpy.ops.curve.delete(type='VERT')
                # to access the last control point on the first spline of the bezier curve
                cp = LastControlPoint(obj)
        else:   # going up
            # set transform to local
            bpy.context.scene.transform_orientation_slots[0].type = 'LOCAL'

            # adjust for scale
            scalemult = obj.scale[0]

            # copy it with an extrude 
            bpy.ops.curve.extrude_move(CURVE_OT_extrude={"mode":'TRANSLATION'}, TRANSFORM_OT_translate={"value":(2 * scalemult, 0, 0), 
            "orient_matrix_type":'LOCAL', "constraint_axis":(True, False, False)})

        # Select all control handles in the curve
        bpy.ops.curve.select_all(action='SELECT')

        # switch to Object mode
        bpy.ops.object.mode_set(mode='OBJECT')
        #  centre the origin to geometry
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
        
        # move a selected object to 3D cursor location
        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
        



    # ====== Wave Curve Adjust ===============
    # check if selected object is a wave curve
    if "WaveCurve" in objname:

        # switch to Object mode
        #bpy.ops.object.mode_set(mode='OBJECT')
         
        # select the active object 
        obj = bpy.context.object

        # switch to Object mode
        bpy.ops.object.mode_set(mode='OBJECT')

        #move the cursor to the origin of the object
        bpy.ops.view3d.snap_cursor_to_selected()

        # switch to Edit mode
        bpy.ops.object.mode_set(mode='EDIT')
        
        # Deselect all control handles in the curve
        bpy.ops.curve.select_all(action='DESELECT')
          

        # get the total waves
        waves = mytool.my_int_curve_cp

        if dir == "down":
            if waves > 1:
                # delete last 2 control points for each wave
                for i in range(2):
                    # to access the last control point on the first spline of the bezier curve
                    cp = LastControlPoint(obj)
                    # delete it
                    bpy.ops.curve.delete(type='VERT')
                waves -= 1            
        else:   # going up
            # Deselect all control handles in the curve
            bpy.ops.curve.select_all(action='DESELECT')
            # to access the last control point on the first spline of the bezier curve
            cp = LastControlPoint(obj)
                
            # switch to local orientation
            bpy.context.scene.transform_orientation_slots[0].type = 'LOCAL'
            # switch to median pivot point
            bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'
            
            # adjust for scale
            scalemult = obj.scale[0]
            
            # copy last cp with an extrude 
            bpy.ops.curve.extrude_move(CURVE_OT_extrude={"mode":'TRANSLATION'}, TRANSFORM_OT_translate={"value":(2 * scalemult, 0, 0), "orient_matrix_type":'LOCAL', "constraint_axis":(True, False, False)})

            # to access the last control point on the first spline of the bezier curve
            cp = LastControlPoint(obj)
            # move the control point
            Movecp(obj, cp, 0, 2 * scalemult, 0)
            
            # copy last cp with an extrude 
            bpy.ops.curve.extrude_move(CURVE_OT_extrude={"mode":'TRANSLATION'}, TRANSFORM_OT_translate={"value":(2 * scalemult, 0, 0), "orient_matrix_type":'LOCAL', "constraint_axis":(True, False, False)})
            
            # to access the last control point on the first spline of the bezier curve
            cp = LastControlPoint(obj)
            # move the control point
            Movecp(obj, cp, 0, -2 * scalemult, 0)

            # update waves
            waves += 1            

            # update total waves
            mytool.my_int_curve_cp = waves
            
        # Select all control handles in the curve
        bpy.ops.curve.select_all(action='SELECT')


    # switch to Object mode
    bpy.ops.object.mode_set(mode='OBJECT')
    #  centre the origin to geometry
    bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
    
    # move a selected object to 3D cursor location
    bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
    
    # switch back to original transform
    bpy.context.scene.transform_orientation_slots[0].type = transformtype
    #switch back to original pivot
    bpy.context.scene.tool_settings.transform_pivot_point = pivotpoint
    # switch to saved mode
    bpy.ops.object.mode_set(mode=currentmode)

                    
    return()
        
    
def ControlPoints(curveobj):
# routine returns the number of control points in the curve passed
    
    # check if passed object is a curve
    if IsCurveObject(curveobj):   
        # get the spline data of the object curve
        spline_data = curveobj.data.splines
        # get all the bezier points on the first spline
        bp = spline_data[0].bezier_points
        
        # update control points
        return(len(bp))
    else:
        return (0)
    
def LastControlPoint(curveobj):
# routine selects & returns the last control point in the curve passed


    # check if passed object is a curve
    if IsCurveObject(curveobj):   
        # Deselect all control handles in the curve
        #bpy.ops.curve.select_all(action='DESELECT')
        # get the spline data of the object curve
        spline_data = curveobj.data.splines
        # get all the bezier points on the first spline
        bp = spline_data[0].bezier_points
        # get index of last cp 
        lastcpindex = len(bp)-1
        # to access the last control point on the first spline of the bezier curve
        cp = bp[lastcpindex]
        # select the vertices of the last control point
        cp.select_control_point = True
        cp.select_left_handle = True
        cp.select_right_handle = True
    
        # return control point
        return(cp)
    else:
        return (0)
 
   



