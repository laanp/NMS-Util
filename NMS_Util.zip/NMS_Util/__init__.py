bl_info = {
    "name" : "NMS Util",
    "author" : "laanp",
    "version" : (1, 13),
    "blender" : (2, 83, 0),
    "location" : "View3d > NMS Util",
    "warning" : "",
    "wiki_url" : "",
    "category" : "Modify Mesh"    
}
 
    

import bpy
import bmesh
from functools import partial
from mathutils import Vector, Matrix
from math import pi, tan, atan, ceil, floor, radians, degrees, modf
from bpy.types import Panel, Operator, PropertyGroup 
from bpy.props import *



# ======================================== Import Modules =======================================================

import NMS_Util.modules.floor_creator as FLOOR
import NMS_Util.modules.circle_creator as CIRCLE
import NMS_Util.modules.wire_text_creator as WIRETEXT
import NMS_Util.modules.object_manipulator as OBJMAN
import NMS_Util.modules.object_along_curve as OAC
import NMS_Util.modules.object_replace as OBJREP
import NMS_Util.modules.curve_creator as CURVES


# Message box setup-  This routine is already in the NMS Base Builders Plugin
# but shown here for independence if needed 
#def ShowMessageBox(message="", title="Message Box", icon="INFO"):
#    def draw(self, context):
#        self.layout.label(text=message)
#
#    bpy.context.window_manager.popup_menu(draw, title=title, icon=icon)


# routine called when the text box changed - used by wire text creator
def ChangeText(self, context):
    bpy.ops.nmsutil.text_adjust('EXEC_DEFAULT')

# routine to do something when my_int_width changes ... more investigation needed
def OP_AlignAction(self, context):
    OBJMAN.AlignObjects()


# ======================================== Custom Class PropertyGroup Definitions =======================================================
class MyProperties(PropertyGroup):
    # properties for Floor Creator
    my_int_width : bpy.props.IntProperty (name= "Width(x):", soft_min=1, soft_max = 20, default = 1) 
    my_int_length : bpy.props.IntProperty (name= "Length(y):", soft_min=1, soft_max = 20, default = 1) 
    my_int_diam : bpy.props.IntProperty (name= "Diameter:", soft_min=2, soft_max = 20, default = 2) 
    my_int_floors : bpy.props.IntProperty (name= "Floors", soft_min=1, soft_max = 10, default = 1) 
    my_int_wall_height : bpy.props.IntProperty (name= "Wall Height:", soft_min=1, soft_max = 10, default = 1) 
    my_bool_opt_round : bpy.props.BoolProperty (name= "Optimize Round Floor", default=True)
    my_bool_symmetrical : bpy.props.BoolProperty (name= "Keep Symmetry", default= False)
    my_int_centres_to_remove : bpy.props.IntProperty (name= "", soft_min=0, soft_max = 9, default = 0) 
    my_bool_with_glass : bpy.props.BoolProperty (name= "With Glass")
    my_float_round_adjust : bpy.props.FloatProperty (name= "Round Floor To Centre Adjustment:", soft_min=0.1, soft_max = 100,  default= 0.5)
    my_int_index : bpy.props.IntProperty (name= "Index", default=0) 
    my_enum_material : bpy.props.EnumProperty(
        name = "",
        description = "Floor Materials",
        items=[('OP1', "Wood", ""),
                ('OP2', "Metal", ""),
                ('OP3', "Concrete", "")
        ]
    )
    my_enum_shape : bpy.props.EnumProperty(
        name = "",
        description = "Shape Styles",
        items=[('OP1', "Square", ""),
                ('OP2', "Round", "")
        ]
    )
    

    # Properties for Circle Creator
    my_int_obj_count : bpy.props.IntProperty (name= "Count:", soft_min=3, soft_max = 100, default = 30) 
    my_float_obj_width : bpy.props.FloatProperty (name= "Object Width:")
    my_int_circle_diam : bpy.props.IntProperty (name= "Size:", soft_min=1, soft_max = 20, default = 5) 
    my_float_circle_radius : bpy.props.FloatProperty (name= "Circle Radius")
    my_str_obj_name : bpy.props.StringProperty (name= "Original Object Name:") 
    my_str_circle_name : bpy.props.StringProperty (name= "Circle Name:") 
    my_str_ref_obj_name : bpy.props.StringProperty (name= "Ref Object Name:") 
    my_bool_circle_done : bpy.props.BoolProperty (name= "Circle Complete")
    my_bool_setup_done : bpy.props.BoolProperty (name= "Setup Complete")
    my_bool_centre_adjust_done : bpy.props.BoolProperty (name= "Centre Adjust Done")
    # These 3 also used by object_along_curve
    my_bool_90_flip : bpy.props.BoolProperty (name= "90 axis flip toggle", default=True)
    my_float_cust_rot : bpy.props.FloatProperty (name= "Custom Object Rotation:", soft_min=0.1, soft_max = 360,  default= 10)
    my_bool_custom_rot : bpy.props.BoolProperty (name= "custom axis rotate toggle")
    
    my_float_dist_to_centre : bpy.props.FloatProperty (name= "Object Distance To Centre Adjustment:", soft_min=0.1, soft_max = 100,  default= 0.5)
    my_float_rot_offset : bpy.props.FloatProperty (name= "Object Rotation Offset:", soft_min=0.01, soft_max = 45,  default= 0.05)
    my_floatvect_rad : bpy.props.FloatVectorProperty (name= "Ref Obect centre of object location")
     
    

    # properties for wire text utility
    my_str_text : bpy.props.StringProperty (name= "Enter Text:", update=ChangeText) 
    my_bool_center : bpy.props.BoolProperty(name= "Alignment", default= False, update=ChangeText)
    my_bool_italic : bpy.props.BoolProperty(name= "Auto Italic", default = False, update=ChangeText)


    # properties for the Object Manipulator
    my_bool_activesource : bpy.props.BoolProperty (name= "Active Source", default=False)
    my_bool_copy : bpy.props.BoolProperty (name= "Copy", default=False)
    my_bool_move : bpy.props.BoolProperty (name= "Move", default=True)
    my_bool_attr_rot : bpy.props.BoolProperty (name= "Rotation Attribute", default=False)
    my_bool_attr_sca : bpy.props.BoolProperty (name= "Scale Attribute", default=False)
    my_bool_attr_loc : bpy.props.BoolProperty (name= "Location Attribute", default=False)
    my_bool_loc : bpy.props.BoolProperty (name= "Location", default=True)
    my_bool_rot : bpy.props.BoolProperty (name= "Rotation", default=True)
    my_bool_sca : bpy.props.BoolProperty (name= "Scale", default=True)
    my_enum_action : bpy.props.EnumProperty(
        name = "",
        description = "Action",
        items=[('OP1', "Copy", ""),
                ('OP2', "Move", "")
        ]
    )
    # added as part of the Align addition - under the object manipulator
    my_bool_clrattr_rot : bpy.props.BoolProperty (name= "Rotation Attribute", default=False)
    my_bool_clrattr_sca : bpy.props.BoolProperty (name= "Scale Attribute", default=False)
    my_bool_xalign : bpy.props.BoolProperty (name= "Align Along X Axis", default=False, update=OP_AlignAction)
    my_bool_yalign : bpy.props.BoolProperty (name= "Align Along Y Axis", default=False, update=OP_AlignAction)
    my_bool_zalign : bpy.props.BoolProperty (name= "Align Along Z Axis", default=False, update=OP_AlignAction)
    my_enum_alignmode : bpy.props.EnumProperty(
        name = "",
        description = "Align Mode",
        items=[
                ('OPT_2', "Centres", ""),
                ('OPT_1', "Negative Sides", ""),
                ('OPT_3', "Positive Sides", "")
        ],
        update = OP_AlignAction 
    )
    my_enum_alignto : bpy.props.EnumProperty(
        name = "",
        description = "Align To",
        items=[
                ('OPT_4', "Active", ""),
                ('OPT_1', "Scene Origin", ""),
                ('OPT_2', "3D Cursor", ""),
                ('OPT_3', "Selection", "")
        ],
        update = OP_AlignAction 
    )

    
    # associated with object_along_curve module (this also references 
    my_float_curve_length : bpy.props.FloatProperty (name= "Curve Length:")
    my_float_oac_offset : bpy.props.FloatProperty (name= "Object Along Curve Offset:", soft_min= 0.01, soft_max = 1.00,  default= 0.20)
    my_float_oac_adjoffset : bpy.props.FloatProperty (name= "Object Along Curve Adjustement Offset:", soft_min=0.1, soft_max = 100,  default= 0.5)



# copy this class section to MyProperties into __init__.py when ready to combine with NMSUtil
class MyCurveProperties(PropertyGroup):
    # properties for Curve Creator
    my_enum_curve_shape : bpy.props.EnumProperty(
        name = "",
        description = "Curve Styles",
        items=[('OP1', "Straight", ""),
                ('OP2', "Circle", ""),
                ('OP3', "Half-Circle", ""),
                ('OP4', "Wave", ""),
                ('OP5', "Arc", ""),
                ('OP6', "Spiral", "")
        ], 
    )
    my_int_curve_cp : bpy.props.IntProperty (name= "Control Points", soft_min=1, soft_max = 100, default = 3) 
    my_int_curve_diam : bpy.props.IntProperty (name= "Diameter", soft_min=1, soft_max = 100, default = 20) 



# ======================================== Panels =======================================================


  
# "Floor Creator" Panel class
# this contains the code that draws the "Floor Creator" menu and in turn, calls the associated
# Operators (code that executes when a user clicks a button)  
class NMSUTIL_PT_fc_panel(Panel):
    bl_label = "Floor Creator"
    bl_idname = "ADDONNAME_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "NMS Util"
    bl_options = {'DEFAULT_CLOSED'}      # startup with panel closed
    

 
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool

        # create a menu area
        box = layout.box()
        row = box.row()
        row.label(text = "Get a Floor Tile:", icon = 'MESH_PLANE')
        row = box.row()
        row.label(text = "Floor Material:", icon = 'MATERIAL_DATA')
        row.prop(mytool, "my_enum_material")
        row = box.row()
        row.prop(mytool, "my_bool_with_glass", text="With Glass")
        row.operator("nmsutil.add_floortile_operator", text="Build")
        row = box.row()

       # get the currently selected object
        obj = context.object


        # Display the name of the object in the menu (panel)
        # create a menu area
        box = layout.box()
        row = box.row()
        if obj :
            # Display the name of the object in the menu (panel)
            row.prop(obj, "name")

        
        # create a resize button
        row = box.row()
        row.operator("transform.resize")
        
        # create a menu label
        row = layout.row()

        # create a menu area
        box = layout.box()
        row = box.row()
        # for square layout
        if mytool.my_enum_shape == 'OP1' :
            row.label(text = "Floor Shape:", icon = 'OUTLINER_DATA_LATTICE')
            row.prop(mytool, "my_enum_shape", icon = 'MESH_PLANE')
        else:    #round floors
            row.label(text = "Floor Shape:", icon = 'MESH_CIRCLE')
            row.prop(mytool, "my_enum_shape", icon = 'MESH_CIRCLE')
        
        row = box.row()
        # for square layout
        if mytool.my_enum_shape == 'OP1' :
            row = box.row()
            row = box.row()
            #row.prop(mytool, "my_bool_opt_round", text="Optimize For Least Pieces")
        else:    #round floors
            row.prop(mytool, "my_bool_symmetrical", text="Symmetrical")
            if mytool.my_bool_symmetrical:
                row.prop(mytool, "my_bool_opt_round", text="Optimize For Least Pieces")

        # create new menu area
        box = layout.box()
        row = box.row()
        # for square layout
        if mytool.my_enum_shape == 'OP1' :
            row.label(text = "Floor Dimensions", icon = 'FULLSCREEN_ENTER')
            row = box.row()
        else:    # for round layout
            row.label(text = "Floor Dimensions", icon = 'PROP_ON')
            row = box.row()
            row.label(text = "Diameter:")
            row.label(text = "Centres To Remove:")
            row = box.row()

       
        if mytool.my_enum_shape == 'OP1' :
            row.prop(mytool, "my_int_width")
            row.prop(mytool, "my_int_length")
        else:    #round floors
            row.prop(mytool, "my_int_diam")
            row.prop(mytool, "my_int_centres_to_remove")

        # User adjustment of number of floors
        row = box.row()
        row.label(text = "No. of Floors & Wall Height", icon = 'AXIS_TOP')
        row = box.row()
        row.prop(mytool, "my_int_floors")
        # User adjustment of space betweenfloors (basically wall height)
        row.prop(mytool, "my_int_wall_height")
        
        box = layout.box()
        row = box.row()
        row = box.row()
        if mytool.my_enum_shape == 'OP1' :
            row.label(text = "Build Square Floors", icon = 'FILE_BLEND')
        else:
            row.label(text = "Build Round Floors", icon = 'FILE_BLEND')
        row = box.row()
        if mytool.my_enum_shape == 'OP1' :
            row.operator("nmsutil.create_square_operator")
        else:
            if mytool.my_bool_symmetrical:
                if mytool.my_bool_opt_round:
                    row.operator("nmsutil.create_sym_opto_round_operator")
                else:                
                    row.operator("nmsutil.create_round_operator")
            else:
                row.operator("nmsutil.create_opto_round_operator")

            row = box.row()
            row.label(text="Adjust Round Floor", icon = "DRIVER_DISTANCE")
            row = box.row()
            row.label(text="Distance to Centre:")
            row = box.row()
            
            #row.operator("nmsutil.index_dnadjust_operator", text= "<<", icon = 'PLAY_REVERSE')
            #row.prop(mytool, "my_int_index", text="")
            #row.operator("nmsutil.index_upadjust_operator", text= ">>", icon = 'PLAY')
            
        
            row.operator("nmsutil.round_inadjust_operator", text= "<<", icon = 'PLAY_REVERSE')
            row.prop(mytool, "my_float_round_adjust", text="")
            row.operator("nmsutil.round_outadjust_operator", text= ">>", icon = 'PLAY')
            row = box.row()



# "Object Circle Creator" Panel class
# this contains the code that draws the "Object Circle Creator" menu and in turn, calls the associated
# Operators (code that executes when a user clicks a button)  
class NMSUTIL_PT_coa_panel(Panel):
    bl_label = "Object Circle Creator"
    bl_idname = "NMSUTIL_PT_coa_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "NMS Util"
    bl_options = {'DEFAULT_CLOSED'}      # startup with panel closed


    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool
        
       # get the currently selected object
        obj = context.object
        
        # Display the name of the object in the menu (panel)
        row = layout.row()
        if obj :
            row.prop(obj, "name")
            row = layout.row()
        
            # create a resize button
            row = layout.row()
            row.operator("transform.resize")
            row = layout.row()

        # create a menu area
        box = layout.box()
        row = box.row()
        row = box.row()
        row.label(text = "Object Circle:", icon = 'MODIFIER_ON')
        row.operator("nmsutil.setup_operator", text="Setup / Reset")
        row = box.row()
        row = box.row()
        row = box.column_flow(columns=2, align=False)      # align=False creates gaps between buttons
        row.label(text = "Objects In Circle:", icon = 'PHYSICS')
        row.label(text = "  ")
        row.prop(mytool, "my_int_obj_count")
        

        # create new menu area
        box = layout.box()
        row = box.row()
        row.label(text = "Object Orientation in Circle:", icon = 'SPHERE')
        row = box.row()
        row.label(text = "Rotation Increments:")
        row = box.column_flow(columns=3, align=False)      # align=False creates gaps between buttons
        if not mytool.my_bool_custom_rot: 
            row.prop(mytool, "my_bool_90_flip", text="90°")
            row.prop(mytool, "my_bool_90_flip", text="45°", invert_checkbox= True)
        else:
            row.prop(mytool, "my_float_cust_rot", text="")
            row.label(text = "Degrees  ")
        row.prop(mytool, "my_bool_custom_rot", text="Custom")
        row = box.row()
        row.operator("nmsutil.flipx_operator")
        row.operator("nmsutil.flipy_operator")
        row.operator("nmsutil.flipz_operator")
        row = box.row()
        row = box.row()


        # create new menu area
        box = layout.box()
        row = box.row()
        row = box.row()
        row.label(text = "Build Circle", icon = 'FILE_BLEND')
        row = box.row()
        row.operator("nmsutil.create_circle_operator")
        row = box.row()
        
        
        # create new menu area
        box = layout.box()
        row = box.row()
        
        row.label(text="Adjust Circle", icon = "DRIVER_DISTANCE")
        row = box.row()
        row.label(text="Distance to Centre:")
        row = box.row()
        
        row.operator("nmsutil.inadjust_operator", text= "<<", icon = 'PLAY_REVERSE')
        row.prop(mytool, "my_float_dist_to_centre", text="")
        row.operator("nmsutil.outadjust_operator", text= ">>", icon = 'PLAY')
        row = box.row()
        row.label(text="Object Rotation Offset:")
        row = box.row()
        row.operator("nmsutil.rot_inadjust_operator", text= "<<", icon = 'PLAY_REVERSE')
        row.prop(mytool, "my_float_rot_offset", text="")
        row.operator("nmsutil.rot_outadjust_operator", text= ">>", icon = 'PLAY')
        row = box.row()
       

    @classmethod
    def poll(cls, context):
        return True





class NMSUTIL_PT_TextTool(Panel):
    bl_label = "NMS Wiring Text"
    bl_idname = "NMSUTIL_PT_TextTool"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "NMS Util"
    bl_options = {'DEFAULT_CLOSED'}      # startup with panel closed
    


    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool
        
        # check if at least 1 object selected
        found = len(context.selected_objects)

        # check if an object selected and it's a font.
        if found:
            obj = context.selected_objects[0]
            text = context.object.data

        # new tool area
        layout.separator(factor= 1)
        box = layout.box()
        row = box.row()

        row.label(text= "Enter or Modify Text:", icon = 'FILE_TEXT')
        row = box.row()
        row.prop(mytool, "my_str_text")
        row = box.row()

        #row.prop(mytool, "my_str_text")


        # Display the text of the object in the menu (panel)
        row.label(text= "Scale:", icon = 'EMPTY_ARROWS')
        row.operator("transform.resize")

        #row.prop(mytool, "my_flt_scale")
        row = box.row()
        
        layout.separator(factor= 0)
        box = layout.box()
        row = box.row()
        row.label(text= "Text Options:", icon = 'FILE_TEXT')
        row = box.row()
        
        #if mytool.my_bool_italic == True:
        #row.prop(mytool, "my_bool_italic", text="Italics", icon='ITALIC')

        if mytool.my_bool_italic == True:
            row.label(text= "", icon= 'ITALIC')
            row.prop(mytool, "my_bool_italic", text="Italics: Enabled")
        else:
            row.label(text= "", icon= 'FONT_DATA')
            row.prop(mytool, "my_bool_italic", text="Italics: Disabled")
        row = box.row()
                
        #spacing
        # Only show these attributes if an active text object selected 
        if found and obj.type == 'FONT':
            row = box.row()
            row.label(text= "")
            row.label(text= "Spacing Options:", icon = 'TRACKING_FORWARDS_SINGLE')
            row = box.row()
            row.label(text= "Character:")
            row.prop(text, "space_character", text="")
            row = box.row()
            row.label(text= "Word:")
            row.prop(text, "space_word", text="")
            row = box.row()
            #row.label(text= "Line:")
            #row.prop(text, "space_line", text="")
        
            # new section
            box = layout.box()
            row = box.row()
            row.label(text= "Build The Text:")
            row = box.row()
            row = box.row()
            row.operator("nmsutil.text_build", text="Create")
            row = box.row()
  


# "Object Manipulation" Panel class
# this contains the code that draws the "Object Manipulation" menu and in turn, calls the associated
# Operators (code that executes when a user clicks a button)  
class NMSUTIL_PT_objman_panel(Panel):
    bl_label = "Object Manipulation"
    bl_idname = "NMSOBJECTMAN_PT_objman_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "NMS Util"
    bl_options = {'DEFAULT_CLOSED'}      # startup with panel closed


    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool
        
       # get the currently selected object
        obj = context.object
        
        # create a menu area  =======================  Move, Copy, Attributes ====================
        box = layout.box()
        row = box.row()
        row.label(text = "Move, Copy Objects and/or Attributes:", icon = 'MODIFIER_ON')
        row = box.row()
        row.label(text = "Choose which to apply:")
        row = box.row()
        row.label(text = "Attribute:")
        row = row.column_flow(columns=2, align=False)      # align=False creates gaps between buttons
        row.label(text = "Active")
        row.label(text = "Selected")
        row = box.row()
        row.prop(mytool, "my_bool_attr_rot", text="Rotation")

        if mytool.my_bool_attr_rot :
            row = row.column_flow(columns=2, align=False)      # align=False creates gaps between buttons
            if mytool.my_bool_rot:
                row.prop(mytool, "my_bool_rot", text= ">>>>>>")
            else:    
                 row.prop(mytool, "my_bool_rot", text= "<<<<<<")
            row = row.split(factor=.2,align= True)
            row.prop(mytool, "my_bool_rot", text= "", invert_checkbox= True)
        row = box.row()
        row.prop(mytool, "my_bool_attr_sca", text="Scale")
        if mytool.my_bool_attr_sca :
            row = row.column_flow(columns=2, align=False)      # align=False creates gaps between buttons
            if mytool.my_bool_sca:
                row.prop(mytool, "my_bool_sca", text= ">>>>>>")
            else:
                row.prop(mytool, "my_bool_sca", text= "<<<<<<")
            row = row.split(factor=.2,align= True)
            row.prop(mytool, "my_bool_sca", text= "", invert_checkbox= True)
        row = box.row()
        row.prop(mytool, "my_bool_attr_loc", text="Location")
        if mytool.my_bool_attr_loc :
            row = row.column_flow(columns=2, align=False)      # align=False creates gaps between buttons
            if mytool.my_bool_loc:
                row.prop(mytool, "my_bool_loc", text= ">>>>>>")
            else:
                row.prop(mytool, "my_bool_loc", text= "<<<<<<")
            row = row.split(factor=.2,align= False)
            row.prop(mytool, "my_bool_loc", text= "", invert_checkbox= True)
            row = box.row()
            row = box.row()
            if mytool.my_bool_loc :
                split = row.split(factor= .3,align= True)
                split.prop(mytool, "my_enum_action")
                split.label(text = "Active to Selected")
            else:
                split = row.split(factor= .3,align= True)
                split.prop(mytool, "my_enum_action")
                split.label(text = "Selected to Active")

        row = box.row()        
        row = box.row()        
        row.operator("nmsutil.objectman_perf_action", text="Apply")
        row = box.row()
        row = box.row()
        
        # create a menu area   ===============   Clear Section ===========================
        box = layout.box()
        row = box.row()
        #row.separator(factor= 100)
        row.label(text = "Clear Attributes on Selected Objects:", icon = 'MODIFIER_ON')
        row = box.row()
        row.prop(mytool, "my_bool_clrattr_rot", text="Rotation")
        
        row = box.row()
        row.prop(mytool, "my_bool_clrattr_sca", text="Scale")
        row.operator("nmsutil.objectman_clear_action", text="Clear")
        row = box.row()
       
        # create a menu area   ===============   Align Section ===========================
        box = layout.box()
        row = box.row()
        row = box.row()
        row.label(text = "Align Objects:", icon = 'MODIFIER_ON')
        row = box.row()
        row.label(text = "Align Mode:")
        row.prop(mytool, "my_enum_alignmode", text="")
        row = box.row()
        row.label(text = "Align To:")
        row.prop(mytool, "my_enum_alignto", text="")
        row = box.row()
        row.label(text = "Axis:")
        row.prop(mytool, "my_bool_xalign", text="X:")
        row.prop(mytool, "my_bool_yalign", text="Y:")
        row.prop(mytool, "my_bool_zalign", text="Z:")
        row = box.row()
        row.operator("distribute.distributeobjects", text="Distribute Along Global Axis")
        
        # create a menu area   ===============   Face Alignment Section ===========================
        box = layout.box()
        row = box.row()
        row.label(text = "Align Object Faces:", icon = 'MODIFIER_ON')
        row = box.row()
        row.label(text = "1. Select 2 Objects")
        row = box.row()
        row.label(text = "2. Click for Edit Mode:")
        row.operator("nmsutil.objectman_selectfaces")
        row = box.row()
        row.label(text = "3. LMB to select source face")
        row = box.row()        
        row.label(text = "4. SHIFT + LMB to select destination face")
        row = box.row()        
        row.label(text = "5. Click Align:")
        row.operator("nmsutil.objectman_attachfaces", text="Align")
        row = box.row()

 

    @classmethod
    def poll(cls, context):
        return True




# "Object Along Curve" Panel class
# this contains the code that draws the "Object Along Curve" menu and in turn, calls the associated
# Operators (code that executes when a user clicks a button)  
class NMSUTIL_PT_oac_panel(Panel):
    bl_label = "Object Along Curve"
    bl_idname = "NMSUTIL_PT_oac_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "NMS Util"
    bl_options = {'DEFAULT_CLOSED'}      # startup with panel closed


    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool

        # create new menu area
        box = layout.box()
        box.separator(factor= 0.1)       

        row = box.row()
        row = box.column_flow(columns=2, align=False)      # align=False creates gaps between buttons
        row.label(text = "Select Object & Curve")
        row.operator("nmsutil.setup_oac_operator", text="Setup / Reset")
        row = box.row()
        row.label(text = "then click setup:")

        # create new area
        box = layout.box()
        row = box.row()
        row.label(text = "Object Orientation Along Curve", icon = 'CON_CLAMPTO')
        row = box.row()

        row.label(text = "Rotation Increments:", icon = 'SPHERE')
        row = box.column_flow(columns=3, align=False)      # align=False creates gaps between buttons
        if not mytool.my_bool_custom_rot: 
            row.prop(mytool, "my_bool_90_flip", text="90°")
            row.prop(mytool, "my_bool_90_flip", text="45°", invert_checkbox= True)
        else:
            row.prop(mytool, "my_float_cust_rot", text="")
            row.label(text = "Degrees  ")
        row.prop(mytool, "my_bool_custom_rot", text="Custom")
        row = box.row()
        row.operator("nmsutil.flipx_operator")
        row.operator("nmsutil.flipy_operator")
        row.operator("nmsutil.flipz_operator")
        row = box.row()
        row = box.row()
        
        # adds more spacing (range 0.1 - 100) to rows and before/after text
        #box.separator(factor= 0.1)       
        # create new menu area
        box = layout.box()
        #row.separator(factor= 100)
        row = box.row()
        row.label(text = "Copy objects along curve", icon = 'PARTICLE_POINT')
        #split = row.split(factor=.5,align= True)
        #split.label(text = "")
        row = box.row()
        row.operator("nmsutil.oac_operator", text = "Create")
        row = box.row()
       
        # create new menu area
        box = layout.box()
        #row.separator(factor= 100)
        row = box.row()
        row.label(text = "Adjust spacing along curve:", icon = 'CENTER_ONLY')
        row = box.row()
        row.label(text = "Increments:")
        row = box.row()
        
        row.operator("nmsutil.oac_inadjust_operator", text= "<<", icon = 'PLAY_REVERSE')
        row.operator("nmsutil.oac_outadjust_operator", text= ">>", icon = 'PLAY')
        row.label(text = "%Adjust by:")
        row.prop(mytool, "my_float_oac_adjoffset", text="")
        row = box.row()
        row = box.row()
        row = box.column_flow(columns=2, align=False)      # align=False creates gaps between buttons
        #row.label(text = "")
        #split = row.split(factor=0.5,align= True)
        #split.label(text = " ")
        row.label(text = "Spacing (0 - 1):")
        row.prop(mytool, "my_float_oac_offset", text="")
        row = box.row()
        row = box.row()
        row.operator("nmsutil.oac_adjust_operator", text = "Adjust")
        row = box.row()

    @classmethod
    def poll(cls, context):
        return True



# "Object Replacement" Panel class
# this contains the code that draws the "Object Replacement" menu and in turn, calls the associated
# Operators (code that executes when a user clicks a button)  
class NMSUTIL_PT_objrep_panel(Panel):
    bl_label = "Object Replacement"
    bl_idname = "NMSOBJECTREP_PT_objrep_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "NMS Util"
    bl_options = {'DEFAULT_CLOSED'}      # startup with panel closed


    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool
        
       # get the currently active object
        obj = context.object

        # create a menu area
        box = layout.box()
        row = box.row()

        if len(bpy.context.selected_objects) > 1 and obj:
            # adds more spacing (range 0.1 - 100) to rows and before/after text
            #box.separator(factor= 0.1)       
            #row.separator(factor= 100)
            row.label(text = "Replace Selected Object(s) with Active Object:", icon = 'MODIFIER_ON')
            row = box.row()
            #split = row.split(factor=.5,align= True)
            #split.label(text = "")
            row = box.row()
            if len(bpy.context.selected_objects) > 0 and obj:
                row.label(text = "You are about to replace ({0}) objects"
                .format(len(bpy.context.selected_objects) - 1))
                row = box.row()
                row.label(text = "with:  {0}"
                .format(obj.name))
            row = box.row()
            row.prop(mytool, "my_bool_attr_sca", text= "Keep Scale")
            row = box.row()        
            row = box.row()        
            row.operator("nmsutil.objectrep_perf_action", text="Apply")
            row = box.row()
        else:
            row.label(text = "Select objects to replace, with last")
            row = box.row()
            row.label(text = "object selected as replacement object")
       

    @classmethod
    def poll(cls, context):
        return True




# "NMSUtil Curve" Panel class
# this contains the code that draws the "Curves" menu and in turn, calls the associated
# Operators (code that executes when a user clicks a button)  
class NMSUTIL_PT_curves_panel(Panel):
    bl_label = "Curve Creator"
    bl_idname = "NMSUTIL_PT_curves_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "NMS Util"
    bl_options = {'DEFAULT_CLOSED'}      # startup with panel closed


    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_curvetool

        # check if at least 1 object selected, and it's a curve
        found = len(bpy.context.selected_objects) and  bpy.context.selected_objects[0].type == 'CURVE'
        if found:
            # get the first object
            obj = bpy.context.selected_objects[0]
            objname = obj.name
        else:
            obj = bpy.context.object
            objname = ""
                
        # create a menu area - Curve shape
        box = layout.box()
        row = box.row()


        
        # ========= Straight Curve ===============
        if not found:
            if mytool.my_enum_curve_shape == 'OP1': 
                #row = box.column_flow(columns=2, align=False)      # align=False creates gaps between buttons
                    row.label(text = "Build Curve Shape:", icon = 'MODIFIER')
                    row.prop(mytool, "my_enum_curve_shape", icon = 'REMOVE')
                    row = box.row()
                    row = box.column_flow(columns=2, align=False)      # align=False creates gaps between buttons
                    row.operator("nmsutil.curve_build", text= "Build Curve")
                    row.prop(mytool, "my_int_curve_cp")
        else:   # editing existing curve
            # check if selected object is a straight curve
            if "StraightCurve" in objname:
                # further check if the currently selected item is a curve object
                row.label(text = "Adjust Curve Shape:", icon = 'MODIFIER')
                
                # save the object interaction mode
                objmode = "Mode: " + bpy.context.object.mode
                
                row.operator("object.editmode_toggle", text=objmode)
                row = box.row()
                split = row.split(factor=0.5,align= True)
                cp = CURVES.ControlPoints(bpy.context.selected_objects[0])
                cpstr = "Adjust Control Points: ({0})".format(cp)
                
                split.label(text=cpstr)
                split.operator("nmsutil.curve_cpadjustdown", text= "<<")
                split.operator("nmsutil.curve_cpadjustup", text= ">>")


       
        # ========= Circle Curve ===============
        if not found:
            if mytool.my_enum_curve_shape == 'OP2': 
                #row = box.column_flow(columns=2, align=False)      # align=False creates gaps between buttons
                    row.label(text = "Build Curve Shape:", icon = 'MODIFIER')
                    row.prop(mytool, "my_enum_curve_shape", icon = 'MESH_CIRCLE')
                    row = box.row()
                    row = box.column_flow(columns=2, align=False)      # align=False creates gaps between buttons
                    row.operator("nmsutil.curve_build", text= "Build Curve")
                    row.prop(mytool, "my_int_curve_diam")
        
        else:   # editing existing curve
            # check if selected object is a circle curve
            if "CircleCurve" in objname:
                # further check if the currently selected item is a curve object
                row.label(text = "Adjust Circle Size:", icon = 'MODIFIER')
                
                # allow toggle of the object interaction mode
                objmode = "Mode: " + bpy.context.object.mode
                row.operator("object.editmode_toggle", text=objmode)
                row = box.row()
                row.operator("transform.resize", text= "Re-size")

        # ========= Half-Circle Curve ===============
        if not found:
            if mytool.my_enum_curve_shape == 'OP3': 
                #row = box.column_flow(columns=2, align=False)      # align=False creates gaps between buttons
                    row.label(text = "Build Curve Shape:", icon = 'MODIFIER')
                    row.prop(mytool, "my_enum_curve_shape", icon = 'SPHERECURVE')
                    row = box.row()
                    row = box.column_flow(columns=2, align=False)      # align=False creates gaps between buttons
                    row.operator("nmsutil.curve_build", text= "Build Curve")
                    row.prop(mytool, "my_int_curve_diam")
        
        else:   # editing existing curve
            # check if selected object is a circle curve
            if "HalfCircCurve" in objname:
                # further check if the currently selected item is a curve object
                row.label(text = "Adjust Half-Circle Size:", icon = 'MODIFIER')
                
                # allow toggle of the object interaction mode
                objmode = "Mode: " + bpy.context.object.mode
                row.operator("object.editmode_toggle", text=objmode)
                row = box.row()
                row.operator("transform.resize", text= "Re-size")
        
        # ========= Wave Curve ===============
        if not found:
            if mytool.my_enum_curve_shape == 'OP4':
                row.label(text = "Build Curve Shape:", icon = 'MODIFIER')
                row.prop(mytool, "my_enum_curve_shape", icon = 'IPO_EASE_IN_OUT')
                row = box.row()
                row = box.column_flow(columns=2, align=False)      # align=False creates gaps between buttons
                row.operator("nmsutil.curve_build", text= "Build Curve")
                row.prop(mytool, "my_int_curve_cp", text="Waves")
        else:   # editing existing curve
            # check if selected object is a wave curve
            if "WaveCurve" in objname:
                # further check if the currently selected item is a curve object
                row.label(text = "Adjust Curve Shape:", icon = 'MODIFIER')
                
                # allow toggle of the object interaction mode
                objmode = "Mode: " + bpy.context.object.mode
                row.operator("object.editmode_toggle", text=objmode)
                row = box.row()
                split = row.split(factor=0.5,align= True)
                cp = CURVES.ControlPoints(bpy.context.selected_objects[0])
                waves = int((cp - 1) / 2)
                cpstr = "Adjust Waves: ({0})".format(waves)
            
                split.label(text=cpstr)
                split.operator("nmsutil.curve_cpadjustdown", text= "<<")
                split.operator("nmsutil.curve_cpadjustup", text= ">>")


        
        
        # ========= Arc Curve ===============
        if not found:
            if mytool.my_enum_curve_shape == 'OP5': 
                #row = box.column_flow(columns=2, align=False)      # align=False creates gaps between buttons
                row.label(text = "Build Curve Shape:", icon = 'MODIFIER')
                row.prop(mytool, "my_enum_curve_shape", icon = 'HIDE_ON')
                row = box.row()
                row = box.column_flow(columns=2, align=False)      # align=False creates gaps between buttons
                row.operator("nmsutil.curve_build", text= "Build Curve")
                row.prop(mytool, "my_int_curve_diam", text="Span")
        else:   # editing existing curve
            # check if selected object is a arc curve
            if "ArcCurve" in objname:
                # further check if the currently selected item is a curve object
                row.label(text = "Adjust Curve Shape:", icon = 'MODIFIER')
                
                # allow toggle of the object interaction mode
                objmode = "Mode: " + bpy.context.object.mode
                row.operator("object.editmode_toggle", text=objmode)
                row = box.row()
                row.operator("transform.resize", text= "Re-size")

        
        
        # ========= Spiral Curve ===============
        if not found:
            if mytool.my_enum_curve_shape == 'OP6' and not CURVES.HasScrewModifier(obj): 
                    #row = box.column_flow(columns=2, align=False)      # align=False creates gaps between buttons
                    row.label(text = "Build Curve Shape:", icon = 'MODIFIER')
                    row.prop(mytool, "my_enum_curve_shape", icon = 'MOD_SCREW')
                    row = box.row()
                    row = box.column_flow(columns=2, align=False)      # align=False creates gaps between buttons
                    row.operator("nmsutil.curve_setup", text= "Setup")

            # additional panel to define screw modifier
            if CURVES.HasScrewModifier(obj):
                # create a menu area - Spiral Options
                box = layout.box()
                row = box.row()
                row.label(text = "Spiral Setup:", icon = 'MOD_SCREW')
                row = box.row()
                row = box.column_flow(columns=2, align=False)      # align=False creates gaps between buttons
                # allow modifications of screw modifier parameters in panel
                row.prop(obj.modifiers['Screw'], "axis")
                row.prop(obj.modifiers['Screw'], "screw_offset")
                row = box.row()
                row.prop(obj.modifiers['Screw'], "steps")
                row.prop(obj.modifiers['Screw'], "angle")
                row = box.row()
                row.prop(obj.modifiers['Screw'], "iterations")
                row.operator("transform.resize", text= "Re-size")
                row = box.row()
                row = box.row()
                row = box.column_flow(columns=3, align=False)      # align=False creates gaps between buttons
                row.label(text = "")
                row.operator("nmsutil.curve_build", text= "Build Curve")
                row = box.row()

        else:   # editing existing curve
            # check if selected object is a arc curve
            if "SpiralCurve" in objname:
                # further check if the currently selected item is a curve object
                row.label(text = "Adjust Curve Shape:", icon = 'MODIFIER')
                
                # allow toggle of the object interaction mode
                objmode = "Mode: " + bpy.context.object.mode
                row.operator("object.editmode_toggle", text=objmode)
                row = box.row()
                row.operator("transform.resize", text= "Re-size")

                


        # ========= Common for all objects - checks for curve and offers delete option ===============

        if found:   # if a selected object exists
            if CURVES.IsCurveObject(CURVES.GetObjectConstraint(obj)) :
                # option to Destroy Curve - Keep objects along curve path
                # create a menu area - Delete
                box = layout.box()
                row = box.row()
                row.label(text = "Remove Curve & Constraints, Keep Objects:", icon = 'TRASH')
                row = box.row()
                row = box.column_flow(columns=3, align=False)      # align=False creates gaps between buttons
                row.label(text = "")
                row.operator("nmsutil.curve_delete", text= "Delete")
                row = box.row()



# ======================================== Operators =======================================================

class NMSUTIL_OP_objrep_do_action(Operator):
    bl_label = "Perform Action"
    bl_idname = "nmsutil.objectrep_perf_action"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        OBJREP.ObjReplacement()

        return {'FINISHED'} 
  

class NMSUTIL_OP_objman_do_action(Operator):
    bl_label = "Perform Action"
    bl_idname = "nmsutil.objectman_perf_action"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        OBJMAN.ObjMan()

        return {'FINISHED'}


# =====================    Clear Attributes and Align modules added =============================
class NMSUTIL_OP_SelectFaces(Operator):
    bl_label = "Edit Mode"
    bl_idname = "nmsutil.objectman_selectfaces"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool
        # get active object    
        
        obj = bpy.context.object                       

        # get the currently selected object
        if not obj : 
            ShowMessageBox("Please choose at least 2 objects!", "Object Manipulation Error", 'ERROR')
            return {'FINISHED'}

        # check if at least 2 objects selected (at least the active selected)
        if len(bpy.context.selected_objects) <= 1:
            ShowMessageBox("Please choose at least 2 objects!", "Object Manipulation Error", 'ERROR')
            return {'FINISHED'}

        # check if at least 2 objects selected (at least the active selected)
        if len(bpy.context.selected_objects) > 2:
            ShowMessageBox("Please choose only 2 objects!", "Object Manipulation Error", 'ERROR')
            return {'FINISHED'}
            
        # place 3D window in edit mode
        bpy.ops.object.mode_set(mode='EDIT')
        
        # select face mode        
        bpy.ops.mesh.select_mode(type="FACE")

        return {'FINISHED'}

# =====================    Distribute module added =============================
class DistributeObjectsOperator(bpy.types.Operator):
    bl_idname = "distribute.distributeobjects"
    bl_label = "Distribute Objects"
    bl_options = {'REGISTER', 'UNDO'}

    axis: EnumProperty(
        name="Axis",
        description="Axis selection",
        items= [('x', "X", ""),('y', "Y", ""),('z', "Z","")],
        default='x'
    )
    margin: bpy.props.FloatProperty(name="Margin")

    def execute(self, context):
        objs = bpy.context.selected_objects
        MD = 0
        if len(objs) <= 1:
            return {'CANCELLED'}
        
        first = objs[0]
        gap = abs(self.margin)
        direction = Vector((0, 0, 0))
        setattr(direction, self.axis, 1)
        if self.margin < 0:
            direction *= -1

        def axis(vec):
            return getattr(vec, self.axis)

        def point_to_world_coords(obj, t):
            return obj.matrix_world @ Vector((*t, 0))

        def world_bounds(obj):
            return [axis(point_to_world_coords(obj, q)) for q in obj.bound_box]

        new_position = first.location + direction * min(world_bounds(first))
        
        for obj in objs:
            new_position -= direction * min(world_bounds(obj))
            obj.location = new_position
            new_position += direction * (max(world_bounds(obj)) + gap)
        return {'FINISHED'}


    def invoke(self, context, event):
        if len(context.selected_objects) <= 1:
            self.report({'WARNING'}, "Not enough objects selected")
            return {'CANCELLED'}

        self.execute(context)
        return context.window_manager.invoke_props_popup(self, event)



# =====================   Attach faces module added =============================

class NMSUTIL_OP_AttachFaces(Operator):
    bl_label = "Perform Action"
    bl_idname = "nmsutil.objectman_attachfaces"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool


        
        # call the external module
        # in form: <file>.<headerclass>.<function>
        # clear the selected atrributes from the selected objects in the scene
        OBJMAN.AttachFaces()

        return {'FINISHED'}


# =====================    Clear Attributes and Align modules added =============================
class NMSUTIL_OP_ClearAttr(Operator):
    bl_label = "Perform Action"
    bl_idname = "nmsutil.objectman_clear_action"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool
        
        # call the external module
        # in form: <file>.<headerclass>.<function>
        # clear the selected atrributes from the selected objects in the scene
        OBJMAN.ClearAttr()

        return {'FINISHED'}





# =====================    Wire Text Modules  =============================

class NMSUTIL_OP_BuildText(Operator):
    bl_label = "Text Build"
    bl_idname = "nmsutil.text_build"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        WIRETEXT.BuildText()

        return {'FINISHED'}


class NMSUTIL_OP_AdjustText(Operator):
    bl_label = "Text Adjustment"
    bl_idname = "nmsutil.text_adjust"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        WIRETEXT.AdjustText()

        return {'FINISHED'}




# This operator is code that runs when a user clicks on the "Build" button in the 
# "Floor Creator" menu to add floor tiles
class OP_AddFloorTile(Operator):
    bl_label = "Add A Floor Tile"
    bl_idname = "nmsutil.add_floortile_operator"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        FLOOR.AddFloorTile()

        return {'FINISHED'}
 
 
 
 
 
# This operator is code that runs when a user clicks on the "<<" button in the 
# "Floor Creator" menu, under the "Distance to Centre" menu item, to adjust round floor tiles 
# towards/away from the round floor centre by incremental amounts.
class OP_AdjustRoundINOperator(Operator):
    bl_label = "Adjust Diameter For Round Floors:"
    bl_idname = "nmsutil.round_inadjust_operator"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        FLOOR.AdjustRoundINOperator()

        return {'FINISHED'}

 
  
# This operator is code that runs when a user clicks on the ">>" button in the 
# "Floor Creator" menu, under the "Distance to Centre" menu item, to adjust round floor tiles 
# towards/away from the round floor centre by incremental amounts.
class OP_AdjustRoundOUTOperator(Operator):
    bl_label = "Adjust Diameter For Round Floors:"
    bl_idname = "nmsutil.round_outadjust_operator"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        FLOOR.AdjustRoundOUTOperator()

        return {'FINISHED'}


# Optimized round floors creation routine for NON-symmetrical layout
# This operator is code that runs when a user clicks on the "Create" button in the 
# "Floor Creator" menu, under the "Build Round Floors" menu item, to build round floor arrangements
class OP_CreateOptoRound(Operator):
    bl_label = "Create"
    bl_idname = "nmsutil.create_opto_round_operator"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        FLOOR.CreateOptoRound()

        return {'FINISHED'}
       





# Optimized round floors creation routine for Symmetrical layout
# This operator is code that runs when a user clicks on the "Create" button in the 
# "Floor Creator" menu, under the "Build Round Floors" menu item, to build round floor arrangements
class OP_CreateSymOptoRound(Operator):
    bl_label = "Create"
    bl_idname = "nmsutil.create_sym_opto_round_operator"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        FLOOR.CreateSymOptoRound()

        return {'FINISHED'}






# Round floors creation routine for Symmetrical layout - no optimization (very wasteful on resources,
# but looks cool.
# This operator is code that runs when a user clicks on the "Create" button in the 
# "Floor Creator" menu, under the "Build Round Floors" menu item, to build round floor arrangements
class OP_CreateRound(Operator):
    bl_label = "Create"
    bl_idname = "nmsutil.create_round_operator"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        FLOOR.CreateRound()

        return {'FINISHED'}


       
 

# Square floors creation routine 
# This operator is code that runs when a user clicks on the "Create" button in the 
# "Floor Creator" menu, under the "Build Square Floors" menu item, to build square floor arrangements
class OP_CreateSquare(Operator):
    bl_label = "Create"
    bl_idname = "nmsutil.create_square_operator"
    bl_options = {"UNDO", "REGISTER"}    
    
    
    
    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        FLOOR.CreateSquare()

        return {'FINISHED'}




# This operator is the main code that runs when a user clicks on the "Setup/Reset" button in the 
# "Object Circle Creator" Panel" menu, under the "Object Circle" section, to complete the
# setup arrangement for building the circle.  
# It will dispay a circle mesh item, and a reference object, to show the intial diameter
# and arrangement of the circle build.  
class OP_SetupCircle(Operator):
    bl_label = "Setup"
    bl_idname = "nmsutil.setup_operator"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        CIRCLE.SetupCircle()

        return {'FINISHED'}



# This operator is the main code that runs when a user clicks on the "X-Axis" button in the 
# "Object Circle Creator" Panel" menu, under the "Object Orientation in Circle" section, to 
# adjust the X-Axis rotation, of the reference object, in custom or predefined rotation increments.  
class OP_FlipX(Operator):
    bl_label = "X-Axis"
    bl_idname = "nmsutil.flipx_operator"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        CIRCLE.FlipX()

        return {'FINISHED'}



# This operator is the main code that runs when a user clicks on the "Y-Axis" button in the 
# "Object Circle Creator" Panel" menu, under the "Object Orientation in Circle" section, to 
# adjust the Y-Axis rotation of the reference object, in custom or predefined rotation increments.  
class OP_FlipY(Operator):
    bl_label = "Y-Axis"
    bl_idname = "nmsutil.flipy_operator"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        CIRCLE.FlipY()

        return {'FINISHED'}



# This operator is the main code that runs when a user clicks on the "Z-Axis" button in the 
# "Object Circle Creator" Panel" menu, under the "Object Orientation in Circle" section, to 
# adjust the Z-Axis rotation of the reference object, in custom or predefined rotation increments.  
class OP_FlipZ(Operator):
    bl_label = "Z-Axis"
    bl_idname = "nmsutil.flipz_operator"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        CIRCLE.FlipZ()

        return {'FINISHED'}



# This operator is code that runs when a user clicks on the "<<" button in the 
# "Object Circle Creator" Panel" menu, under the "Object Rotation Offset" menu item, to adjust circle object(s) 
# rotation by incremental amounts.
# It is primarily used to rotate the reference object before completing the "Create Circle" routine,
# but also will rotate the entire selected object circle items if done after building the circle
class OP_RotationINAdjustOperator(Operator):
    bl_label = "Adjust Rotation:"
    bl_idname = "nmsutil.rot_inadjust_operator"
    bl_options = {"UNDO", "REGISTER"}    


    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        CIRCLE.RotationINAdjustOperator()

        return {'FINISHED'}


# This operator is code that runs when a user clicks on the ">>" button in the 
# "Object Circle Creator" Panel" menu, under the "Object Rotation Offset" menu item, to adjust circle object(s) 
# rotation by incremental amounts.
# It is primarily used to rotate the reference object before completing the "Create Circle" routine,
# but also will rotate the entire selected object circle items if done after building the circle
class OP_RotationOUTAdjustOperator(Operator):
    bl_label = "Adjust Rotation:"
    bl_idname = "nmsutil.rot_outadjust_operator"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        CIRCLE.RotationOUTAdjustOperator()

        return {'FINISHED'}

    
    
    

# This operator is code that runs when a user clicks on the "<<" button in the 
# "Object Circle Creator" Panel" menu, under the "Distance to Centre" menu item, to adjust circle object(s) 
# towards/away from the circle centre by incremental amounts.
class OP_AdjustINOperator(Operator):
    bl_label = "Adjust Diameter:"
    bl_idname = "nmsutil.inadjust_operator"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        CIRCLE.AdjustINOperator()

        return {'FINISHED'}



# This operator is code that runs when a user clicks on the ">>" button in the 
# "Object Circle Creator" Panel" menu, under the "Distance to Centre" menu item, to adjust circle object(s) 
# towards/away from the circle centre by incremental amounts.
class OP_AdjustOUTOperator(Operator):
    bl_label = "Adjust Diameter:"
    bl_idname = "nmsutil.outadjust_operator"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        CIRCLE.AdjustOUTOperator()

        return {'FINISHED'}



# This operator is the main code that runs when a user clicks on the "Create" button in the 
# "Object Circle Creator" Panel" menu, under the "Build Circle" section, to create the object circle.
class OP_CreateCircle(Operator):
    bl_label = "Create"
    bl_idname = "nmsutil.create_circle_operator"
    bl_options = {"UNDO", "REGISTER"}    


    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        CIRCLE.CreateCircle()

        return {'FINISHED'}
       

class OP_SetupObjectAlongCurve(Operator):
    bl_label = "Setup Object Along Curve"
    bl_idname = "nmsutil.setup_oac_operator"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        # call the external module
        # in form: <file>.<function>

        # setup the OAC
        OAC.SetupObjectOnCurve()    

        return {'FINISHED'}


class OP_CreateObjectsOnCurve(Operator):
    bl_label = "Object Along Curve"
    bl_idname = "nmsutil.oac_operator"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        # call the external module
        # in form: <file>.<function>
        OAC.CreateObjectsOnCurve()

        return {'FINISHED'}


class OP_OAC_INAdjust(Operator):
    bl_label = "Object IN Adjust Along Curve"
    bl_idname = "nmsutil.oac_inadjust_operator"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        # call the external module
        # in form: <file>.<function>
        OAC.OAC_INAdjust()

        return {'FINISHED'}

class OP_OAC_OUTAdjust(Operator):
    bl_label = "Object OUT Adjust Along Curve"
    bl_idname = "nmsutil.oac_outadjust_operator"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        # call the external module
        # in form: <file>.<function>
        OAC.OAC_OUTAdjust()

        return {'FINISHED'}

class OP_OAC_Adjust(Operator):
    bl_label = "Object Adjust Along Curve"
    bl_idname = "nmsutil.oac_adjust_operator"
    bl_options = {"UNDO", "REGISTER"}    

    def execute(self, context):

        # call the external module
        # in form: <file>.<function>
        OAC.OAC_Adjust()

        return {'FINISHED'}


class NMSUtil_OP_CurveSetup(bpy.types.Operator):
    bl_idname = "nmsutil.curve_setup"
    bl_label = "Setup Curves"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        CURVES.SetupCurve()
        
        return {'FINISHED'}

class NMSUtil_OP_CurveBuild(bpy.types.Operator):
    bl_idname = "nmsutil.curve_build"
    bl_label = "Build Curves"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        
        CURVES.BuildCurve()
        
        return {'FINISHED'}

class NMSUtil_OP_CurveDelete(bpy.types.Operator):
    bl_idname = "nmsutil.curve_delete"
    bl_label = "Build Curves"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        
        CURVES.DeleteCurve()
        
        return {'FINISHED'}


class NMSUtil_OP_Curve_CP_adjustup(bpy.types.Operator):
    bl_idname = "nmsutil.curve_cpadjustup"
    bl_label = "Build Curves"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        
        CURVES.AdjustCurve("up")
        
        return {'FINISHED'}

class NMSUtil_OP_Curve_CP_adjustdown(bpy.types.Operator):
    bl_idname = "nmsutil.curve_cpadjustdown"
    bl_label = "Build Curves"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        # call the external module
        # in form: <file>.<headerclass>.<function>
        
        CURVES.AdjustCurve("down")
        
        return {'FINISHED'}




# Create an array of the classes defined above
# order is important! 
classes = [MyProperties, NMSUTIL_PT_fc_panel, NMSUTIL_PT_coa_panel, NMSUTIL_PT_TextTool, NMSUTIL_PT_objman_panel,  
        NMSUTIL_PT_objrep_panel, NMSUTIL_PT_oac_panel, 
        NMSUTIL_OP_objman_do_action, NMSUTIL_OP_objrep_do_action,
        NMSUTIL_OP_SelectFaces, DistributeObjectsOperator, NMSUTIL_OP_AttachFaces,
        NMSUTIL_OP_ClearAttr,
        NMSUTIL_OP_BuildText, NMSUTIL_OP_AdjustText,
        OP_AddFloorTile, OP_AdjustRoundINOperator,
        OP_AdjustRoundOUTOperator, OP_CreateOptoRound, OP_CreateSymOptoRound, 
        OP_CreateRound, OP_CreateSquare, OP_SetupCircle, OP_FlipX, OP_FlipY, OP_FlipZ,
        OP_RotationINAdjustOperator, OP_RotationOUTAdjustOperator,
        OP_AdjustINOperator, OP_AdjustOUTOperator, OP_CreateCircle,
        OP_SetupObjectAlongCurve, OP_CreateObjectsOnCurve, 
        OP_OAC_INAdjust, OP_OAC_OUTAdjust, OP_OAC_Adjust,
        MyCurveProperties, NMSUTIL_PT_curves_panel, NMSUtil_OP_CurveSetup, 
        NMSUtil_OP_CurveBuild, NMSUtil_OP_CurveDelete, NMSUtil_OP_Curve_CP_adjustup, NMSUtil_OP_Curve_CP_adjustdown
        ]



#standard footer for Addon that registers and unregisters classes 
def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.my_tool = bpy.props.PointerProperty(type= MyProperties)
    bpy.types.Scene.my_curvetool = bpy.props.PointerProperty(type= MyCurveProperties)
 
def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.my_tool
    del bpy.types.Scene.my_curvetool
 
if __name__ == "__main__":
    register()